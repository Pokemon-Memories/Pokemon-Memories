/*

Ratings and how they work:

-2: Extremely detrimental
	  The sort of ability that relegates Pokemon with Uber-level BSTs into NU.
	ex. Slow Start, Truant

-1: Detrimental
	  An ability that does more harm than good.
	ex. Defeatist, Normalize

 0: Useless
	  An ability with no net effect during a singles battle.
	ex. Healer, Illuminate

 1: Ineffective
	  An ability that has a minimal effect. Should not be chosen over any other ability.
	ex. Damp, Shell Armor

 2: Situationally useful
	  An ability that can be useful in certain situations.
	ex. Blaze, Insomnia

 3: Useful
	  An ability that is generally useful.
	ex. Infiltrator, Sturdy

 4: Very useful
	  One of the most popular abilities. The difference between 3 and 4 can be ambiguous.
	ex. Protean, Regenerator

 5: Essential
	  The sort of ability that defines metagames.
	ex. Desolate Land, Shadow Tag

*/

'use strict';

exports.BattleAbilities = {
	// Shadow Abilities
	"legendshadow": {
		shortDesc: "Pokemon's Moves will always target the opponent's lowest Defensive Stat. Scalar Moves are always 180 BP",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Legend Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['increment'] || move.multihit) {
				this.debug('Legend Shadow boost');
				return this.chainModify(1.3);
			}
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, source) {
			if (move && (move.category === 'Physical' || move.category === 'Special') && (source.getStat('spa', false, true) >= source.getStat('atk', false, true))) {
				move.category = 'Special';
			} else if (move && (move.category === 'Physical' || move.category === 'Special') && (source.getStat('atk', false, true) > source.getStat('spa', false, true))) {
				move.category = 'Physical';
			}
			let foeactive = source.side.foe.active;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || foeactive[i].fainted) continue;
				if ((foeactive[i].getStat('def', false, true) >= foeactive[i].getStat('spd', false, true))) {
					this.add('-message', "" + source.name + " is targeting the opponent's Special Defense!");
					move.defensiveCategory = "Special";
				} else {
					this.add('-message', "" + source.name + " is targeting the opponent's Defense!");
					move.defensiveCategory = "Physical";
				}
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if ((pokemon.item === 'strangeball' || pokemon.item === 'strangeessence') && move && move.id === 'storedpower') {
				return this.chainModify(0.67);
			}
		},
		id: "legendshadow",
		name: "Legend Shadow",
		shadowAbility: true,
		rating: 3.5,
		num: 233,
	},
	"speedshadow": {
		desc: "The power of this Pokemon's move is multiplied by 1.5 if it moves ahead of its opponent.",
		shortDesc: ".",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Speed Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (target.newlySwitched || this.willMove(target)) {
				this.debug('Speed Shadow boost');
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "speedshadow",
		name: "Speed Shadow",
		shadowAbility: true,
		rating: 3,
		num: 148,
	},
	"nightshadow": {
		desc: "Prevents adjacent opposing Pokemon from choosing to switch out unless they are immune to trapping or also have this Ability. Pokemon's Status Moves have perfect accuracy.",
		shortDesc: "Traps the opponent and grants the Pokemon perfect accuracy.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Night Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
			if (!pokemon.volatiles['prenighttrap']) pokemon.addVolatile('prenighttrap');
		},
		onBoost: function (boost, target, source, effect) {
			if (boost['spe'] > 0) {
				delete boost['spe'];
				this.add("-fail", target, "boost", "Speed");
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.category === 'Status' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		id: "nightshadow",
		name: "Night Shadow",
		shadowAbility: true,
		rating: 4.5,
		num: 23,
	},
	"timeshadow": {
		shortDesc: "Pokemon's restores 1/2 of its Max Hp, if it reaches or falls below 1/4 of its Max Hp.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Time Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).flags['armorshellsmash']) {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		onResidualOrder: 99,
		onResidualSubOrder: 6,
		onResidual: function (pokemon) {
			if (pokemon.hp && (pokemon.hp <= pokemon.maxhp / 5) && !pokemon.volatiles['timeshadowlock']) {
				this.add('-activate', pokemon, 'ability: Time Shadow');
				this.add('-message', "" + pokemon.name + " is turning back time!");
				pokemon.removeVolatile('shadowstate');
				this.heal(pokemon.maxhp * 0.6);
				if (pokemon.status) pokemon.cureStatus();
				pokemon.addVolatile('shadowstate');
				pokemon.addVolatile('timeshadowlockunused');
			}
		},
		onFoeBasePower: function (basePower, attacker, defender, move) {
			if (this.effectData.target !== defender) return;
			if ((move.category === 'Physical' || move.category === 'Special') && move.priority >= 1 && move.typeMod > 0) {
				return this.chainModify(0.5);
			}
		},
		suppressWeather: true,
		id: "timeshadow",
		name: "Time Shadow",
		shadowAbility: true,
		rating: 4,
		num: 192,
	},
	"blazeshadow": {
		desc: "Pokemon's Moves will always be Critical Hits if it has any Positive Stat Boosts.",
		shortDesc: "Pokemon's Moves will always be Critical Hits if it has any Positive Stat Boosts.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Blaze Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
			if (pokemon.volatiles['flamingshadowcompleted']) return;
			if (pokemon.getStat('atk', false, true) <= pokemon.getStat('spa', false, true)) {
				this.boost({atk:1});
				pokemon.addVolatile('flamingshadowcompleted');
				pokemon.addVolatile('blzslowatk');
			} else if (pokemon.getStat('spa', false, true) < pokemon.getStat('atk', false, true)) {
				this.boost({spa:1});
				pokemon.addVolatile('flamingshadowcompleted');
				pokemon.addVolatile('blzslowspa');
			}
		},
		onModifyMove: function (move, source) {
			if (source.positiveBoosts()) {
				this.add('-message', "" + source.name + " is overflowing with power!");
				move.willCrit = true;
			}
		},
		id: "blazeshadow",
		name: "Blaze Shadow",
		shadowAbility: true,
		rating: 4.5,
		num: 51,
	},
	"aurashadow": {
		shortDesc: "Pokemon's Fighting-type moves have their priority increased by 1.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Aura Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onModifyPriority: function (priority, pokemon, target, move) {
			if (move && move.type === 'Fighting') return priority + 1;
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Fighting'] = true;
			}
		},
		id: "aurashadow",
		name: "Aura Shadow",
		shadowAbility: true,
		rating: 4,
		num: 177,
	},
	"spaceshadow": {
		shortDesc: "Pokemon's Dragon-Type Moves will always hit the opponent's Types Super-Effectively.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Space Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onModifyMove: function (move, pokemon) {
			if (move && move.type === 'Dragon') move.hasSTAB = true;
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['spaceshadoweffect']) target.removeVolatile('spaceshadoweffect');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['spaceshadoweffect']) defender.addVolatile('spaceshadoweffect');
			if (move.type === 'Dragon') move.flags['exempt'] = true;
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (source === this.effectData.target) {
				return true;
			}
			return accuracy;
		},
		id: "spaceshadow",
		name: "Space Shadow",
		shadowAbility: true,
		rating: 3.5,
		num: 1640,
	},
	"glowshadow": {
		shortDesc: "Pokemon's Fire-Type Moves hit opposing Water-Type Pokemon Super-Effectively, and its Ghost-Type Moves bypass Type-Based Immunities.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Glow Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['glowingshadoweffect']) target.removeVolatile('glowingshadoweffect');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['glowingshadoweffect']) defender.addVolatile('glowingshadoweffect');
			if (move.type === 'Fire' && (defender.hasType('Water'))) move.flags['exempt'] = true;
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Ghost'] = true;
			}
		},
		id: "glowshadow",
		name: "Glow Shadow",
		shadowAbility: true,
		rating: 3,
		num: 177,
	},
	"titanshadow": {
		desc: "Speed increases by 1 Stage when this Pokemon reaches 1/2 or less of its Max HP, Normal-Type Moves ignore immunities.",
		shortDesc: "Speed increases by 1 Stage when this Pokemon reaches 1/2 or less of its Max HP, Normal-Type Moves ignore immunities.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Titan Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp * 0.66 && !pokemon.volatiles['titanshield']) {
				this.boost({def: 1, spd: 1}, pokemon);
				pokemon.addVolatile('titanshield');
			}
			if (pokemon.hp <= pokemon.maxhp / 2 && !pokemon.volatiles['titanshadow']) {
				this.boost({spe: 1}, pokemon);
				pokemon.addVolatile('titanshadow');
			}
			if (pokemon.hp <= pokemon.maxhp * 0.333 && !pokemon.volatiles['titanfury']) {
				this.boost({atk: 2}, pokemon);
				pokemon.addVolatile('titanfury');
			}
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Normal'] = true;
			}
		},
		id: "titanshadow",
		name: "Titan Shadow",
		shadowAbility: true,
		rating: 4,
		num: 129,
	},
	"swiftshadow": {
		shortDesc: "Pokemon's Special Attacks have their Priority increased by 1.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Swift Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onModifyPriority: function (priority, pokemon, target, move) {
			if (move && move.category === 'Special') return priority + 1;
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				this.add('-activate', pokemon, 'ability: Swift Shadow');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Swift Shadow');
			return false;
		},
		id: "swiftshadow",
		name: "Swift Shadow",
		shadowAbility: true,
		rating: 5,
		num: 177,
	},
	"floralshadow": {
		desc: "Opposing moves that attempt to switch the Pokemon out will be reflected back to the opponent",
		shortDesc: "Opposing moves that attempt to switch the Pokemon out will be reflected back to the opponent",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Floral Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if ((defender.positiveBoosts())) {
				return this.chainModify(2);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status) {
				this.add('-activate', pokemon, 'ability: Floral Shadow');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Floral Shadow');
			return false;
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.hasFlowered || (!move.flags['switchfoe'] && !move.flags['switchstatusfoe'])) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasFlowered = true;
			this.useMove(newMove, target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "floralshadow",
		name: "Floral Shadow",
		shadowAbility: true,
		rating: 3,
		num: 156,
	},
	"heroshadow": {
		shortDesc: "This Pokemon will always outspeed opponent if its Base Speed is higher.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Hero Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (basePower <= 120) {
				this.debug('Hero Shadow boost');
				return this.chainModify(1.5);
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "heroshadow",
		name: "Hero Shadow",
		shadowAbility: true,
		rating: 3,
		num: 100,
	},
	"mirrorshadow": {
		desc: "Opposing Fire-Type and Flying-Type Moves are reflected back to the opponent. Pokemon's Moves hits its Resistances Super-Effectively.",
		shortDesc: "Opposing Fire-Type and Flying-Type Moves are reflected back to the opponent. Pokemon's Moves hits its Resistances Super-Effectively.",
		id: "mirrorshadow",
		name: "Mirror Shadow",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Mirror Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onModifyMove: function (move) {
			move.ignoreAbility = true;
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['mirrorshadoweffect']) target.removeVolatile('mirrorshadoweffect');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['mirrorshadoweffect']) defender.addVolatile('mirrorshadoweffect');
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.hasLanded || (move.type !== 'Fire' && move.type !== 'Flying')) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasLanded = true;
			this.useMove(newMove, target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "mirrorshadow",
		name: "Mirror Shadow",
		isBreaker: true,
		shadowAbility: true,
		rating: 4.5,
		num: 156,
	},
	"relicshadow": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Relic Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move, pokemon) {
			if (move && (move.category === 'Physical' || move.category === 'Special') && move.flags['sound']) {
				move.hasSTAB = true;
				move.flags['descale'] = true;
			}
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Fighting'] = true;
				move.ignoreImmunity['Normal'] = true;
			}
			if (move.id === 'extremespeed') {
				move.type = '???';
				move.hasSTAB = true;
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Ghost' && typeMod > 0 && !move.flags['exempt']) {
				return -1;
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (source === this.effectData.target) {
				return true;
			}
			return accuracy;
		},
		id: "relicshadow",
		name: "Relic Shadow",
		shadowAbility: true,
		rating: 4,
		num: 88,
	},
	"forgeshadow": {
		shortDesc: "If this Pokemon is at full HP, damage taken from attacks is halved.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Forge Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.target !== 'self') {
				target.addVolatile('forgefactor');
			}
		},
		onUpdate: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i].volatiles['forgeswitch']) foeactive[i].addVolatile('forgeswitch');
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (target.hp) {
				this.debug('Forge weaken');
				return this.chainModify(0.5);
			}
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, target, source);
			return null;
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['forgeshadoweffect']) defender.addVolatile('forgeshadoweffect');
			if (move.type === 'Rock' && (defender.hasType('Steel'))) move.flags['exempt'] = true;
		},
		onAllyTryHitSide: function (target, source, move) {
			if (target.side === source.side || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, this.effectData.target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "forgeshadow",
		name: "Forge Shadow",
		shadowAbility: true,
		rating: 5,
		num: 136,
	},
	"thundershadow": {
		shortDesc: "Pokemon's Dragon-Type Moves will always hit the opponent's Types Super-Effectively.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['shadowmsg']) return;
			this.add('-ability', pokemon, 'Thunder Shadow');
			this.add('-message', "" + pokemon.name + " is blazing with Shadow Energy!");
			pokemon.addVolatile('shadowmsg');
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move && move.type === 'Electric') move.hasSTAB = true;
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Electric'] = true;
			}
			if (move.category === 'Special' && !move.isZ && move.id !== 'strangewave' && !move.flags['nocategoryswap']) {
				move.category = 'Physical';
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (source === this.effectData.target) {
				return true;
			}
			return accuracy;
		},
		id: "thundershadow",
		name: "Thunder Shadow",
		shadowAbility: true,
		rating: 3.5,
		num: 1640,
	},

	// Debug Ability
	"debugtest": {
		shortDesc: "This Pokemon's Hp is doubled.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk) {
			return this.chainModify(2);
		},
		isNonstandard: true,
		id: "debugtest",
		name: "debugtest",
		rating: 5,
		num: 37,
	},

	// Debut Abilities
	"armament": {
		desc: ".",
		shortDesc: ".",
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Bug' && (move.type === 'Fire') && !move.flags['exempt']) {
				return 0;
			} else if (move && move.effectType === 'Move' && type === 'Steel' && (move.type === 'Fire') && !move.flags['exempt']) {
				return -1;
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (basePower <= 100) {
				this.debug('Armament boost');
			}
		},
		id: "armament",
		name: "Armament",
		addedAbility: true,
		rating: 3.5,
		num: 88,
	},
	"assembly": {
		desc: "Pokemon automatically restores 1/3 of its Max Hp upon falling below 1/2. Activates once per Switch-In",
		shortDesc: "Pokemon automatically restores 1/3 of its Max Hp upon falling below 1/2. Activates once per Switch-In",
		onUpdate: function (pokemon) {
			if (pokemon.hp && (pokemon.hp <= pokemon.maxhp / 2) && !pokemon.volatiles['assembled']) {
				this.add('-ability', pokemon, 'Assembly');
				this.add('-anim', pokemon, 'calmmind', pokemon);
				this.add('-message', "" + pokemon.name + " is repairing itself!");
				this.heal(pokemon.maxhp / 3);
				pokemon.addVolatile('assembled');
			}
		},
		id: "assembly",
		name: "Assembly",
		addedAbility: true,
		rating: 3.5,
		num: 83,
	},
	"breakingpoint": {
		desc: "Pokemon's highest offensive Stat is sharply raised when its health drops to 1/3 or less.",
		shortDesc: "Pokemon's highest offensive Stat is sharply raised when its health drops to 1/3 or less.",
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 3 && !pokemon.volatiles['breakingpoint']) {
				if (pokemon.getStat('atk', false, true) >= pokemon.getStat('spa', false, true)) {
					this.boost({atk:2});
					pokemon.addVolatile('breakingpoint');
				} else if (pokemon.getStat('spa', false, true) > pokemon.getStat('atk', false, true)) {
					this.boost({spa:2});
					pokemon.addVolatile('breakingpoint');
				}
			}
		},
		id: "breakingpoint",
		name: "Breaking Point",
		addedAbility: true,
		rating: 4,
		num: 129,
	},
	"culinary": {
		desc: "If this Pokemon is at or above Half of its Max HP, it survives one hit with at least 1 HP. OHKO moves fail when used against this Pokemon.",
		shortDesc: "If this Pokemon is at or above Half of its Max HP, it survives one hit with at least 1 HP. Immune to OHKO.",
		onDamagePriority: -100,
		onDamage: function (damage, target, source, effect) {
			if (!target.item || target.item !== 'berryjuice') return;
			if ((target.hp >= target.maxhp / 2) && damage >= target.hp && effect && effect.effectType === 'Move') {
				if (target.useItem()) {
					this.add('-ability', target, 'Culinary');
					this.add('-message', "" + target.name + "'s beverage is keeping it awake!");
					target.addVolatile('beverage');
					return target.hp - 1;
				}
			}
		},
		id: "culinary",
		name: "Culinary",
		addedAbility: true,
		rating: 4,
		num: 5,
	},
	"darksmog": {
		shortDesc: ".",
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.typeMod < 0) {
				this.heal(pokemon.maxhp / 2, pokemon, pokemon, null, null);
			}
			if (target.volatiles['darksmog']) target.removeVolatile('darksmog');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['darksmog']) defender.addVolatile('darksmog');
			if (move.selfSwitch) move.flags['exempt'] = true;
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && (move.category === 'Physical' || move.category === 'Special') && (move.flags['switch'] || move.selfSwitch)) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "darksmog",
		name: "Dark Smog",
		rating: 3,
		num: 260,
	},
	"effervescent": {
		shortDesc: "This Pokemon can hit Ghost types with Normal- and Fighting-type moves.",
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Fighting'] = true;
				move.ignoreImmunity['Normal'] = true;
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && (move.type === 'Fighting' || move.type === 'Normal')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "effervescent",
		name: "Effervescent",
		addedAbility: true,
		rating: 3,
		num: 113,
	},
	"equalizer": {
		desc: "If this Pokemon has a major status condition, its Attack and SpA are multiplied by 1.3.",
		shortDesc: "If this Pokemon is statused, its Attack and SpA is 1.3x.",
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.target !== 'self') {
				target.addVolatile('equalfactor');
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || foeactive[i].fainted) continue;
				let scale = (Math.floor(foeactive[i].getStat('atk', false, true)) + (foeactive[i].getStat('spa', false, true)));
				this.heal(scale / 8);
			}
		},
		id: "equalizer",
		name: "Equalizer",
		addedAbility: true,
		rating: 3,
		num: 113,
	},
	"fairyspring": {
		shortDesc: "This Pokemon's moves have their secondary effect chance doubled.",
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.selfSwitch) {
				this.heal(pokemon.maxhp / 3, pokemon, pokemon, null, null);
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.effectType === 'Move' && effect.type === 'Dark' && effect.target !== 'self') {
				target.addVolatile('fairyspring');
			}
		},
		id: "fairyspring",
		name: "Fairy Spring",
		rating: 3.5,
		num: 32,
	},
	"forestsedge": {
		desc: "This Pokemon is immune to Water-type moves and restores 1/4 of its maximum HP, rounded down, when hit by a Water-type move.",
		shortDesc: "This Pokemon heals 1/4 of its max HP when hit by Water moves; Water immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && (move.category === 'Special' && move.type === 'Dark')) {
				if (!this.heal(target.maxhp / 3)) {
					this.add('-immune', target, '[msg]', '[from] ability: Forest\'s Edge');
				}
				return null;
			}
		},
		addedAbility: true,
		id: "forestsedge",
		name: "Forest's Edge",
		rating: 3.5,
		num: 11,
	},
	"mutation": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && (move.type === 'Psychic')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target !== source) return;
			let showMsg = false;
			for (let i in boost) {
				if (effect.type === 'Psychic' && (!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Shadow Shield", "[of] " + target);
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (source === this.effectData.target) {
				return true;
			}
			return accuracy;
		},
		id: "mutation",
		name: "Mutation",
		addedAbility: true,
		rating: 3.5,
		num: 253,
	},
	"mysticguard": {
		shortDesc: "This Pokemon cannot be burned. Gaining this Ability while burned cures it.",

		onEffectiveness: function (typeMod, target, type, move) {
			if (!target.hasType('Psychic')) return;
			if (move && move.effectType === 'Move' && type === 'Psychic' && !move.flags['exempt'] && typeMod > 0) {
				return 0;
			}
		},
		id: "mysticguard",
		name: "Mystic Guard",
		addedAbility: true,
		rating: 3.5,
		num: 41,
	},
	"powergenerator": {
		desc: "This Pokemon has a 33% chance to have its major status condition cured at the end of each turn.",
		shortDesc: "This Pokemon has a 33% chance to have its status cured at the end of each turn.",
		onSwitchIn: function (pokemon) {
			pokemon.addVolatile('energized');
		},
		onResidualOrder: 5,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.hp && !pokemon.volatiles['energized'] && this.random(3) === 0) {
				this.debug('full power core');
				this.add('-activate', pokemon, 'ability: Power Generator');
				pokemon.addVolatile('energized');
			}
		},
		id: "powergenerator",
		name: "Power Generator",
		addedAbility: true,
		isEnergizer: true,
		rating: 3.5,
		num: 61,
	},
	"reconstruction": {
		desc: "Pokemon automatically restores 1/3 of its Max Hp upon falling below 1/2. Activates once per Switch-In",
		shortDesc: "Pokemon automatically restores 1/3 of its Max Hp upon falling below 1/2. Activates once per Switch-In",
		onUpdate: function (pokemon) {
			if (pokemon.hp && (pokemon.hp <= pokemon.maxhp / 2) && !pokemon.volatiles['rebuilt']) {
				this.add('-ability', pokemon, 'Reconstruction');
				this.add('-anim', pokemon, 'shiftgear', pokemon);
				this.add('-message', "" + pokemon.name + " is rebuilding itself!");
				this.heal(pokemon.maxhp / 3);
				pokemon.addVolatile('rebuilt');
			}
		},
		id: "reconstruction",
		name: "Reconstruction",
		addedAbility: true,
		rating: 3.5,
		num: 83,
	},
	"sacredorigin": {
		desc: ".",
		shortDesc: ".",
		onSwitchIn: function (pokemon) {
			this.add('-ability', pokemon, 'Sacred Origin');
			this.add('-message', "" + pokemon.name + " has graced the field with its presence!");
		},
		onModifyMove: function (move, pokemon) {
			let foundation = pokemon.getItem();
			if (pokemon.template.species === 'Arceus-Revelation') {
				move.hasSTAB = true;
				move.stab = 2;
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (source.template.species === 'Arceus-Revelation' && source === this.effectData.target) {
				return true;
			}
			return accuracy;
		},
		onEffectiveness: function (typeMod, target, type, move) {
			let origin = target.types[0];
			if (target.template.species !== 'Arceus-Revelation') return;
			if (move && move.effectType === 'Move' && !move.flags['exempt'] && target.hp >= target.maxhp && type === origin) {
				this.add('-ability', target, 'Sacred Origin');
				this.add('-anim', target, 'calmmind', target);
				this.add('-message', "The Original One is glistening with light..");
				return -1;
			}
		},
		onSwitchOut: function (pokemon) {
			if (!pokemon.template.species !== 'Arceus-Revelation' || !pokemon.status) return;
			if (pokemon.status) {
				this.add('-ability', pokemon, 'Sacred Origin');
				this.add('-curestatus', pokemon, pokemon.status);
				pokemon.setStatus('');
			}
		},
		id: "sacredorigin",
		name: "Sacred Origin",
		rating: 5,
		num: 11,
	},
	"shadowcleaver": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			let vary = pokemon.types[0];
			let varys = pokemon.types[1];
			let contin = pokemon.getTypes();
			if (move && (move.type === vary || move.type === varys)) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Ghost'] = true;
				move.ignoreImmunity['Normal'] = true;
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category !== 'Status') {
				this.heal(pokemon.lastDamage / 4, pokemon, pokemon, null, null);
			}
			if (target.volatiles['shadowcleaver']) target.removeVolatile('shadowcleaver');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['shadowcleaver']) defender.addVolatile('shadowcleaver');
			if (move.type === 'Ghost') move.flags['exempt'] = true;
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, source) {
			let foeactive = source.side.foe.active;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || foeactive[i].fainted) continue;
				if (((move.category === 'Physical' || move.flags['hitsdef']) || (move.category === 'Special' || move.flags['hitsspd'])) && foeactive[i].boosts.def >= 1) {
					this.add('-message', "" + source.name + " is cleaving through the target's Defenses!");
					move.ignoreDefensive = true;
				}
			}
		},
		id: "shadowcleaver",
		name: "Shadow Cleaver",
		addedAbility: true,
		rating: 4,
		num: 253,
	},
	"shadowcloak": {
		desc: ".",
		shortDesc: ".",
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && (move.type === 'Dark' && !move.flags['exempt'])) {
				return -1;
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (effect.id === 'sparklewave' || effect.id === 'tailwind' || effect.id === 'trickroom' || effect.id === 'uproar') {
				this.attrLastMove('[still]');
				this.add('-activate', this.effectData.target, 'ability: Shadow Cloak');
				this.add('-message', "" + source.name + " cannot use this move!");
				return false;
			}
		},
		id: "shadowcloak",
		name: "Shadow Cloak",
		addedAbility: true,
		rating: 3.5,
		num: 11,
	},
	"shieldsend": {
		shortDesc: "This Pokemon's contact moves have a 30% chance of poisoning.",
		onModifyMove: function (move, source, target) {
			if (!move || (move.category !== 'Physical' && move.category !== 'Special')) return;
			if (!move.secondaries) {
				move.secondaries = [];
			}
			move.secondaries.push({
				self: {
					boosts: {
						atk: 1,
						def: -1,
						spd: -1,
					},
				},
				ability: this.getAbility('shieldsend'),
			});
		},
		id: "shieldsend",
		name: "Shield's End",
		addedAbility: true,
		rating: 4,
		num: 143,
	},
	"warmembrace": {
		shortDesc: "This Pokemon cannot be burned. Gaining this Ability while burned cures it.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod > 0) {
				this.debug('Warm Embrace neutralize');
				return this.chainModify(0.75);
			}
		},
		id: "warmembrace",
		name: "Warm Embrace",
		addedAbility: true,
		rating: 3,
		num: 41,
	},


	// Abilities
	"adaptability": {
		desc: "This Pokemon's moves that match one of its types have a same-type attack bonus (STAB) of 2 instead of 1.5.",
		shortDesc: "This Pokemon's same-type attack bonus (STAB) is 2 instead of 1.5.",
		onModifyMove: function (move) {
			move.stab = 2;
		},
		id: "adaptability",
		name: "Adaptability",
		rating: 3.5,
		num: 91,
	},
	"powerspot": {
		desc: "This Pokemon's moves that match one of its types have a same-type attack bonus (STAB) of 1.8 instead of 1.5.",
		shortDesc: "This Pokemon's same-type attack bonus (STAB) is 1.8 instead of 1.5.",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Power Spot');
				this.add('-message', "" + pokemon.name + " has awakened its Spectral Powers!");
			}
		},
		onTryHit: function (target, source, move) {
			if (target !== source  && move.type === 'UnusedForNow' && move.priority >= 1) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Power Spot');
				}
				return null;
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4) {
				return this.chainModify(1.5);
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.volatiles['activechange'] && (move && move.type === 'Ghost') && ((move.category === 'Physical' && pokemon.boosts.atk < 1) || move.category === 'Special' && pokemon.boosts.spa < 1)) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		id: "powerspot",
		name: "Power Spot",
		rating: 3,
		num: 91,
	},
	"aftermath": {
		desc: "If this Pokemon is knocked out with a contact move, that move's user loses 1/4 of its maximum HP, rounded down. If any active Pokemon has the Ability Damp, this effect is prevented.",
		shortDesc: "If this Pokemon is KOed with a contact move, that move's user loses 1/4 its max HP.",
		id: "aftermath",
		name: "Aftermath",
		onAfterDamageOrder: 1,
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.flags['contact'] && !target.hp) {
				this.damage(source.maxhp / 4, source, target);
			}
		},
		rating: 2.5,
		num: 106,
	},
	"aerilate": {
		desc: "This Pokemon's Normal-type moves become Flying-type moves and have their power multiplied by 1.2. This effect comes after other effects that change a move's type, but before Ion Deluge and Electrify's effects.",
		shortDesc: "This Pokemon's Normal-type moves become Flying type and have 1.2x power.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.type === 'Normal' && move.id !== 'naturalgift' && !move.isZ) {
				move.type = 'Flying';
				if (move.category !== 'Status') pokemon.addVolatile('aerilate');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x1333, 0x1000]);
			},
		},
		id: "aerilate",
		name: "Aerilate",
		isSuffix: true,
		rating: 4,
		num: 185,
	},
	"dracolate": {
		desc: "This Pokemon's Normal-type moves become Flying-type moves and have their power multiplied by 1.2. This effect comes after other effects that change a move's type, but before Ion Deluge and Electrify's effects.",
		shortDesc: "This Pokemon's Normal-type moves become Flying type and have 1.2x power.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.type === 'Normal' && move.id !== 'naturalgift' && !move.isZ) {
				move.type = 'Dragon';
				if (move.category !== 'Status') pokemon.addVolatile('dracolate');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x1333, 0x1000]);
			},
		},
		id: "dracolate",
		isSuffix: true,
		name: "Dracolate",
		rating: 4,
		num: 185,
	},
	"ignition": {
		desc: "This Pokemon's Normal-type moves become Flying-type moves and have their power multiplied by 1.2. This effect comes after other effects that change a move's type, but before Ion Deluge and Electrify's effects.",
		shortDesc: "This Pokemon's Normal-type moves become Flying type and have 1.2x power.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.type === 'Normal' && move.id !== 'naturalgift' && !move.isZ) {
				move.type = 'Fire';
				if (move.category !== 'Status') pokemon.addVolatile('ignition');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x1333, 0x1000]);
			},
		},
		id: "ignition",
		isSuffix: true,
		name: "Ignition",
		rating: 4,
		num: 185,
	},
	"airlock": {
		shortDesc: "While this Pokemon is active, the effects of weather conditions are disabled.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Air Lock');
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				this.add('-activate', pokemon, 'ability: Air Lock');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Air Lock');
			return false;
		},
		suppressWeather: true,
		id: "airlock",
		name: "Air Lock",
		rating: 3,
		num: 76,
	},
	"royalmajesty": {
		shortDesc: "While this Pokemon is active, the effects of weather conditions are disabled.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['royal']) {
				this.debug('Royal Majesty boost');
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "royalmajesty",
		name: "Royal Majesty",
		rating: 3,
		num: 267,
	},
	"analytic": {
		desc: "The power of this Pokemon's move is multiplied by 1.3 if it is the last to move in a turn. Does not affect Doom Desire and Future Sight.",
		shortDesc: "This Pokemon's attacks have 1.3x power if it is the last to move in a turn.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (!this.willMove(defender)) {
				this.debug('Analytic boost');
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "analytic",
		name: "Analytic",
		rating: 2,
		num: 148,
	},
	"angerpoint": {
		desc: "If this Pokemon, but not its substitute, is struck by a critical hit, its Attack is raised by 12 stages.",
		shortDesc: "If this Pokemon (not its substitute) takes a critical hit, its Attack is raised 12 stages.",
		onAfterDamage: function (damage, target, source, effect) {
			if ((effect && effect.effectType === 'Move' && effect.id !== 'confused') && target.boosts.atk < 1) {
				this.boost({atk: 1});
			}
		},
		id: "angerpoint",
		name: "Anger Point",
		rating: 3.5,
		num: 83,
	},
	"anticipation": {
		desc: "On switch-in, this Pokemon is alerted if any opposing Pokemon has an attack that is super effective on this Pokemon, or an OHKO move. Counter, Metal Burst, and Mirror Coat count as attacking moves of their respective types, while Hidden Power, Judgment, Natural Gift, Techno Blast, and Weather Ball are considered Normal-type moves.",
		shortDesc: "On switch-in, this Pokemon shudders if any foe has a supereffective or OHKO move.",
		onStart: function (pokemon) {
			let targets = pokemon.side.foe.active;
			for (let i = 0; i < targets.length; i++) {
				if (!targets[i] || targets[i].fainted) continue;
				for (let j = 0; j < targets[i].moveset.length; j++) {
					let move = this.getMove(targets[i].moveset[j].move);
                                       if (move.category !== 'Status' && (this.getImmunity(move.type, pokemon) && this.getEffectiveness(move.type, pokemon) > 0 || move.ohko)) {
						this.add('-ability', pokemon, 'Anticipation');
						if (!pokemon.volatiles['anticipateset']) {
							this.boost({spe: 1}, null, null, null, true);
							if (!pokemon.volatiles['aspeeddrop']) pokemon.addVolatile('aspeeddrop');
							pokemon.addVolatile('anticipateset');
						}
						return;
					}
				}
			}
		},
		id: "anticipation",
		name: "Anticipation",
		rating: 3,
		num: 107,
	},
	"arenatrap": {
		desc: "Prevents adjacent opposing Pokemon from choosing to switch out unless they are immune to trapping or are airborne.",
		shortDesc: "Prevents adjacent foes from choosing to switch unless they are airborne.",
		onFoeTrapPokemon: function (pokemon) {
			let condition = pokemon.getAbility();
			if (condition.isBreaker) return;
			if (!this.isAdjacent(pokemon, this.effectData.target) || pokemon.hasType('Ghost')) return;
			if (pokemon.isGrounded()) {
				pokemon.tryTrap(true);
			}
		},
		onFoeMaybeTrapPokemon: function (pokemon, source) {
			if (!source) source = this.effectData.target;
			if (!this.isAdjacent(pokemon, source) || pokemon.hasType('Ghost')) return;
			if (pokemon.isGrounded(!pokemon.knownType)) { // Negate immunity if the type is unknown
				pokemon.maybeTrapped = true;
			}
		},
		id: "arenatrap",
		name: "Arena Trap",
		rating: 4.5,
		num: 71,
	},
	"aromaveil": {
		desc: "This Pokemon and its allies cannot be affected by Attract, Disable, Encore, Heal Block, Taunt, or Torment.",
		shortDesc: "Protects user/allies from Attract, Disable, Encore, Heal Block, Taunt, and Torment.",
		onAllyTryAddVolatile: function (status, target, source, effect) {
			if (status.id in {attract:1, disable:1, encore:1, healblock:1, taunt:1, torment:1}) {
				if (effect.effectType === 'Move') {
					this.add('-activate', this.effectData.target, 'ability: Aroma Veil', '[of] ' + target);
				}
				return null;
			}
		},
		id: "aromaveil",
		name: "Aroma Veil",
		rating: 1.5,
		num: 165,
	},
	"aurabreak": {
		desc: "While this Pokemon is active, the effects of the Abilities Dark Aura and Fairy Aura are reversed, multiplying the power of Dark- and Fairy-type moves, respectively, by 3/4 instead of 1.33.",
		shortDesc: "While this Pokemon is active, the Dark Aura and Fairy Aura power modifier is 0.75x.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Aura Break');
		},
		onAnyTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			source.addVolatile('aurabreak');
		},
		effect: {
			duration: 1,
		},
		onModifyMove: function (move) {
			move.ignoreAbility = true;
		},
		id: "aurabreak",
		isBreaker: true,
		name: "Aura Break",
		rating: 1.5,
		num: 188,
	},
	"distortionveil": {
		desc: "While this Pokemon is active, the effects of the Abilities Dark Aura and Fairy Aura are reversed, multiplying the power of Dark- and Fairy-type moves, respectively, by 3/4 instead of 1.33.",
		shortDesc: "While this Pokemon is active, the Dark Aura and Fairy Aura power modifier is 0.75x.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Distortion Veil');
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod > 0) {
				this.debug('Distortion Veil neutralize');
				return this.chainModify(0.75);
			}
		},
		id: "distortionveil",
		name: "Distortion Veil",
		rating: 2.5,
		num: 188,
	},
	"distortionpower": {
		shortDesc: "Prevents other Pokemon from lowering this Pokemon's stat stages.",
		onBoost: function (boost, target, source, effect) {
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Distortion Power", "[of] " + target);
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'recoil' && this.activeMove.id !== 'struggle') return null;
		},
		id: "distortionpower",
		name: "Distortion Power",
		rating: 2,
		num: 29,
	},
	"baddreams": {
		desc: "Causes adjacent opposing Pokemon to lose 1/8 of their maximum HP, rounded down, at the end of each turn if they are asleep.",
		shortDesc: "Causes sleeping adjacent foes to lose 1/8 of their max HP at the end of each turn.",
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (!pokemon.hp) return;
			for (let i = 0; i < pokemon.side.foe.active.length; i++) {
				let target = pokemon.side.foe.active[i];
				if (!target || !target.hp) continue;
				if (target.status === 'slp' || target.hasAbility('comatose')) {
					this.damage(target.maxhp / 8, target, pokemon);
				}
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.category !== 'Status' && target.status === 'slp') {
				return this.chainModify([0x2000, 0x1000]);
			}
		},
		id: "baddreams",
		name: "Bad Dreams",
		rating: 2,
		num: 123,
	},
	"battery": {
		shortDesc: "This Pokemon's allies have the power of their special attacks multiplied by 1.3.",
		onBasePowerPriority: 8,
		onAllyBasePower: function (basePower, attacker, defender, move) {
			if (attacker !== this.effectData.target && move.category === 'Special') {
				this.debug('Battery boost');
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "battery",
		name: "Battery",
		rating: 0,
		num: 217,
	},
	"climatechange": {
		desc: "Causes certain Pokemon to change based on weather.",
		shortDesc: "Causes certain Pokemon to change based on weather.",
		onStart: function (pokemon) {
			delete this.effectData.forme;
		},
		onUpdate: function (pokemon) {
			let memcheck = pokemon.getItem();
			if (!pokemon.isActive || pokemon.baseTemplate.baseSpecies !== 'Sawsbuck' || pokemon.transformed) return;
			if (this.isWeather(['sunnyday', 'desolateland']) || ((!this.isWeather['sunnyday'] && !this.isWeather['desolateland']) && pokemon.item === 'firestone')) {
				if (pokemon.template.speciesid !== 'sawsbucksummer') {
					pokemon.formeChange('Sawsbuck-Summer');
					this.add('-formechange', pokemon, 'Sawsbuck-Summer', '[msg]', '[from] ability: Climate Change');
					pokemon.addVolatile('formecheck');
					if (!pokemon.setType('Fire')) return;
					this.add('-start', pokemon, 'typechange', 'Fire', '[from] Climate Change');
					if (!pokemon.addType('Grass')) return;
					this.add('-start', pokemon, 'typeadd', 'Grass', '[from] Climate Change');
					if (!pokemon.volatiles['climateboost']) pokemon.addVolatile('climateboost');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memorynormal']) pokemon.removeVolatile('memorynormal');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memorywater']) pokemon.removeVolatile('memorywater');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memoryice']) pokemon.removeVolatile('memoryice');
					if (pokemon.volatiles['activechange'] && !pokemon.volatiles['memoryfire'] && memcheck.onMemory !== 'Fire') pokemon.addVolatile('memoryfire');
				}
			} else if (this.isWeather(['raindance', 'primordialsea']) || ((!this.isWeather['raindance'] && !this.isWeather['primordialsea']) && pokemon.item === 'waterstone')) {
			if (pokemon.template.speciesid !== 'sawsbuckautumn') {
					pokemon.formeChange('Sawsbuck-Autumn');
					pokemon.addVolatile('formecheck');
					if (!pokemon.setType('Fire')) return;
					this.add('-start', pokemon, 'typechange', 'Fire', '[from] Climate Change');
					if (!pokemon.addType('Grass')) return;
					this.add('-start', pokemon, 'typeadd', 'Grass', '[from] Climate Change');
					if (!pokemon.volatiles['climateboost']) pokemon.addVolatile('climateboost');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memorynormal']) pokemon.removeVolatile('memorynormal');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memoryfire']) pokemon.removeVolatile('memoryfire');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memoryice']) pokemon.removeVolatile('memoryice');
					if (pokemon.volatiles['activechange'] && !pokemon.volatiles['memorywater'] && memcheck.onMemory !== 'Water') pokemon.addVolatile('memorywater');
				}
			} else if (this.isWeather(['hail']) || (!this.isWeather['hail'] && pokemon.item === 'icestone')) {
			if (pokemon.template.speciesid !== 'sawsbuckwinter') {
					pokemon.formeChange('Sawsbuck-Winter');
					this.add('-formechange', pokemon, 'Sawsbuck-Winter', '[msg]', '[from] ability: Climate Change');
					pokemon.addVolatile('formecheck');
					if (!pokemon.setType('Fire')) return;
					this.add('-start', pokemon, 'typechange', 'Fire', '[from] Climate Change');
					if (!pokemon.addType('Grass')) return;
					this.add('-start', pokemon, 'typeadd', 'Grass', '[from] Climate Change');
					if (!pokemon.volatiles['climateboost']) pokemon.addVolatile('climateboost');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memorynormal']) pokemon.removeVolatile('memorynormal');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memorywater']) pokemon.removeVolatile('memorywater');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memoryfire']) pokemon.removeVolatile('memoryfire');
					if (pokemon.volatiles['activechange'] && !pokemon.volatiles['memoryice'] && memcheck.onMemory !== 'Ice') pokemon.addVolatile('memoryice');
				}
			} else {
				if (pokemon.template.speciesid === 'sawsbucksummer' || pokemon.template.speciesid === 'sawsbuckautumn' || pokemon.template.speciesid === 'sawsbuckwinter') {
					pokemon.formeChange('Sawsbuck');
					this.add('-formechange', pokemon, 'Sawsbuck', '[msg]', '[from] ability: Climate Change');
					pokemon.addVolatile('formecheck');
					if (pokemon.volatiles['climateboost']) pokemon.removeVolatile('climateboost');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memoryfire']) pokemon.removeVolatile('memoryfire');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memorywater']) pokemon.removeVolatile('memorywater');
					if (pokemon.volatiles['activechange'] && pokemon.volatiles['memoryice']) pokemon.removeVolatile('memoryice');
					if (pokemon.volatiles['activechange'] && !pokemon.volatiles['memorynormal'] && memcheck.onMemory !== 'Normal') pokemon.addVolatile('memorynormal');
				}
			}
		},
		isClimate: true,
		id: "climatechange",
		name: "Climate Change",
		rating: 3.5,
		num: 246,
	},
	"soaringburst": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			delete this.effectData.forme;
		},
		onStart: function (pokemon) {
			if (pokemon.template.species !== 'Necrozma-Dawn-Wings' || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.item !== 'lightclay' && pokemon.template.speciesid !== 'necrozmaultra') {
				this.add('-message', "Necrozma is shining with a blinding light!");
				this.add('-activate', pokemon, 'ability: Soaring Burst');
				let template = this.getTemplate('Necrozma-Ultra');
				pokemon.formeChange(template);
				pokemon.baseTemplate = template;
				pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
				this.add('detailschange', pokemon, pokemon.details);
				this.add('-message', "" + pokemon.name + " transformed into its Ultra Forme!");
				pokemon.setAbility(template.abilities['0']);
				pokemon.baseAbility = pokemon.ability;
				pokemon.addVolatile('formecheck');
				pokemon.addVolatile('runnecrozmacheck');
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon) {
			if (pokemon.template.species !== 'Necrozma-Dawn-Wings' || pokemon.transformed || !pokemon.hp) return;
			if (!pokemon.volatiles['lightskytest'] && pokemon.volatiles['photoflag'] && pokemon.template.speciesid !== 'necrozmaultra') {
				this.add('-message', "Necrozma is shining with a blinding light!");
				this.add('-activate', pokemon, 'ability: Soaring Burst');
				let template = this.getTemplate('Necrozma-Ultra');
				pokemon.formeChange(template);
				pokemon.baseTemplate = template;
				pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
				this.add('detailschange', pokemon, pokemon.details);
				this.add('-message', "" + pokemon.name + " transformed into its Ultra Forme!");
				pokemon.setAbility(template.abilities['0']);
				pokemon.baseAbility = pokemon.ability;
				pokemon.addVolatile('formecheck');
			}
		},
		id: "soaringburst",
		name: "Soaring Burst",
		rating: 4,
		num: 250,
	},
	"searingburst": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			delete this.effectData.forme;
		},
		onStart: function (pokemon) {
			if (pokemon.template.species !== 'Necrozma-Dusk-Mane' || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.item !== 'lightclay' && pokemon.template.speciesid !== 'necrozmaultra') {
				this.add('-message', "Necrozma is shining with a blinding light!");
				this.add('-activate', pokemon, 'ability: Searing Burst');
				let template = this.getTemplate('Necrozma-Ultra');
				pokemon.formeChange(template);
				pokemon.baseTemplate = template;
				pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
				this.add('detailschange', pokemon, pokemon.details);
				this.add('-message', "" + pokemon.name + " transformed into its Ultra Forme!");
				pokemon.setAbility(template.abilities['0']);
				pokemon.baseAbility = pokemon.ability;
				pokemon.addVolatile('runnecrozmacheck');
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon) {
			if (pokemon.template.species !== 'Necrozma-Dusk-Mane' || pokemon.transformed || !pokemon.hp) return;
			if (!pokemon.volatiles['lightskytest'] && pokemon.volatiles['photoflag'] && pokemon.template.speciesid !== 'necrozmaultra') {
				this.add('-message', "Necrozma is shining with a blinding light!");
				this.add('-activate', pokemon, 'ability: Searing Burst');
				let template = this.getTemplate('Necrozma-Ultra');
				pokemon.formeChange(template);
				pokemon.baseTemplate = template;
				pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
				this.add('detailschange', pokemon, pokemon.details);
				this.add('-message', "" + pokemon.name + " transformed into its Ultra Forme!");
				pokemon.setAbility(template.abilities['0']);
				pokemon.baseAbility = pokemon.ability;
				pokemon.addVolatile('formecheck');
			}
		},
		id: "searingburst",
		name: "Searing Burst",
		rating: 4,
		num: 250,
	},
	"tempest": {
		desc: "Causes certain Pokemon to change based on weather.",
		shortDesc: "Causes certain Pokemon to change based on weather.",
		onStart: function (source) {
			delete this.effectData.forme;
			for (let i = 0; i < this.queue.length; i++) {
				if (this.queue[i].choice === 'runPrimal' && this.queue[i].pokemon === source && source.template.speciesid === 'kyogre') return;
				if (this.queue[i].choice !== 'runSwitch' && this.queue[i].choice !== 'runPrimal') break;
			}
			this.setWeather('raindance');
		},
		onUpdate: function (pokemon) {
			if (!pokemon.isActive || pokemon.baseTemplate.baseSpecies !== 'Tornadus' || pokemon.transformed) return;
			if (this.isWeather(['raindance', 'primordialsea'])) {
				if (pokemon.template.speciesid !== 'tornadustherian') {
					pokemon.formeChange('Tornadus-Therian');
					this.add('-formechange', pokemon, 'Tornadus-Therian', '[msg]', '[from] ability: Tempest');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid === 'tornadustherian') {
					pokemon.formeChange('Tornadus');
					this.add('-formechange', pokemon, 'Tornadus', '[msg]', '[from] ability: Tempest');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (!user.hasType('Water') && move.type === 'Water') {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		setRain: true,
		id: "tempest",
		name: "Tempest",
		rating: 3.5,
		num: 255,
	},
	"malleate": {
		desc: ".",
		shortDesc: ".",
		onModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Electric' && move.typeMod < 0) {
				this.debug('Malleate boost');
				return this.chainModify(2);
			}
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (attacker.template.baseSpecies !== 'Thundurus' || attacker.transformed || move.category === 'Status' || move.flags['noswap']) return;
			if (move.category === 'Status') return;
			let targetSpecies = (move.category === 'Special' ? 'Thundurus' : 'Thundurus-Therian');
			if (attacker.template.species !== targetSpecies && attacker.formeChange(targetSpecies)) {
				this.add('-formechange', attacker, targetSpecies, '[from] ability: Malleate');
				attacker.addVolatile('formecheck');
			}
		},
		id: "malleate",
		name: "Malleate",
		rating: 3.5,
		num: 256,
	},
	"ensemble": {
		desc: ".",
		shortDesc: ".",
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			let memcheck = attacker.getItem();
			if (attacker.template.baseSpecies !== 'Meloetta' || attacker.transformed || move.category === 'Status' || move.flags['noswap']) return;
			if (move.category === 'Status') return;
			let targetSpecies = (move.category === 'Special' ? 'Meloetta' : 'Meloetta-Pirouette');
			if (attacker.template.species !== targetSpecies && attacker.formeChange(targetSpecies)) {
				this.add('-formechange', attacker, targetSpecies, '[from] ability: Ensemble');
				attacker.addVolatile('formecheck');
				attacker.addVolatile('hidememmsgshort');
				if (attacker.volatiles['activechange'] && attacker.template.species === 'Meloetta' && !attacker.volatiles['memorypsychic']) {
					if (attacker.volatiles['memoryfighting']) attacker.removeVolatile('memoryfighting');
					if (memcheck.onMemory !== 'Psychic') attacker.addVolatile('memorypsychic');
				} else if (attacker.volatiles['activechange'] && attacker.template.species === 'Meloetta-Pirouette' && !attacker.volatiles['memoryfighting']) {
					if (attacker.volatiles['memorypsychic']) attacker.removeVolatile('memorypsychic');
					if (memcheck.onMemory !== 'Fighting') attacker.addVolatile('memoryfighting');
				}
			}
		},
		id: "ensemble",
		name: "Ensemble",
		rating: 4,
		num: 256,
	},
	"encorex": {
		desc: ".",
		shortDesc: ".",
		onAfterMoveSecondarySelf: function (source, target, move) {
			if (source && source === target && move && move.category === 'Status' && !move.ohko) {
				this.heal(source.maxhp / 20, source, source);
			}
		},
		id: "encorex",
		isNonstandard: true,
		name: "Encorex",
		rating: 4,
		num: 233,
	},
	"amplifier": {
		desc: "Amplifies the power of Sound Moves.",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move.flags['sound']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		id: "amplifier",
		name: "Amplifier",
		rating: 4,
		num: 253,
	},
	"luminouspower": {
		desc: "Amplifies the power of Moves if the Pokemon has any Positive Stat Boosts.",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.positiveBoosts()) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Psychic' && move.type === 'Dark' && typeMod > 0 && !move.flags['exempt']) {
				return 0;
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (target.hasType('Dark')) {
				this.debug('Luminous boost');
				return this.chainModify(1.5);
			}
		},
		id: "luminouspower",
		name: "Luminous Power",
		rating: 4,
		num: 253,
	},
	"oversight": {
		desc: "Amplifies the power of Sound Moves.",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === '???' && !pokemon.volatiles['oversightcheck'] && ((move.category === 'Physical') || move.category === 'Special')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon, basePower) {
			let bp = move.basePower;
			if ((move.type === 'Normal' && (bp <= 150 || move.isCharge)) && move.id !== 'naturalgift') {
				move.type = '???';
				pokemon.addVolatile('oversightcheck');
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "oversight",
		name: "Oversight",
		rating: 4,
		num: 253,
	},
	"oversightarchive": {
		desc: "Amplifies the power of Sound Moves.",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === '???') {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon, basePower) {
			let bp = move.basePower;
			if ((move.type === 'Normal' && bp <= 150) && move.id !== 'naturalgift') {
				move.type = '???';
				pokemon.addVolatile('oversightcheck');
			}
		},
		id: "oversightarchive",
		isNonstandard: true,
		name: "Oversight Archive",
		rating: 4,
		num: 253,
	},
	"customrecoilscript": {
		desc: ".",
		shortDesc: ".",
		onAfterMoveSecondarySelf: function (source, target, move) {
			if (source && source !== target && move && move.category !== 'Status' && !source.volatiles['activechange']) {
				this.damage(source.lastDamage / 3, source, source);
			}
		},
		id: "customrecoilscript",
		isNonstandard: true,
		name: "Custom Recoil Script",
		rating: 4,
		num: 253,
	},
	"psychoforce": {
		shortDesc: "This Pokemon's attacks that are not very effective on a target deal double damage. Ignores positive stat changes",
		onStart: function (pokemon) {
			pokemon.addVolatile('psychoforceflag');
			pokemon.addVolatile('mewtwoabilityflag');
			pokemon.addVolatile('psyforceendure');
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (target.volatiles['psyforceendure']) {
				this.add('-ability', target, 'Psycho Force');
				this.add('-anim', target, 'calmmind', target);
				this.add('-message', "" + target.name + "'s Psychic Powers are mitigating " + source.name + "'s power by 50\%!");
				this.debug('Psycho Force Neutralize');
				return this.chainModify(0.67);
			}
		},
		onAfterDamage: function (damage, target, source, effect) {
			if ((effect && effect.effectType === 'Move' && effect.id !== 'confused') && target.volatiles['psyforceendure']) {
				target.removeVolatile('psyforceendure');
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Psycho Force Boost');
				return damage * 1.5;
			} else if (move && move.typeMod > 0) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move, pokemon) {
			delete move.flags['contact'];
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Fighting'] = true;
			}
			let foundation = pokemon.getItem();
			if (foundation.isMemory && pokemon.volatiles['activechange'] && (move.type === 'Psychic' || move.type === 'Fighting')) return;
			if (pokemon.volatiles['mewtwobunused']) return;
			if ((move.type !== pokemon.types[0] && move.type !== pokemon.types[1]) && move.type !== foundation.onMemory && (move.category === 'Physical' || move.category === 'Special')) {
				move.hasSTAB = true;
				move.stab = 1.3;
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && ((move.type === 'Fairy') && !move.flags['exempt']) && typeMod > 0) {
				return 0;
			}
		},
		onTryMove: function (pokemon) {
			if (pokemon.template.species === 'Mewtwo' || pokemon.template.species === 'Mewtwo-Mega-X' || pokemon.template.species === 'Mewtwo-Mega-Y') {
				return;
			}
			this.add('-message', "The burden of Psycho Force is too great to bear!");
			if (pokemon.template.species !== 'Mewtwo' && pokemon.template.species !== 'Mewtwo-Mega-X' && pokemon.template.species !== 'Mewtwo-Mega-Y') {
				this.add('-fail', pokemon, 'ability: Psycho Force');
				return null;
			}
			this.add('-fail', pokemon, 'ability: Psycho Force');
			this.damage(pokemon.maxhp / 4, pokemon);
			return null;
		},
		onBoost: function (boost, target, source, effect) {
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Psycho Force", "[of] " + target);
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa) {
			return this.chainModify(1.2);
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (pokemon, target, move) {
			pokemon.addVolatile('fullburst');
		},
		isUnbreakable: true,
		isMewtwo: true,
		id: "psychoforce",
		name: "Psycho Force",
		rating: 5,
		num: 245,
	},
	"psychicassault": {
		shortDesc: "If this Pokemon is at full HP, damage taken from attacks is halved.",
		onStart: function (pokemon) {
			pokemon.addVolatile('psychicassaultflag');
			pokemon.addVolatile('mewtwoabilityflag');
			pokemon.addVolatile('assaultboost');
		},
		onModifyMove: function (move, pokemon) {
			if (move && move.type === 'Fairy') move.hasSTAB = true;
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move && move.flags['charity'] && !move.flags['charityblock'] && move.id === 'pressurewave') {
				pokemon.switchFlag = true;
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && ((move.type === 'Dragon') && !move.flags['exempt'])) {
				return -1;
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if ((basePower <= 150 && (!move.flags['psyasoff'] && !move.flags['burst'])) || (move.id === 'psystrike' || move.id === 'prismstrike') || move.flags['scalar']) {
				this.debug('Psychic Assault boost');
				return this.chainModify(1.5);
			}
		},
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk) {
			return this.chainModify(1.5);
		},
		onTryMove: function (pokemon) {
			if (pokemon.template.species === 'Mewtwo' || pokemon.template.species === 'Mewtwo-Mega-X' || pokemon.template.species === 'Mewtwo-Mega-Y') {
				return;
			}
			this.add('-message', "The burden of Psychic Assault is too great to bear!");
			if (pokemon.template.species !== 'Mewtwo' && pokemon.template.species !== 'Mewtwo-Mega-X' && pokemon.template.species !== 'Mewtwo-Mega-Y') {
				this.add('-fail', pokemon, 'ability: Psychic Assault');
				return null;
			}
			this.add('-fail', pokemon, 'ability: Psychic Assault');
			this.damage(pokemon.maxhp / 4, pokemon);
			return null;
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Psychic Assault", "[of] " + target);
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move && move.flags['charity'] && !move.flags['charityblock'] && move.id === 'psychicorder') {
				pokemon.switchFlag = true;
			}
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (pokemon, target, move) {
			pokemon.addVolatile('fullburst');
		},
		isUnbreakable: true,
		isMewtwo: true,
		id: "psychicassault",
		name: "Psychic Assault",
		rating: 5,
		num: 257,
	},
	"psychicpower": {
		shortDesc: "This Pokemon's attacks that are super effective against the target do 1.3x damage.",
		onStart: function (pokemon) {
			pokemon.addVolatile('mewtwoabilityflag');
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.volatiles['choicelock'] || pokemon.volatiles['generallock']) {
				return this.chainModify([0x1199, 0x1000]);
			}
		},
		onTryMove: function (pokemon) {
			if (pokemon.template.species === 'Mewtwo' || pokemon.template.species === 'Mewtwo-Mega-X' || pokemon.template.species === 'Mewtwo-Mega-Y') {
				return;
			}
			this.add('-message', "The burden of Psychic Power is too great to bear!");
			if (pokemon.template.species !== 'Mewtwo' && pokemon.template.species !== 'Mewtwo-Mega-X' && pokemon.template.species !== 'Mewtwo-Mega-Y') {
				this.add('-fail', pokemon, 'ability: Psychic Power');
				return null;
			}
			this.add('-fail', pokemon, 'ability: Psychic Power');
			this.damage(pokemon.maxhp / 4, pokemon);
			return null;
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'brn') {
				return false;
			}
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (pokemon, target, move) {
			pokemon.addVolatile('fullburst');
		},
		isUnbreakable: true,
		isMewtwo: true,
		id: "psychicpower",
		name: "Psychic Power",
		rating: 4,
		num: 233,
	},
	"hightenedmind": {
		desc: "If this Pokemon loses its held item for any reason, its Speed is doubled. This boost is lost if it switches out or gains a new item or Ability.",
		shortDesc: "Speed is doubled on held item loss; boost is lost if it switches, gets new item/Ability.",
		onStart: function (pokemon) {
			pokemon.addVolatile('mewtwoabilityflag');
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).category === 'Status') {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		onAfterUseItem: function (item, pokemon) {
			if (pokemon !== this.effectData.target) return;
			pokemon.addVolatile('hightenedmind');
			pokemon.addVolatile('mindfirstturn');
			this.add('-ability', pokemon, 'Hightened Mind');
			this.add('-message', "" + pokemon.name + " is lost in its thoughts...");
		},
		onTakeItem: function (item, pokemon) {
			pokemon.addVolatile('hightenedmind');
			pokemon.addVolatile('mindfirstturn');
			this.add('-ability', pokemon, 'Hightened Mind');
			this.add('-message', "" + pokemon.name + " is lost in its thoughts...");
		},
		onEnd: function (pokemon) {
			pokemon.removeVolatile('hightenedmind');
			if (pokemon.volatiles['highmind2']) pokemon.removeVolatile('highmind2');
		},
		effect: {
			onModifySpe: function (spe, pokemon) {
				if (!pokemon.item) {
					return this.chainModify(1.5);
				}
			},
			onModifyAtk: function (atk, pokemon) {
				if (!pokemon.item && pokemon.boosts.atk < 1) {
					return this.chainModify(1.5);
				}
			},
			onModifySpA: function (spa, pokemon) {
				if (!pokemon.item && pokemon.boosts.spa < 1) {
					return this.chainModify(1.5);
				}
			},
			onBeforeMovePriority: 0.5,
			onBeforeMove: function (pokemon, target, move) {
				pokemon.addVolatile('fullburst');
			},
		},
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && !source.item && source.volatiles['hightenedmind'] && !source.volatiles['mindfirstturn'] && (!source.volatiles['highmind1'] && !source.volatiles['highmind2'])) {
				source.addVolatile('highmind1');
			} else if (effect && effect.effectType === 'Move' && !source.item && source.volatiles['hightenedmind'] && !source.volatiles['mindfirstturn'] && (source.volatiles['highmind1'] && !source.volatiles['highmind2'])) {
				source.removeVolatile('hightenedmind');
				source.addVolatile('highmind2');
				this.add('-ability', source, 'Hightened Mind');
				this.add('-message', "" + source.name + "'s power has returned to normal levels!");
			}
		},
		isMewtwo: true,
		id: "hightenedmind",
		name: "Hightened Mind",
		rating: 4.5,
		num: 84,
	},
	"oppression": {
		desc: "If this Pokemon is the target of an opposing Pokemon's move, that move loses one additional PP.",
		shortDesc: "If this Pokemon is the target of a foe's move, that move loses one additional PP.",
		onStart: function (pokemon) {
			pokemon.addVolatile('mewtwoabilityflag');
		},
		onDeductPP: function (target, source) {
			if (target.side === source.side) return;
			return 1;
		},
		onBasePowerPriority: 8,
		onFoeBasePower: function (basePower, attacker, defender, move) {
			if (this.effectData.target !== defender || attacker.hasAbility(['psychicpower', 'psychoforce', 'psychicassault', 'oppression'])) return;
			if (this.willMove(defender)) {
				this.debug('Oppression deboost');
				return this.chainModify(0.67);
			}
		},
		onTryMove: function (pokemon) {
			if (pokemon.template.species === 'Mewtwo' || pokemon.template.species === 'Mewtwo-Mega-X' || pokemon.template.species === 'Mewtwo-Mega-Y') {
				return;
			}
			this.add('-message', "The burden of Oppression is too great to bear!");
			if (pokemon.template.species !== 'Mewtwo' && pokemon.template.species !== 'Mewtwo-Mega-X' && pokemon.template.species !== 'Mewtwo-Mega-Y') {
				this.add('-fail', pokemon, 'ability: Oppression');
				return null;
			}
			this.add('-fail', pokemon, 'ability: Oppression');
			this.damage(pokemon.maxhp / 4, pokemon);
			return null;
		},
		isUnbreakable: true,
		isMewtwo: true,
		id: "oppression",
		isNonstandard: true,
		name: "Oppression",
		rating: 4,
		num: 46,
	},
	"progenitor": {
		desc: ".",
		shortDesc: ".",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (pokemon.moveset[3]) {
				let genes = this.getMove(pokemon.moveset[3].id).category;
				if (pokemon.moveset[0]) {
					let type = this.getMove(pokemon.moveset[0].id).type;
					if (!item.isMemory && genes === 'Status') {
						if (pokemon.hasType(type) || !pokemon.setType(type)) return false;
						this.add('-start', pokemon, 'typechange', type, '[from] Genesis');
					}
				}
			}
			if (pokemon.moveset[0] && !pokemon.moveset[1]) {
				let gene = this.getMove(pokemon.moveset[0].id).type;
				this.add('-message', "" + pokemon.name + " is changing the opposing " + gene + "-Type Moves into Resistances!");
			}
			if (pokemon.moveset[1] && !pokemon.moveset[0]) {
				let genes = this.getMove(pokemon.moveset[1].id).type;
				this.add('-message', "" + pokemon.name + " is changing the opposing " + genes + "-Type Moves into Resistances!");
			}
			if (pokemon.moveset[0] && pokemon.moveset[1]) {
				let origin = this.getMove(pokemon.moveset[0].id).type;
				let origins = this.getMove(pokemon.moveset[1].id).type;
				this.add('-message', "" + pokemon.name + " is changing the opposing " + origin + "-Type and " + origins + "-Type Moves into Resistances!");
			}
		},
		onModifyMove: function (move, pokemon) {
			if (move && (move.category === 'Physical' || move.category === 'Special')) move.hasSTAB = true;
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (target.moveset[0]) {
				let movements = this.getMove(target.moveset[0].id).type;
				if (move && move.effectType === 'Move' && move.type === movements && !move.flags['exempt']) {
					return -1;
				}
			}
			if (target.moveset[1]) {
				let momentum = this.getMove(target.moveset[1].id).type;
				if (move && move.effectType === 'Move' && move.type === momentum && !move.flags['exempt']) {
					return -1;
				}
			}
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (pokemon.positiveBoosts()) {
					if ((this.getMove(moves[i].move).flags['heal'] || this.getMove(moves[i].move).flags['autoheal']) && !this.getMove(moves[i].move).flags['healswitch']) {
						pokemon.disableMove(moves[i].id);
					}
				}
			}
		},
		id: "progenitor",
		name: "Progenitor",
		isMyuu: true,
		rating: 4,
		num: 88,
	},
	"pollution": {
		desc: ".",
		shortDesc: ".",
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (!pokemon.hp) return;
			for (let i = 0; i < pokemon.side.foe.active.length; i++) {
				let target = pokemon.side.foe.active[i];
				if (!target || !target.hp) continue;
				if (target.status === 'psn' || target.status === 'tox') {
					this.damage(target.maxhp / 5, target, pokemon);
				}
			}
		},
		id: "pollution",
		name: "Pollution",
		rating: 3,
		num: 258,
	},
	"dragonascension": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			delete this.effectData.forme;
		},
		onUpdate: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Rayquaza' || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.item === 'dragongem' || pokemon.item === 'flyinggem') {
				if (pokemon.template.speciesid !== 'rayquazamega') {
					this.add('-message', "Rayquaza is transforming!");
					this.add('-activate', pokemon, 'ability: Dragon Ascent');
					let template = this.getTemplate('Rayquaza-Mega');
					pokemon.formeChange(template);
					pokemon.baseTemplate = template;
					pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
					this.add('detailschange', pokemon, pokemon.details);
					this.add('-message', "" + pokemon.name + " Mega Evolved into Mega Rayquaza!");
					pokemon.setAbility(template.abilities['0']);
					pokemon.baseAbility = pokemon.ability;
					pokemon.addVolatile('formecheck');
				}
			}
		},
		id: "dragonascension",
		isNonstandard: true,
		name: "Dragon Ascension",
		rating: 4,
		num: 259,
	},
	"shadowdraw": {
		shortDesc: ".",
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 5);
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category !== 'Status') {
				this.heal(pokemon.lastDamage / 4, pokemon, pokemon, null, null);
			}
			if (target.volatiles['shadowdraw']) target.removeVolatile('shadowdraw');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['shadowdraw']) defender.addVolatile('shadowdraw');
			if (move.type === 'Ghost') move.flags['exempt'] = true;
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target.hp < target.maxhp) return;
			if (target === source || move.isDrawn || move.priority < 1) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.isDrawn = true;
			this.useMove(newMove, target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "shadowdraw",
		name: "Shadow Draw",
		rating: 3.5,
		num: 260,
	},
	"frenetic": {
		shortDesc: ".",
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['frenetic']) target.removeVolatile('frenetic');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['frenetic']) defender.addVolatile('frenetic');
			if (move.type === 'Electric' && (defender.hasType('Dragon') || defender.hasType('Poison'))) move.flags['exempt'] = true;
		},
		id: "frenetic",
		name: "Frenetic",
		rating: 3.5,
		num: 260,
	},
	"shadoweater": {
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			let condition = source.getAbility();
			if (source.positiveBoosts()) {
				this.debug('Shadow Neutralize');
				return this.chainModify(0.5);
			}
		},
		onAfterDamage: function (damage, target, source, move) {
			if (move && (move.category === 'Physical' || move.category === 'Special')) {
				if (source.positiveBoosts()) {
					source.addVolatile('shadeatboost');
					source.clearBoosts();
					this.add('-clearboost', source);
				}
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.target !== 'self') {
				target.addVolatile('shadeatfactor');
			}
		},
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 4);
		},
		id: "shadoweater",
		name: "Shadow Eater",
		switchHealing: true,
		rating: 3,
		num: 111,
	},
	"spectralforce": {
		shortDesc: ".",
		onStart: function (pokemon) {
			pokemon.addVolatile('energypartb');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['shadoweffect']) defender.addVolatile('shadoweffect');
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if ((move && move.type === 'Ghost') && ((move.category === 'Physical') || move.category === 'Special')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Ghost'] = true;
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category !== 'Status') {
				this.heal(pokemon.lastDamage / 16, pokemon, pokemon, null, null);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "spectralforce",
		name: "Spectral Force",
		rating: 3.5,
		num: 260,
	},
	"thousandarms": {
		desc: ".",
		shortDesc: ".",
		onPrepareHit: function (source, target, move) {
			if (move.id in {iceball: 1, rollout: 1}) return;
			if (move.category !== 'Status' && !move.selfdestruct && !move.multihit && !move.flags['charge'] && !move.flags['preset'] && !move.spreadHit && !move.isZ) {
				move.multihit = 3;
				source.addVolatile('thousandarms');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower) {
				if (this.effectData.hit) {
					this.effectData.hit++;
					return this.chainModify(0.25);
				} else {
					this.effectData.hit = 1;
				}
			},
			onSourceModifySecondaries: function (secondaries, target, source, move) {
				if (move.id === 'secretpower' && this.effectData.hit < 2) {
					// hack to prevent accidentally suppressing King's Rock/Razor Fang
					return secondaries.filter(effect => effect.volatileStatus === 'flinch');
				}
			},
		},
		id: "thousandarms",
		name: "Thousand Arms",
		rating: 5,
		num: 261,
	},
	"speedtouch": {
		shortDesc: "This Pokemon's Speed is raised by 1 stage after it is damaged by a move.",
		onAfterDamage: function (damage, target, source, effect) {
			if (effect && effect.effectType === 'Move' && effect.id !== 'confused') {
				this.boost({spe:1});
			}
		},
		id: "speedtouch",
		name: "Speed Touch",
		rating: 3,
		num: 262,
	},
	"dragonarmor": {
		desc: ".",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.positiveBoosts() && (move.type === 'Dragon' || move.type === 'Ground')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onFoeBasePower: function (basePower, attacker, defender, move) {
			if (this.effectData.target !== defender) return;
			if (move && move.flags['choiced']) {
				return this.chainModify(0.33);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Ice' || move.type === 'Rock') {
				this.debug('Dragon Armor neutralize');
				return this.chainModify(0.5);
			}
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'recoil' && this.activeMove.id !== 'struggle') return null;
		},
		id: "dragonarmor",
		name: "Dragon Armor",
		rating: 3.5,
		num: 263,
	},
	"pureforce": {
		shortDesc: "This Pokemon's Special Attack is doubled.",
		onModifySpAPriority: 5,
		onModifySpA: function (spa) {
			return this.chainModify(2);
		},
		id: "pureforce",
		isNonstandard: true,
		name: "Pure Force",
		rating: 5,
		num: 251,
	},
	"accumulate": {
		desc: "Transforms Golett if it is holding a Cell Battery.",
		shortDesc: "Transforms Golett if it has Cell Battery.",
		onStart: function (pokemon) {
			delete this.effectData.forme;
		},
		onUpdate: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Golett' || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.item === 'cellbattery') {
				if (pokemon.template.speciesid !== 'golurk') {
					this.add('-message', "Golett is reacting to the Battery's charge!");
					this.add('-activate', pokemon, 'ability: Accumulate');
					let template = this.getTemplate('Golurk');
					pokemon.formeChange(template);
					pokemon.baseTemplate = template;
					pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
					this.add('detailschange', pokemon, pokemon.details);
					this.add('-message', "" + pokemon.name + " transformed into Golurk!");
					pokemon.setAbility(template.abilities['0']);
					pokemon.baseAbility = pokemon.ability;
					pokemon.addVolatile('formecheck');
				}
			}
		},
		id: "accumulate",
		isNonstandard: true,
		name: "Accumulate",
		rating: 4,
		num: 252,
	},
	"compactarmor": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if ((move.category === 'Physical' || move.flags['hitsdef']) && !move.flags['descale'] && !move.flags['hitsspd'] && target.hp >= target.maxhp / 2) {
				this.debug('Compact Armor Neutralize');
				return this.chainModify(0.67);
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if ((move && move.type === 'Steel') && ((move.category === 'Physical') || move.category === 'Special')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "compactarmor",
		name: "Compact Armor",
		rating: 4,
		num: 253,
	},
	"unbreakable": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onSourceModifyDamage: function (damage, source, target, move) {
			let mod = 1;
			if (move.flags['contact']) mod /= 4;
			return this.chainModify(mod);
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && (move.type === 'Fighting' || move.type === 'Steel')) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "unbreakable",
		name: "Unbreakable",
		rating: 4,
		num: 253,
	},
	"psychosis": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && (move.type === 'Psychic')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "psychosis",
		name: "Psychosis",
		rating: 2.5,
		num: 253,
	},
	"idealist": {
		desc: ".",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && pokemon.hp >= pokemon.maxhp) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Electric' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Idealist boost');
				return this.chainModify(1.2);
			}
		},
		onModifyMove: function (move, pokemon) {
			if (move.secondaries) {
				delete move.secondaries;
			}
		},
		id: "idealist",
		name: "Idealist",
		isDreaming: true,
		rating: 4,
		num: 253,
	},
	"realist": {
		desc: ".",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && pokemon.hp >= pokemon.maxhp) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Fire' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'brn' && status.id !=='psn' && status.id !='tox') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Realist');
			return false;
		},
		onModifyMove: function (move, pokemon) {
			if (move.secondaries) {
				delete move.secondaries;
			}
		},
		id: "realist",
		name: "Realist",
		isDreaming: true,
		rating: 4,
		num: 253,
	},
	"battlearmor": {
		shortDesc: "This Pokemon cannot be struck by a critical hit.",
		onBoost: function (boost, target, source, effect) {
			if (source && target !== source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Battle Armor", "[of] " + target);
		},
		onCriticalHit: false,
		id: "battlearmor",
		name: "Battle Armor",
		rating: 1,
		num: 4,
	},
	"battlebond": {
		desc: "If this Pokemon is a Greninja, it transforms into Ash-Greninja after knocking out a Pokemon. As Ash-Greninja, its Water Shuriken has 20 base power and always hits 3 times.",
		shortDesc: "After KOing a Pokemon: becomes Ash-Greninja, Water Shuriken: 20 power, hits 3x.",
		onStart: function (pokemon) {
			if (!pokemon.volatiles['bondboost']) {
				pokemon.addVolatile('bondboost');
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Battle Bond boost');
				return this.chainModify(1.3);
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			let item = pokemon.getItem();
			if (!item.isPlate) return;
			if (move && (move.category === 'Physical' || move.category === 'Special')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onModifyMove: function (move) {
			move.ignoreWeather = true;
		},
		id: "battlebond",
		name: "Battle Bond",
		rating: 3,
		num: 210,
	},
	"oldbbond": {
		desc: "If this Pokemon is a Greninja, it transforms into Ash-Greninja after knocking out a Pokemon. As Ash-Greninja, its Water Shuriken has 20 base power and always hits 3 times.",
		shortDesc: "After KOing a Pokemon: becomes Ash-Greninja, Water Shuriken: 20 power, hits 3x.",
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && source.template.speciesid === 'greninja' && !source.transformed && source.side.foe.pokemonLeft) {
				this.add('-activate', source, 'ability: Battle Bond');
				let template = this.getTemplate('Greninja-Ash');
				source.formeChange(template);
				source.baseTemplate = template;
				source.details = template.species + (source.level === 100 ? '' : ', L' + source.level) + (source.gender === '' ? '' : ', ' + source.gender) + (source.set.shiny ? ', shiny' : '');
				this.add('detailschange', source, source.details);
				this.add('-message', "" + source.name + " became Ash-Greninja! (placeholder)"); // TODO: -bond
				pokemon.addVolatile('formecheck');
			}
		},
		onModifyMove: function (move, attacker) {
			if (move.id === 'watershuriken' && attacker.template.species === 'Greninja-Ash') {
				move.multihit = 3;
			}
		},
		id: "oldbbond",
		isNonstandard: true,
		name: "Old Battle Bond",
		rating: 3,
		num: 210,
	},
	"beastboost": {
		desc: "This Pokemon's highest stat is raised by 1 stage if it attacks and knocks out another Pokemon.",
		shortDesc: "This Pokemon's highest stat is raised by 1 if it attacks and KOes another Pokemon.",
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && !source.volatiles['beastboostcheck']) {
				let stat = 'atk';
				let bestStat = 0;
				for (let i in source.stats) {
					if (source.stats[i] > bestStat) {
						stat = i;
						bestStat = source.stats[i];
					}
				}
				this.boost({[stat]:1}, source);
				source.addVolatile('beastboostcheck');
			}
		},
		id: "beastboost",
		name: "Beast Boost",
		rating: 3.5,
		num: 224,
	},
	"berserk": {
		desc: "This Pokemon's Special Attack is raised by 1 stage when it reaches 1/2 or less of its maximum HP.",
		shortDesc: "This Pokemon's Sp. Atk is raised by 1 when it reaches 1/2 or less of its max HP.",
		onAfterDamage: function (damage, target, source, move) {
			if (!target.hp || !damage || move.effectType !== 'Move') return;
			if (target.hp <= target.maxhp / 2 && target.hp + damage > target.maxhp / 2) {
				this.boost({spa: 1});
			}
		},
		id: "berserk",
		name: "Berserk",
		rating: 2.5,
		num: 201,
	},
	"bigpecks": {
		shortDesc: "Prevents other Pokemon from lowering this Pokemon's Defense stat stage.",
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			if (boost['def'] && boost['def'] < 0) {
				delete boost['def'];
				if (!effect.secondaries) this.add("-fail", target, "unboost", "Defense", "[from] ability: Big Pecks", "[of] " + target);
			}
		},
		id: "bigpecks",
		name: "Big Pecks",
		rating: 0.5,
		num: 145,
	},
	"blaze": {
		desc: "When this Pokemon has 1/3 or less of its maximum HP, rounded down, its attacking stat is multiplied by 1.5 while using a Fire-type attack.",
		shortDesc: "When this Pokemon has 1/3 or less of its max HP, its Fire attacks do 1.5x damage.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, attacker, defender, move) {
			if (move.type === 'Fire' && attacker.hp <= attacker.maxhp / 3) {
				this.debug('Blaze boost');
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (atk, attacker, defender, move) {
			if (move.type === 'Fire' && attacker.hp <= attacker.maxhp / 3) {
				this.debug('Blaze boost');
				return this.chainModify(1.5);
			}
		},
		id: "blaze",
		name: "Blaze",
		rating: 2,
		num: 66,
	},
	"bulletproof": {
		desc: "This Pokemon is immune to ballistic moves. Ballistic moves include Bullet Seed, Octazooka, Barrage, Rock Wrecker, Zap Cannon, Acid Spray, Aura Sphere, Focus Blast, and all moves with Ball or Bomb in their name.",
		shortDesc: "Makes user immune to ballistic moves (Shadow Ball, Sludge Bomb, Focus Blast, etc).",
		onTryHit: function (pokemon, target, move) {
			if (move.flags['bullet']) {
				this.add('-immune', pokemon, '[msg]', '[from] ability: Bulletproof');
				return null;
			}
		},
		id: "bulletproof",
		name: "Bulletproof",
		rating: 3,
		num: 171,
	},
	"cheekpouch": {
		desc: "If this Pokemon eats a Berry, it restores 1/3 of its maximum HP, rounded down, in addition to the Berry's effect.",
		shortDesc: "If this Pokemon eats a Berry, it restores 1/3 of its max HP after the Berry's effect.",
		onEatItem: function (item, pokemon) {
			this.heal(pokemon.maxhp / 2);
		},
		id: "cheekpouch",
		name: "Cheek Pouch",
		rating: 2,
		num: 167,
	},
	"ripen": {
		desc: "If this Pokemon eats a Berry, it restores 1/3 of its maximum HP, rounded down, in addition to the Berry's effect.",
		shortDesc: "If this Pokemon eats a Berry, it restores 1/3 of its max HP after the Berry's effect.",
		onEatItem: function (item, pokemon) {
			this.heal(pokemon.maxhp / 2);
		},
		id: "ripen",
		name: "Ripen",
		rating: 2,
		num: 167,
	},
	"chlorophyll": {
		shortDesc: "If Sunny Day is active, this Pokemon's Speed is doubled.",
		onModifySpe: function (spe) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				return this.chainModify(2);
			}
		},
		id: "chlorophyll",
		name: "Chlorophyll",
		rating: 2.5,
		num: 34,
	},
	"clearbody": {
		shortDesc: "Prevents other Pokemon from lowering this Pokemon's stat stages.",
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Clear Body", "[of] " + target);
		},
		id: "clearbody",
		name: "Clear Body",
		rating: 2,
		num: 29,
	},
	"cloudnine": {
		shortDesc: "While this Pokemon is active, the effects of weather conditions are disabled.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Cloud Nine');
		},
		suppressWeather: true,
		id: "cloudnine",
		name: "Cloud Nine",
		rating: 3,
		num: 13,
	},
	"colorchange": {
		desc: "This Pokemon's type changes to match the type of the last move that hit it, unless that type is already one of its types. This effect applies after all hits from a multi-hit move; Sheer Force prevents it from activating if the move has a secondary effect.",
		shortDesc: "This Pokemon's type changes to the type of a move it's hit by, unless it has the type.",
		onAfterMoveSecondary: function (target, source, move) {
			let type = move.type;
			if (target.isActive && move.effectType === 'Move' && move.category !== 'Status' && type !== '???' && !target.hasType(type)) {
				if (!target.setType(type)) return false;
				this.add('-start', target, 'typechange', type, '[from] Color Change');

				if (target.side.active.length === 2 && target.position === 1) {
					// Curse Glitch
					const decision = this.willMove(target);
					if (decision && decision.move.id === 'curse') {
						decision.targetLoc = -1;
						decision.targetSide = target.side;
						decision.targetPosition = 0;
					}
				}
			}
		},
		id: "colorchange",
		name: "Color Change",
		rating: 1,
		num: 16,
	},
	"comatose": {
		shortDesc: "This Pokemon cannot be statused, and is considered to be asleep.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Comatose');
		},
		onSetStatus: function (status, target, source, effect) {
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Comatose');
			return false;
		},
		// Permanent sleep "status" implemented in the relevant sleep-checking effects
		isUnbreakable: true,
		id: "comatose",
		name: "Comatose",
		rating: 3,
		num: 213,
	},
	"competitive": {
		desc: "This Pokemon's Special Attack is raised by 2 stages for each of its stat stages that is lowered by an opposing Pokemon.",
		shortDesc: "This Pokemon's Sp. Atk is raised by 2 for each of its stats that is lowered by a foe.",
		onAfterEachBoost: function (boost, target, source) {
			if (!source || target.side === source.side) {
				return;
			}
			let statsLowered = false;
			for (let i in boost) {
				if (boost[i] < 0) {
					statsLowered = true;
				}
			}
			if (statsLowered) {
				this.boost({spa: 2}, null, null, null, true);
			}
		},
		id: "competitive",
		name: "Competitive",
		rating: 2.5,
		num: 172,
	},
	"compoundeyes": {
		shortDesc: "This Pokemon's moves have their accuracy multiplied by 1.3.",
		onSourceModifyAccuracy: function (accuracy) {
			if (typeof accuracy !== 'number') return;
			this.debug('compoundeyes - enhancing accuracy');
			return accuracy * 1.3;
		},
		id: "compoundeyes",
		name: "Compound Eyes",
		rating: 3.5,
		num: 14,
	},
	"contrary": {
		shortDesc: "If this Pokemon has a stat stage raised it is lowered instead, and vice versa.",
		onBoost: function (boost) {
			for (let i in boost) {
				boost[i] *= -1;
			}
		},
		id: "contrary",
		name: "Contrary",
		rating: 4,
		num: 126,
	},
	"corrosion": {
		shortDesc: "This Pokemon can poison or badly poison other Pokemon regardless of their typing.",
		// Implemented in battle-engine.js:BattlePokemon#setStatus
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Poison'] = true;
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Poison' && move.typeMod < 0) {
				this.debug('Corrosion boost');
				return this.chainModify(1.5);
			}
		},
		id: "corrosion",
		name: "Corrosion",
		rating: 2.5,
		num: 212,
	},
	"cursedbody": {
		desc: "If this Pokemon is hit by an attack, there is a 30% chance that move gets disabled unless one of the attacker's moves is already disabled.",
		shortDesc: "If this Pokemon is hit by an attack, there is a 30% chance that move gets disabled.",
		onAfterDamage: function (damage, target, source, move) {
			if (!source || source.volatiles['disable']) return;
			if (source !== target && move && move.effectType === 'Move' && !move.isFutureMove) {
				if (this.random(10) < 3) {
					source.addVolatile('disable', this.effectData.target);
				}
			}
		},
		id: "cursedbody",
		name: "Cursed Body",
		rating: 2,
		num: 130,
	},
	"cutecharm": {
		desc: "There is a 30% chance a Pokemon making contact with this Pokemon will become infatuated if it is of the opposite gender.",
		shortDesc: "30% chance of infatuating Pokemon of the opposite gender if they make contact.",
		onAfterDamage: function (damage, target, source, move) {
			if (move && move.flags['contact']) {
				if (this.random(10) < 3) {
					source.addVolatile('attract', this.effectData.target);
				}
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			let mod = 1;
			if (move.flags['contact']) mod /= 4;
			return this.chainModify(mod);
		},
		id: "cutecharm",
		name: "Cute Charm",
		rating: 3,
		num: 56,
	},
	"damp": {
		desc: "While this Pokemon is active, Self-Destruct, Explosion, and the Ability Aftermath are prevented from having an effect.",
		shortDesc: "While this Pokemon is active, Self-Destruct, Explosion, and Aftermath have no effect.",
		id: "damp",
		onAnyTryMove: function (target, source, effect) {
			if (effect.id === 'selfdestruct' || effect.id === 'explosion') {
				this.attrLastMove('[still]');
				this.add('cant', this.effectData.target, 'ability: Damp', effect, '[of] ' + target);
				return false;
			}
		},
		onAnyDamage: function (damage, target, source, effect) {
			if (effect && effect.id === 'aftermath') {
				return false;
			}
		},
		name: "Damp",
		rating: 1,
		num: 6,
	},
	"dancer": {
		desc: "After another Pokemon uses a dance move, this Pokemon uses the same move. Moves used by this Ability cannot be copied again.",
		shortDesc: "After another Pokemon uses a dance move, this Pokemon uses the same move.",
		id: "dancer",
		onAnyAfterMove: function (source, target, move) {
			if (!this.effectData.target.hp || source === this.effectData.target) return;
			if (move.id.includes('dance') && move.id !== 'raindance') {
				this.faintMessages();
				this.add('-activate', this.effectData.target, 'ability: Dancer');
				this.useMove(move, this.effectData.target);
			}
		},
		name: "Dancer",
		rating: 2.5,
		num: 216,
	},
	"darkaura": {
		desc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		shortDesc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === 'Dark' && !move.flags['noauraboost']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category !== 'Status' && move.priority < 1) {
				this.heal(pokemon.lastDamage / 10, pokemon, pokemon, null, null);
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		id: "darkaura",
		name: "Dark Aura",
		rating: 3,
		num: 186,
	},
	"superdarkaura": {
		desc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		shortDesc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Super Dark Aura');
			this.add('-message', "" + pokemon.name + " shrouds the land in darkness!");
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === 'Dark' && !move.flags['noauraboost']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category !== 'Status' && move.priority < 1) {
				this.heal(pokemon.lastDamage / 8, pokemon, pokemon, null, null);
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.target !== 'self') {
				target.addVolatile('darkaurafactor');
			}
		},
		onFaint: function (pokemon) {
			let test = pokemon.side.foe;
			this.add('-ability', pokemon, 'Super Dark Aura');
			this.add('-message', "" + pokemon.name + " leaves behind a token of its wrath!");
			test.addSideCondition('spikes', pokemon.side.foe, pokemon, null, null);
			test.addSideCondition('spikes', pokemon.side.foe, pokemon, null, null);
			test.addSideCondition('spikes', pokemon.side.foe, pokemon, null, null);
		},
		isMemorized: true,
		id: "superdarkaura",
		name: "Super Dark Aura",
		rating: 5,
		num: 186,
	},
	"frostaura": {
		shortDesc: "This Pokemon cannot be paralyzed. Gaining this Ability while paralyzed cures it.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Frost Aura');
			this.add('-message', "" + pokemon.name + " is radiating a frosty aura!");
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Ice' && (source === this.effectData.target || target === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === 'Ice') {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'frz') {
				this.add('-activate', pokemon, 'ability: Frost Aura');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'frz') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Frost Aura');
			return false;
		},
		id: "frostaura",
		name: "Frost Aura",
		rating: 3,
		num: 7,
	},
	"belowfreezing": {
		shortDesc: "While this Pokemon is active, the effects of weather conditions are disabled.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move && move.type === 'Ice' && attacker.item === 'snowball') {
				this.debug('Below Freezing Snowball boost');
				return this.chainModify([0x1666, 0x1000]);
			} else if (move && move.type === 'Ice' && attacker.item !== 'snowball') {
				this.debug('Below Freezing boost');
				return this.chainModify([0x1333, 0x1000]);
			} 
		},
		id: "belowfreezing",
		name: "Below Freezing",
		rating: 3,
		num: 267,
	},
	"neuroforce": {
		shortDesc: "This Pokemon's attacks that are super effective against the target do 1.2x damage.",
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Neuroforce boost');
				return this.chainModify(1.5);
			} else if (move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move && move.category !== 'Status' && move.priority >= 1) {
				return this.chainModify(0.75);
			}
		},
		onModifyMove: function (move, pokemon) {
			let foundation = pokemon.getItem();
			if (pokemon.template.species !== 'Necrozma-Ultra') return;
			if ((move.type === 'Ghost' || move.type === 'Steel') && (move.category === 'Physical' || move.category === 'Special')) {
				move.hasSTAB = true;
			}
		},
		id: "neuroforce",
		name: "Neuroforce",
		rating: 3,
		num: 233,
	},
	"powerdrive": {
		shortDesc: "Multiplies the Pokemon's Offenses by x1.3 if it is holding a Choice Band or Choice Specs.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, pokemon) {
			if (pokemon.item === 'choiceband' || pokemon.item === 'choicespecs') {
				return this.chainModify(1.3);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			if (pokemon.item === 'choiceband' || pokemon.item === 'choicespecs') {
				return this.chainModify(1.3);
			}
		},
		onModifyMove: function (move) {
			move.infiltrates = true;
		},
		id: "powerdrive",
		name: "Power Drive",
		rating: 3,
		num: 233,
	},
	"debugdrive": {
		shortDesc: "This Pokemon's attacks that are super effective against the target do 1.2x damage.",
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x1199, 0x1000]);
			}
		},
		id: "debugdrive",
		isNonstandard: true,
		name: "Debug Drive",
		rating: 3,
		num: 233,
	},
	"dazzling": {
		desc: "While this Pokemon is active, priority moves from opposing Pokemon targeted at allies are prevented from having an effect.",
		shortDesc: "While this Pokemon is active, allies are protected from opposing priority moves.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Dazzling');
			this.add('-message', "" + pokemon.name + " is blocking opposing Priority Moves!");
		},
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.priority > 0.1 && effect.target !== 'self') {
				this.attrLastMove('[still]');
				this.add('cant', this.effectData.target, 'ability: Dazzling', effect, '[of] ' + target);
				return false;
			}
		},
		id: "dazzling",
		name: "Dazzling",
		rating: 3.5,
		num: 219,
	},
	"defeatist": {
		desc: "While this Pokemon has 1/2 or less of its maximum HP, its Attack and Special Attack are halved.",
		shortDesc: "While this Pokemon has 1/2 or less of its max HP, its Attack and Sp. Atk are halved.",
		onAfterDamage: function (damage, target, source, effect) {
			if (effect && effect.effectType === 'Move' && effect.id !== 'confused' && target.hp <= source.maxhp / 2 && !target.volatiles['defeatist']) {
				this.boost({def: -1, spd: -1, spa: -1, spe: -1, atk: 12}, target);
				target.addVolatile('defeatist');
			}
		},
		id: "defeatist",
		name: "Defeatist",
		rating: 3,
		num: 129,
	},
	"defiant": {
		desc: "This Pokemon's Attack is raised by 2 stages for each of its stat stages that is lowered by an opposing Pokemon.",
		shortDesc: "This Pokemon's Attack is raised by 2 for each of its stats that is lowered by a foe.",
		onAfterEachBoost: function (boost, target, source) {
			if (!source || target.side === source.side) {
				return;
			}
			let statsLowered = false;
			for (let i in boost) {
				if (boost[i] < 0) {
					statsLowered = true;
				}
			}
			if (statsLowered) {
				this.boost({atk: 2}, null, null, null, true);
			}
		},
		id: "defiant",
		name: "Defiant",
		rating: 2.5,
		num: 128,
	},
	"deltastream": {
		desc: "On switch-in, the weather becomes strong winds that remove the weaknesses of the Flying type from Flying-type Pokemon. This weather remains in effect until this Ability is no longer active for any Pokemon, or the weather is changed by Desolate Land or Primordial Sea.",
		shortDesc: "On switch-in, strong winds begin until this Ability is not active in battle.",
		onStart: function (source) {
			this.setWeather('deltastream');
		},
		onAnySetWeather: function (target, source, weather) {
			if (this.getWeather().id === 'deltastream' && !(weather.id in {desolateland:1, primordialsea:1, deltastream:1})) return false;
		},
		onEnd: function (pokemon) {
			if (this.weatherData.source !== pokemon) return;
			for (let i = 0; i < this.sides.length; i++) {
				for (let j = 0; j < this.sides[i].active.length; j++) {
					let target = this.sides[i].active[j];
					if (target === pokemon) continue;
					if (target && target.hp && target.hasAbility('deltastream')) {
						this.weatherData.source = target;
						return;
					}
				}
			}
			this.clearWeather();
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.template.species === 'Rayquaza-Mega' && pokemon.positiveBoosts()) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.id === 'extremespeed' && !move.isZ) {
				move.type = 'Dragon';
				if (move.category !== 'Status') pokemon.addVolatile('dracospeed');
			}
		},
		setWind: true,
		setDelta: true,
		id: "deltastream",
		name: "Delta Stream",
		rating: 5,
		num: 191,
	},
	"desolateland": {
		desc: "On switch-in, the weather becomes extremely harsh sunlight that prevents damaging Water-type moves from executing, in addition to all the effects of Sunny Day. This weather remains in effect until this Ability is no longer active for any Pokemon, or the weather is changed by Delta Stream or Primordial Sea.",
		shortDesc: "On switch-in, extremely harsh sunlight begins until this Ability is not active in battle.",
		onStart: function (source) {
			this.setWeather('desolateland');
			if (source.template.species === 'Groudon-Primal' && source.item === 'redorb') {
				if (!source.setType('Ground')) return;
				this.add('-start', source, 'typechange', 'Ground', '[from] Desolate Land');
				if (!source.addType('Fire')) return;
				this.add('-start', source, 'typeadd', 'Fire', '[from] Desolate Land');
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.template.species !== 'Groudon-Primal' || pokemon.item !== 'redorb') return;
			if (move && (move.type === 'Fire' || move.type === 'Ground')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (target.template.species !== 'Groudon-Primal' || target.item !== 'redorb') return;
			if (move && move.effectType === 'Move' && typeMod > 0 && type === 'Fire' && !move.flags['exempt']) {
				return 0;
			}
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (pokemon, target, move) {
			if (pokemon.template.species === 'Groudon-Primal' && pokemon.item === 'redorb') {
				pokemon.addVolatile('redburst');
			}
		},
		onAnySetWeather: function (target, source, weather) {
			if (this.getWeather().id === 'desolateland' && !(weather.id in {desolateland:1, primordialsea:1, deltastream:1})) return false;
		},
		onEnd: function (pokemon) {
			if (this.weatherData.source !== pokemon) return;
			for (let i = 0; i < this.sides.length; i++) {
				for (let j = 0; j < this.sides[i].active.length; j++) {
					let target = this.sides[i].active[j];
					if (target === pokemon) continue;
					if (target && target.hp && target.hasAbility('desolateland')) {
						this.weatherData.source = target;
						return;
					}
				}
			}
			this.clearWeather();
		},
		isUnbreakable: true,
		setDesolate: true,
		id: "desolateland",
		name: "Desolate Land",
		rating: 5,
		num: 190,
	},
	"disguise": {
		shortDesc: ".",
		onUpdate: function (pokemon) {
			if (!pokemon.isActive || pokemon.baseTemplate.baseSpecies !== 'Mimikyu' || pokemon.transformed) return;
			if (pokemon.positiveBoosts() || pokemon.item === 'duskball') {
				if (pokemon.template.speciesid !== 'mimikyubusted') {
					pokemon.formeChange('Mimikyu-Busted');
					this.add('-formechange', pokemon, 'Mimikyu-Busted', '[msg]', '[from] ability: Disguise');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid === 'mimikyubusted') {
					pokemon.formeChange('Mimikyu');
					this.add('-formechange', pokemon, 'Mimikyu', '[msg]', '[from] ability: Disguise');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (source.volatiles['choicelock'] || source.volatiles['generallock']) {
				this.debug('Disguise Neutralize');
				return this.chainModify(0.5);
			}
		},
		id: "disguise",
		name: "Disguise",
		rating: 3,
		num: 232,
	},
	"disguise1": {
		desc: "If this Pokemon is a Mimikyu, it will take 0 damage the first time it is attacked in battle. It then changes to Busted Form.",
		shortDesc: "If this Pokemon is a Mimikyu, it takes 0 damage the first time it is attacked in battle.",
		onDamagePriority: 1,
		onDamage: function (damage, target, source, effect) {
			if (effect && effect.effectType === 'Move' && target.template.speciesid === 'mimikyu' && !target.transformed) {
				this.add('-activate', target, 'ability: Disguise');
				this.add('-message', "Its disguise served it as a decoy! (placeholder)");
				this.effectData.busted = true;
				return 0;
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.template.speciesid === 'mimikyu' && this.effectData.busted) {
				let template = this.getTemplate('Mimikyu-Busted');
				pokemon.formeChange(template);
				pokemon.baseTemplate = template;
				pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
				this.add('detailschange', pokemon, pokemon.details);
				this.add('-message', "" + pokemon.name + "'s disguise was busted! (placeholder)"); // TODO: -busted
				pokemon.addVolatile('formecheck');
			}
		},
		id: "disguise1",
		isNonstandard: true,
		name: "Disguise1",
		rating: 4,
		num: 209,
	},
	"download": {
		desc: "On switch-in, this Pokemon's Attack or Special Attack is raised by 1 stage based on the weaker combined defensive stat of all opposing Pokemon. Attack is raised if their Defense is lower, and Special Attack is raised if their Special Defense is the same or lower.",
		shortDesc: "On switch-in, Attack or Sp. Atk is raised 1 stage based on the foes' weaker Defense.",
		onStart: function (pokemon) {
			pokemon.addVolatile('downloadnerf');
			let foeactive = pokemon.side.foe.active;
			let totaldef = 0;
			let totalspd = 0;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || foeactive[i].fainted) continue;
				totaldef += foeactive[i].getStat('def', false, true);
				totalspd += foeactive[i].getStat('spd', false, true);
			}
			if (totaldef && totaldef >= totalspd) {
				this.boost({spa:1});
			} else if (totalspd) {
				this.boost({atk:1});
			}
		},
		id: "download",
		name: "Download",
		rating: 4,
		num: 88,
	},
	"bulldozer": {
		desc: "On switch-in, this Pokemon's Attack or Special Attack is raised by 1 stage based on the weaker combined defensive stat of all opposing Pokemon. Attack is raised if their Defense is lower, and Special Attack is raised if their Special Defense is the same or lower.",
		shortDesc: "On switch-in, Attack or Sp. Atk is raised 1 stage based on the foes' weaker Defense.",
		onStart: function (pokemon) {
			this.boost({atk:1, spa:1});
			if (pokemon.hasType('Grass')) pokemon.addVolatile('bulldozerspare');
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns) {
				if (pokemon.volatiles['bulldozerspare']) {
					pokemon.removeVolatile('bulldozerspare');
				} else {
					this.boost({atk:-1, spa:-1});
				}
			}
		},
		id: "bulldozer",
		name: "Bulldozer",
		rating: 4,
		num: 88,
	},
	"dyslexia": {
		desc: ".",
		shortDesc: ".",
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && !move.flags['exempt'] && typeMod > 0) {
				return -1;
			} else if (move && move.effectType === 'Move' && !move.flags['exempt'] && typeMod < 0) {
				return 1;
			}
		},
		id: "dyslexia",
		name: "Dyslexia",
		rating: 2.5,
		num: 88,
	},
	"hopesprout": {
		shortDesc: "Pokemon Restores health at the end of each turn.",
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && typeMod > 0 && type === 'Poison' && !move.flags['exempt']) {
				return 0;
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				this.add('-activate', pokemon, 'ability: Hope Sprout');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Hope Sprout');
			return false;
		},
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 4);
		},
		onDragOutPriority: 1,
		onDragOut: function (source, target) {
			this.add('-activate', source, 'ability: Hope Sprout');
			this.add('-message', "" + source.name + " won't be overcome!");
			this.heal(source.maxhp / 4, source, source, null, null);
			return null;
		},
		id: "hopesprout",
		name: "Hope Sprout",
		switchHealing: true,
		rating: 3,
		num: 192,
	},
	"empyreanblaze": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Empyrean Blaze');
			this.add('-message', "" + pokemon.name + " is blazing with heavenly light!");
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move && move.type === 'Fire' && attacker.item === 'flameorb') {
				this.debug('Empyrean Blaze boost');
				return this.chainModify([0x1333, 0x1000]);
			} 
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && typeMod > 0 && (move.type !== 'Grass' && move.type !== 'Steel') && type === 'Rock' && !move.flags['exempt']) {
				return -1;
			}
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.isAffected || move.priority < 1) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.isAffected = true;
			this.useMove(newMove, target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "empyreanblaze",
		name: "Empyrean Blaze",
		rating: 5,
		num: 88,
	},
	"ultrashell": {
		desc: ".",
		shortDesc: ".",
		onModifyMove: function (move, pokemon, target) {
			if (move.type === 'Ground') {
				move.hasSTAB = true;
			}
			if (move.type === 'Water' && !target.hasAbility('powerofalchemy')) {
				move.ignoreAbility = true;
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Rock' && (move.type === 'Ground') && !move.flags['exempt'] && !move.flags['ultrashell']) {
				return 0;
			} else if (move && move.effectType === 'Move' && type === 'Rock' && (move.type === 'Dragon') && !move.flags['exempt'] && !move.flags['ultrashell']) {
				return -1;
			} else if (move && move.effectType === 'Move' && type === 'Water' && (move.type === 'Poison') && !move.flags['exempt'] && !move.flags['ultrashell']) {
				return -1;
			}
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Ultra Shell", "[of] " + target);
		},

		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Water' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'brn') {
				this.add('-activate', pokemon, 'ability: Ultra Shell');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'brn') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Ultra Shell');
			return false;
		},
		isUnbreakable: true,
		isSanitary: true,
		id: "ultrashell",
		name: "Ultra Shell",
		rating: 5,
		num: 11,
	},
	"lightinversion": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Light Inversion');
			this.add('-message', "" + pokemon.name + " is emitting a strange light!");
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Psychic' && (move.type === 'Dark' || move.type === 'Ghost') && !move.flags['exempt']) {
				return -2;
			} else if (move && move.effectType === 'Move' && type === 'Ghost' && (move.type === 'Dragon' || move.type === 'Fairy') && !move.flags['exempt'] && typeMod < 1) {
				return 1;
			} else if (move && move.effectType === 'Move' && move.type === 'Psychic' && !move.flags['exempt'] && typeMod < 0) {
				return 0;
			}
		},
		isUnbreakable: true,
		id: "lightinversion",
		name: "Light Inversion",
		rating: 2.5,
		num: 88,
	},
	"weatherguard": {
		desc: ".",
		shortDesc: ".",
		onEffectiveness: function (typeMod, target, type, move) {
			if (this.isWeather(['sunnyday', 'desolateland', 'raindance', 'primordialsea', 'hail', 'sandstorm', 'deltastream']) && move && move.effectType === 'Move' && !move.flags['exempt'] && typeMod > 0) {
				this.add('-activate', '', 'weatherguard');
				return 0;
			}
		},
		id: "weatherguard",
		name: "Weather Guard",
		rating: 2.5,
		num: 88,
	},
	"seaking": {
		desc: "This Pokemon ignores other Pokemon's Attack, Special Attack, and accuracy stat stages when taking damage, and ignores other Pokemon's Defense, Special Defense, and evasiveness stat stages when dealing damage.",
		shortDesc: "This Pokemon ignores other Pokemon's stat stages when taking or doing damage.",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Sea King');
				this.add('-message', "" + pokemon.name + " is overflowing with vitality!");
			}
		},
		onAnyModifyBoost: function (boosts, target) {
			let source = this.effectData.target;
			if (source === target) return;
			if (source === this.activePokemon && target === this.activeTarget) {
				boosts['def'] = 0;
				boosts['spd'] = 0;
				boosts['evasion'] = 0;
			}
			if (target === this.activePokemon && source === this.activeTarget) {
				boosts['atk'] = 0;
				boosts['spa'] = 0;
				boosts['def'] = 0;
				boosts['spd'] = 0;
				boosts['accuracy'] = 0;
			}
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Sea King", "[of] " + target);
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (this.isWeather(['raindance', 'primordialsea']) && move && move.effectType === 'Move' && (move.type === 'Water' || move.type === 'Flying') && !move.flags['exempt'] && !move.isExempt) {
				this.add('-message', "" + target.name + " is bracing itself for impact!");
				this.add('-activate', '', 'seaking');
				return -1;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.volatiles['activechange']) {
				this.heal(pokemon.maxhp / 16);
			}
		},
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 8);
		},
		id: "seaking",
		name: "Sea King",
		isDonability: true,
		switchHealing: true,
		rating: 3,
		num: 109,
	},
	"fairyshield": {
		desc: ".",
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === "Fire" || move.type === 'Steel') {
				this.debug('Fairy Shield neutralize');
				return this.chainModify(0.67);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'brn') {
				this.add('-activate', pokemon, 'ability: Fairy Shield');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'brn') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Fairy Shield');
			return false;
		},
		id: "fairyshield",
		name: "Fairy Shield",
		rating: 2.5,
		num: 88,
	},
	"barricade": {
		desc: ".",
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if ((!source.hasAbility('intrepidsword') && !source.hasAbility('pokemonmaster')) && (move.type === "Ice")) {
				this.debug('Barricade neutralize');
				return this.chainModify(0.25);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'frz') {
				this.add('-activate', pokemon, 'ability: Barricade');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'frz') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Barricade');
			return false;
		},
		id: "barricade",
		name: "Barricade",
		rating: 3,
		num: 88,
	},
	"deepsea": {
		desc: ".",
		shortDesc: ".",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Deep Sea');
				this.add('-message', "" + pokemon.name + " is drawing upon the Sea for sustenance");
			}
		},
		onStart: function (pokemon) {
			let item = pokemon.getItem();
			if (!item.isMemory) {
				if (!pokemon.setType('Water')) return;
				this.add('-start', pokemon, 'typechange', 'Water', '[from] Deep Sea');
				if (!pokemon.addType('Flying')) return;
				this.add('-start', pokemon, 'typeadd', 'Flying', '[from] Deep Sea');
			}
			if (pokemon.hp > pokemon.maxhp / 2) return;
			this.add('-ability', pokemon, 'Deep Sea');
			this.add('-message', "" + pokemon.name + " is stirring up a great windstorm!");
			this.add('-anim', pokemon, 'defog', pokemon);
			if (pokemon.hp && pokemon.removeVolatile('leechseed')) {
				this.add('-end', pokemon, 'Leech Seed', '[from] ability: Deep Sea', '[of] ' + pokemon);
			}
			let sideConditions = {spikes:1, toxicspikes:1, stealthrock:1, stickyweb:1};
			for (let i in sideConditions) {
				if (pokemon.hp && pokemon.side.removeSideCondition(i)) {
					this.add('-sideend', pokemon.side, this.getEffect(i).name, '[from] ability: Deep Sea', '[of] ' + pokemon);
				}
			}
			if (pokemon.hp && pokemon.volatiles['partiallytrapped']) {
				pokemon.removeVolatile('partiallytrapped');
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (target.hp >= target.maxhp && !move.flags['descale']) {
				this.debug('Deep Sea weaken');
				return this.chainModify(0.5);
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && (move.type === 'Electric' && !move.flags['exempt']) && type === 'Water' && typeMod > 0) {
				return 0;
			}
		},
 		onSwitchOut: function (pokemon) {
			if (pokemon.volatiles['activechange'] && !pokemon.volatiles['dragondisc']) {
				pokemon.heal(pokemon.maxhp / 4);
			}
		},
		id: "deepsea",
		name: "Deep Sea",
		rating: 4,
		num: 88,
	},
	"fullmoon": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			let item = pokemon.getItem();
			if (!item.isMemory) {
				if (!pokemon.setType('Ghost')) return;
				this.add('-start', pokemon, 'typechange', 'Ghost', '[from] Full Moon');
				if (!pokemon.addType('Water')) return;
				this.add('-start', pokemon, 'typeadd', 'Water', '[from] Full Moon');
			}
		},
		onBoost: function (boost, target, source, effect) {
			for (let i in boost) {
				if (boost[i] > 0) {
					this.heal(target.maxhp / 10);
				}
			}
		},
		id: "fullmoon",
		name: "Full Moon",
		rating: 4,
		num: 88,
	},
	"doubledown": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			if (pokemon.item !== 'poisonmemory') this.boost({def:1, spd:1});
		},
		id: "doubledown",
		name: "Double Down",
		rating: 4,
		num: 88,
	},
	"superdoubledown": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Super Double Down');
			this.add('-message', "" + pokemon.name + "'s defenses are unbreakable!");
			this.boost({def:1, spd:1});
			if (pokemon.moveset[0]) {
				let smooth = this.getMove(pokemon.moveset[0].id).type;
				this.add('-message', "" + pokemon.name + " is resisting opposing " + smooth + "-Type attacks!");
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (target.moveset[0]) {
				let movement = this.getMove(target.moveset[0].id).type;
				if (move && move.effectType === 'Move' && move.type === movement && !move.flags['exempt']) {
					return -1;
				}
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.target !== 'self') {
				target.addVolatile('rundoubledownbind');
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category === 'Status') {
				this.heal(pokemon.maxhp / 4, pokemon, pokemon, null, null);
			}
		},
		isMemorized: true,
		id: "doubledown",
		name: "Double Down",
		rating: 4,
		num: 88,
	},
	"intrepidsword": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			if (!pokemon.boosts.atk >= 1) {
				this.boost({atk:1});
			}
		},
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && (!source.volatiles['iswordcheck'] && !source.volatiles['iswordflag'])) {
				source.addVolatile('iswordcheck');
			} else if (effect && effect.effectType === 'Move' && (source.volatiles['iswordcheck'] && !source.volatiles['iswordflag'])) {
				this.boost({atk:-1}, source);
				source.addVolatile('iswordflag');
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'brn') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Intrepid Sword');
			return false;
		},
		onDragOutPriority: 1,
		onDragOut: function (pokemon) {
			this.add('-activate', pokemon, 'ability: Intrepid Sword');
			this.add('-message', "" + pokemon.name + " won't back down!");
			return null;
		},
		id: "intrepidsword",
		name: "Intrepid Sword",
		rating: 3.5,
		num: 88,
	},
	"dauntlessshield": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			if (!pokemon.boosts.def >= 1) {
				this.boost({def:1});
			}
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.effectType !== 'Move') {
				return false;
			}
		},
		id: "dauntlessshield",
		name: "Dauntless Shield",
		rating: 4,
		num: 88,
	},
	"gallant": {
		shortDesc: "If this Pokemon is at full HP, damage taken from attacks is halved.",
		onStart: function (pokemon) {
			if (!pokemon.boosts.def >= 1) {
				this.boost({def:1});
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.positiveBoosts()) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "gallant",
		name: "Gallant",
		rating: 4,
		num: 136,
	},
	"drizzle": {
		shortDesc: "On switch-in, this Pokemon summons Rain Dance.",
		onStart: function (source) {
			for (let i = 0; i < this.queue.length; i++) {
				if (this.queue[i].choice === 'runPrimal' && this.queue[i].pokemon === source && source.template.speciesid === 'kyogre') return;
				if (this.queue[i].choice !== 'runSwitch' && this.queue[i].choice !== 'runPrimal') break;
			}
			if (source.item === 'roomservice') {
				this.add('-message', "" + source.name + "'s Room Service is transforming its Rain into glistening Snow!");
				this.setWeather('hail');
			} else {
				this.setWeather('raindance');
			}
		},
		setRain: true,
		id: "drizzle",
		name: "Drizzle",
		rating: 4.5,
		num: 2,
	},
	"drought": {
		shortDesc: "On switch-in, this Pokemon summons Sunny Day.",
		onStart: function (source) {
			for (let i = 0; i < this.queue.length; i++) {
				if (this.queue[i].choice === 'runPrimal' && this.queue[i].pokemon === source && source.template.speciesid === 'groudon') return;
				if (this.queue[i].choice !== 'runSwitch' && this.queue[i].choice !== 'runPrimal') break;
			}
			if (source.item === 'roomservice') {
				this.add('-message', "" + source.name + "'s Room Service is obscuring its Sunlight with a powerful cloud of Sand!");
				this.setWeather('sandstorm');
			} else {
				this.setWeather('sunnyday');
			}
		},
		setSun: true,
		id: "drought",
		name: "Drought",
		rating: 4.5,
		num: 70,
	},
	"dryskin": {
		desc: "This Pokemon is immune to Water-type moves and restores 1/4 of its maximum HP, rounded down, when hit by a Water-type move. The power of Fire-type moves is multiplied by 1.25 when used on this Pokemon. At the end of each turn, this Pokemon restores 1/8 of its maximum HP, rounded down, if the weather is Rain Dance, and loses 1/8 of its maximum HP, rounded down, if the weather is Sunny Day.",
		shortDesc: "This Pokemon is healed 1/4 by Water, 1/8 by Rain; is hurt 1.25x by Fire, 1/8 by Sun.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Water') {
				if (!this.heal(target.maxhp / 4)) {
					this.add('-immune', target, '[msg]', '[from] ability: Dry Skin');
				}
				return null;
			}
		},
		onBasePowerPriority: 7,
		onFoeBasePower: function (basePower, attacker, defender, move) {
			if (this.effectData.target !== defender) return;
			if (move.type === 'Fire') {
				return this.chainModify(1.25);
			}
		},
		onWeather: function (target, source, effect) {
			if (effect.id === 'raindance' || effect.id === 'primordialsea') {
				this.heal(target.maxhp / 8);
			} else if (effect.id === 'sunnyday' || effect.id === 'desolateland') {
				this.damage(target.maxhp / 8, target, target);
			}
		},
		id: "dryskin",
		name: "Dry Skin",
		rating: 3,
		num: 87,
	},
	"earlybird": {
		shortDesc: "This Pokemon's sleep counter drops by 2 instead of 1.",
		id: "earlybird",
		name: "Early Bird",
		// Implemented in statuses.js
		rating: 2.5,
		num: 48,
	},
	"effectspore": {
		desc: "30% chance a Pokemon making contact with this Pokemon will be poisoned, paralyzed, or fall asleep.",
		shortDesc: "30% chance of poison/paralysis/sleep on others making contact with this Pokemon.",
		onAfterDamage: function (damage, target, source, move) {
			if (move && move.flags['contact'] && !source.status && source.runStatusImmunity('powder')) {
				let r = this.random(100);
				if (r < 11) {
					source.setStatus('slp', target);
				} else if (r < 21) {
					source.setStatus('par', target);
				} else if (r < 30) {
					source.setStatus('psn', target);
				}
			}
		},
		id: "effectspore",
		name: "Effect Spore",
		rating: 2,
		num: 27,
	},
	"electricsurge": {
		shortDesc: "On switch-in, this Pokemon summons Electric Terrain.",
		onStart: function (source) {
			this.setTerrain('electricterrain');
		},
		id: "electricsurge",
		isNonstandard: true,
		name: "Electric Surge",
		rating: 4,
		num: 226,
	},
	"emergencyexit": {
		shortDesc: "This Pokemon switches out when it reaches 1/2 or less of its maximum HP.",
		onAfterMoveSecondary: function (target, source, move) {
			if (!source || source === target || !target.hp || !move.totalDamage) return;
			if (target.hp <= target.maxhp / 2 && target.hp + move.totalDamage > target.maxhp / 2) {
				if (!this.canSwitch(target.side) || target.forceSwitchFlag || target.switchFlag) return;
				target.switchFlag = true;
				source.switchFlag = false;
				this.add('-activate', target, 'ability: Emergency Exit');
			}
		},
		id: "emergencyexit",
		name: "Emergency Exit",
		rating: 2,
		num: 194,
	},
	"fairyaura": {
		desc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		shortDesc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === 'Fairy' && !move.flags['noauraboost']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onBoost: function (boost, target, source, effect) {
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Fairy Aura", "[of] " + target);
		},
		id: "fairyaura",
		name: "Fairy Aura",
		rating: 3,
		num: 187,
	},
	"superfairyaura": {
		desc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		shortDesc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Super Fairy Aura');
			this.add('-message', "" + pokemon.name + " bathes the land in calming light!");
			if (pokemon.hp && pokemon.removeVolatile('leechseed')) {
				this.add('-end', pokemon, 'Leech Seed', '[from] ability: Super Fairy Aura', '[of] ' + pokemon);
			}
			let sideConditions = {spikes:1, toxicspikes:1, stealthrock:1, stickyweb:1};
			for (let i in sideConditions) {
				if (pokemon.hp && pokemon.side.removeSideCondition(i)) {
					this.add('-sideend', pokemon.side, this.getEffect(i).name, '[from] ability: Super Fairy Aura', '[of] ' + pokemon);
				}
			}
			if (pokemon.hp && pokemon.volatiles['partiallytrapped']) {
				pokemon.removeVolatile('partiallytrapped');
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === 'Fairy' && !move.flags['noauraboost']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onBoost: function (boost, target, source, effect) {
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Super Fairy Aura", "[of] " + target);
		},
		onFaint: function (pokemon) {
			if (!pokemon.side.sideConditions['superfairyfield']) {
				this.add('-ability', pokemon, 'Super Fairy Aura');
				this.add('-message', "" + pokemon.name + " left behind a parting gift!");
				pokemon.side.addSideCondition('superfairyfield');
			}
		},
		isMemorized: true,
		id: "superfairyaura",
		name: "Super Fairy Aura",
		rating: 3,
		num: 187,
	},
	"filter": {
		shortDesc: "This Pokemon receives 3/4 damage from supereffective attacks.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod > 0) {
				this.debug('Filter neutralize');
				return this.chainModify(0.75);
			}
		},
		id: "filter",
		name: "Filter",
		rating: 3,
		num: 111,
	},
	"pragmatic": {
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Fairy') {
				this.debug('Pragmatic neutralize');
				return this.chainModify(0.5);
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (target.hasType('Fairy')) {
				this.debug('Pragmatic boost');
				return this.chainModify(2);
			}
		},
		id: "pragmatic",
		name: "Pragmatic",
		rating: 3,
		num: 111,
	},
	"pastelveil": {
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.flags['choiced'] || ((source.boosts.atk >= 1 && move.category === 'Physical') || (source.boosts.spa >= 1 && move.category === 'Special'))) {
				this.debug('Pastel Veil Neutralize');
				return this.chainModify(0.5);
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Psychic' && move.type === 'Dark' && typeMod > 0 && !move.flags['exempt']) {
				return 0;
			}
		},
		onSwitchOut: function (pokemon) {
			if (!pokemon.status) return;
			if (pokemon.status) {
				this.add('-ability', pokemon, 'Pastel Veil');
				this.add('-curestatus', pokemon, pokemon.status);
				pokemon.setStatus('');
			}
		},
		id: "pastelveil",
		name: "Pastel Veil",
		rating: 3,
		num: 111,
	},
	"frostyveil": {
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Dragon' || move.type === 'Steel' || move.type === 'Electric') {
				this.debug('Frosty Veil neutralize');
				return this.chainModify(0.5);
			}
		},
		onAfterDamage: function (damage, target, source, move) {
			if (move && (move.category === 'Physical' || move.category === 'Special')) {
				if (source.positiveBoosts()) {
					source.clearBoosts();
					this.add('-clearboost', source);
				}
			}
		},
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 8);
		},
		id: "frostyveil",
		name: "Frosty Veil",
		switchHealing: true,
		rating: 3,
		num: 111,
	},
	"chaosbird": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === 'Fire') {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if ((move.type === 'Dark' || move.type === 'Fire') && move.typeMod > 0) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'brn') {
				this.add('-activate', pokemon, 'ability: Chaos Bird');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'brn') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Chaos Bird');
			return false;
		},
		id: "chaosbird",
		name: "Chaos Bird",
		rating: 4,
		num: 253,
	},
	"belligerent": {
		desc: ".",
		shortDesc: ".",
		onAnyModifyBoost: function (boosts, target) {
			let source = this.effectData.target;
			if (source === target) return;
			if (source === this.activePokemon && target === this.activeTarget) {
				boosts['def'] = 0;
				boosts['spd'] = 0;
			}
		},
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && !source.volatiles['belligerentcheck']) {
				this.boost({spe:2}, source);
				source.addVolatile('belligerentcheck');
			}
		},
		id: "belligerent",
		name: "Belligerent",
		rating: 3,
		num: 109,
	},
	"moonlightveil": {
		shortDesc: ".",
		onSourceBasePower: function (damage, source, target, move) {
			if ((source.volatiles['choicelock'] || source.volatiles['generallock']) && !move.ignoreAbility && move.typeMod > 0) {
				this.debug('Veil Neutralize');
				return this.chainModify(0.5);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Ghost' || move.type === 'Dragon' || move.type === 'Steel') {
				this.debug('Moonlight Veil neutralize');
				return this.chainModify(0.5);
			}
		},
		id: "moonlightveil",
		name: "Moonlight Veil",
		rating: 3,
		num: 111,
	},
	"midnightveil": {
		shortDesc: ".",
		onSourceBasePower: function (damage, source, target, move) {
			if ((source.volatiles['choicelock'] || source.volatiles['generallock']) && !move.ignoreAbility && move.typeMod > 0) {
				this.debug('Veil Neutralize');
				return this.chainModify(0.5);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (source.hasType('Ghost') && move && move.typeMod > 0) {
				this.debug('Midnight neutralize');
				return this.chainModify(0.5);
			}
		},
		onTryHit: function (target, source, move) {
			if (target !== source && (move.flags['switch'] || move.flags['switchstatus'])) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Midnight Veil');
				}
				return null;
			}
		},
		id: "midnightveil",
		name: "Midnight Veil",
		rating: 3,
		num: 111,
	},
	"doublelayer": {
		shortDesc: "This Pokemon receives 1/2 damage from supereffective attacks.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Double Layer neutralize');
				return this.chainModify(0.5);
			}
		},
		id: "doublelayer",
		name: "Double-Layer",
		rating: 4,
		num: 111,
	},
	"dualwielder": {
		shortDesc: "This Pokemon's Water-Type attacks that are not very effective on a target deal quadruple damage.",
		onModifyDamage: function (damage, source, target, move) {
			let vary = source.types[0];
			let varys = source.types[1];
			let contin = source.getTypes();
			if (move.type === vary || move.type === varys || move.type === contin) move.flags['hasstab'] = true;
			if ((source.volatiles['memorybug'] && move.type === 'Bug') || (source.volatiles['memorydark'] && move.type === 'Dark') || (source.volatiles['memorydragon'] && move.type === 'Dragon') || (source.volatiles['memoryelectric'] && move.type === 'Electric') || (source.volatiles['memoryfairy'] && move.type === 'Fairy') || (source.volatiles['memoryfighting'] && move.type === 'Fighting') || (source.volatiles['memoryfire'] && move.type === 'Fire') || (source.volatiles['memoryflying'] && move.type === 'Flying') || (source.volatiles['memoryghost'] && move.type === 'Ghost') || (source.volatiles['memorygrass'] && move.type === 'Grass') || (source.volatiles['memoryground'] && move.type === 'Ground') || (source.volatiles['memoryice'] && move.type === 'Ice') || (source.volatiles['memorynormal'] && move.type === 'Normal') || (source.volatiles['memorypoison'] && move.type === 'Poison') || (source.volatiles['memorypsychic'] && move.type === 'Psychic') || (source.volatiles['memoryrock'] && move.type === 'Rock') || (source.volatiles['memorysteel'] && move.type === 'Steel') || (source.volatiles['memorywater'] && move.type === 'Water') || (source.volatiles['memorymystery'] && move.type === '???') && !move.flags['hasstab']) move.flags['hasstab'] = true; 
			if (move && move.flags['hasstab'] && move.typeMod < 0) {
				this.debug('Dual Wielder boost');
				return this.chainModify(4);
			}
		},
		id: "dualwielder",
		name: "Dual Wielder",
		rating: 3,
		num: 110,
	},
	"bountiful": {
		shortDesc: "This Pokemon receives 1/2 damage from semieffective attacks.",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Bountiful');
				this.add('-message', "" + pokemon.name + " is surrounded by Flowers!");
				this.boost({def:1, spd: 1});
				pokemon.addVolatile('flowerfactor');
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if ((move.category === 'Physical' || move.category === 'Special' || move.selfSwitch) && !pokemon.side.sideConditions['bountifulfield']) {
				pokemon.side.addSideCondition('bountifulfield');
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if ((pokemon.hp >= pokemon.maxhp / 2) && pokemon.volatiles['activechange']) {
				this.heal(pokemon.maxhp / 16);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0 || move.priority >= 1) {
				this.debug('Flower Shield neutralize');
				return this.chainModify(0.5);
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Grass' && (move.type === 'Flying') && !move.flags['exempt']) {
				return 0;
			}
		},
		id: "bountiful",
		name: "Bountiful",
		rating: 4,
		num: 111,
	},
	"evergreen": {
		shortDesc: ".",
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['evertarget']) target.removeVolatile('evertarget');
			if ((move.category === 'Physical' || move.category === 'Special') && !pokemon.side.sideConditions['evergreenfield']) {
				pokemon.side.addSideCondition('evergreenfield');
			}
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['evertarget']) defender.addVolatile('evertarget');
			if (move.type === 'Fighting' && (defender.hasType('Fairy') || defender.hasType('Poison'))) {
				move.flags['exempt'] = true;
			} else if (move.type === 'Grass' && defender.volatiles['activechange']) {
				move.flags['exempt'] = true;
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (source.side === this.effectData.target.side && effect.priority > 0.1 && effect.target !== 'self') {
				target.addVolatile('everfactor');
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Grass' && (move.type === 'Poison') && !move.flags['exempt']) {
				return 0;
			} else if (move && move.effectType === 'Move' && type === 'Fighting' && typeMod > 0 && !move.flags['exempt']) {
				return 0;
			}
		},
		id: "evergreen",
		name: "Evergreen",
		rating: 3.5,
		num: 260,
	},
	"parlortrick": {
		shortDesc: "This Pokemon receives 1/2 damage from semieffective attacks.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Parlor Trick neutralize');
				return this.chainModify(0.5);
			}
		},
		onAfterEachBoost: function (boost, target, source) {
			if (!source || target.side === source.side) {
				return;
			}
			let statsLowered = false;
			for (let i in boost) {
				if (boost[i] < 0) {
					statsLowered = true;
				}
			}
			if (statsLowered && target.boosts.spe < 1) {
				this.boost({spe: 1}, null, null, null, true);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				this.add('-activate', pokemon, 'ability: Parlor Trick');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Parlor Trick');
			return false;
		},
		id: "parlortrick",
		name: "Parlor Trick",
		rating: 4,
		num: 111,
	},
	"appetite": {
		shortDesc: ".",
		onAfterDamage: function (damage, target, source, move) {
			if (move && move.category !== 'Status') {
				if (((move.category === 'Physical' || move.flags['hitsdef']) && source.boosts.atk >= 1) && !target.volatiles['appetitedef']) {
					this.boost({def: 2}, target);
					target.addVolatile('appetitedef');
				} else if (((move.category === 'Special' || move.flags['hitsspd']) && source.boosts.spa >= 1) && !target.volatiles['appetitespd']) {
					this.boost({spd: 2}, target);
					target.addVolatile('appetitespd');
				}
			}
		},
		id: "appetite",
		name: "Appetite",
		rating: 3.5,
		num: 111,
	},
	"potentialhanashieldbuff": {
		shortDesc: "This Pokemon receives 1/2 damage from supereffective attacks.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Flower Shield neutralize');
				return this.chainModify(0.5);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Flower Shield neutralize');
				return this.chainModify(0.5);
			} else if ((move && move.category !== 'Status' && move.flags['spout']) && !move.typeMod < 0) {
				this.debug('Flower Shield neutralize');
				return this.chainModify(0.5);
			} else if ((move && move.category !== 'Status' && move.flags['spout']) && move.typeMod < 0) {
				this.debug('Flower Shield neutralize');
				return this.chainModify(0.25);
			}
		},
		id: "potentialhanashieldbuff",
		isNonstandard: true,
		name: "Potential Hana Shield Buff",
		rating: 4,
		num: 111,
	},
	"flamebody": {
		shortDesc: "30% chance a Pokemon making contact with this Pokemon will be burned.",
		onAfterDamage: function (damage, target, source, move) {
			if (move && move.flags['contact']) {
				if (this.random(10) < 3) {
					source.trySetStatus('brn', target);
				}
			}
		},
		id: "flamebody",
		name: "Flame Body",
		rating: 2,
		num: 49,
	},
	"flareboost": {
		desc: "While this Pokemon is burned, the power of its special attacks is multiplied by 1.5.",
		shortDesc: "While this Pokemon is burned, its special attacks have 1.5x power.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (attacker.status === 'brn' && move.category === 'Special') {
				return this.chainModify(1.5);
			}
		},
		id: "flareboost",
		name: "Flare Boost",
		rating: 2.5,
		num: 138,
	},
	"flashfire": {
		desc: "This Pokemon is immune to Fire-type moves. The first time it is hit by a Fire-type move, its attacking stat is multiplied by 1.5 while using a Fire-type attack as long as it remains active and has this Ability. If this Pokemon is frozen, it cannot be defrosted by Fire-type attacks.",
		shortDesc: "This Pokemon's Fire attacks do 1.5x damage if hit by one Fire move; Fire immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Fire') {
				move.accuracy = true;
				if (!target.addVolatile('flashfire')) {
					this.add('-immune', target, '[msg]', '[from] ability: Flash Fire');
				}
				return null;
			}
		},
		onEnd: function (pokemon) {
			pokemon.removeVolatile('flashfire');
		},
		effect: {
			noCopy: true, // doesn't get copied by Baton Pass
			onStart: function (target) {
				this.add('-start', target, 'ability: Flash Fire');
			},
			onModifyAtkPriority: 5,
			onModifyAtk: function (atk, attacker, defender, move) {
				if (move.type === 'Fire') {
					this.debug('Flash Fire boost');
					return this.chainModify(1.5);
				}
			},
			onModifySpAPriority: 5,
			onModifySpA: function (atk, attacker, defender, move) {
				if (move.type === 'Fire') {
					this.debug('Flash Fire boost');
					return this.chainModify(1.5);
				}
			},
			onEnd: function (target) {
				this.add('-end', target, 'ability: Flash Fire', '[silent]');
			},
		},
		id: "flashfire",
		name: "Flash Fire",
		rating: 3,
		num: 18,
	},
	"flowergift": {
		desc: "If this Pokemon is a Cherrim and Sunny Day is active, it changes to Sunshine Form and the Attack and Special Defense of it and its allies are multiplied by 1.5.",
		shortDesc: "If user is Cherrim and Sunny Day is active, it and allies' Attack and Sp. Def are 1.5x.",
		onStart: function (pokemon) {
			delete this.effectData.forme;
		},
		onUpdate: function (pokemon) {
			if (!pokemon.isActive || pokemon.baseTemplate.baseSpecies !== 'Cherrim' || pokemon.transformed) return;
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				if (pokemon.template.speciesid !== 'cherrimsunshine') {
					pokemon.formeChange('Cherrim-Sunshine');
					this.add('-formechange', pokemon, 'Cherrim-Sunshine', '[msg]', '[from] ability: Flower Gift');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid === 'cherrimsunshine') {
					pokemon.formeChange('Cherrim');
					this.add('-formechange', pokemon, 'Cherrim', '[msg]', '[from] ability: Flower Gift');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		id: "flowergift",
		name: "Flower Gift",
		rating: 2.5,
		num: 122,
	},
	"flowerveil": {
		desc: "Grass-type Pokemon on this Pokemon's side cannot have their stat stages lowered by other Pokemon or have a major status condition inflicted on them by other Pokemon.",
		shortDesc: "This side's Grass types can't have stats lowered or status inflicted by other Pokemon.",
		onAllyBoost: function (boost, target, source, effect) {
			if ((source && target === source) || !target.hasType('Grass')) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add('-fail', this.effectData.target, 'unboost', '[from] ability: Flower Veil', '[of] ' + target);
		},
		onAllySetStatus: function (status, target, source, effect) {
			if (target.hasType('Grass')) {
				if (!effect || !effect.status) return false;
				this.add('-activate', this.effectData.target, 'ability: Flower Veil', '[of] ' + target);
				return null;
			}
		},
		id: "flowerveil",
		name: "Flower Veil",
		rating: 0,
		num: 166,
	},
	"fluffy": {
		desc: "This Pokemon receives 1/2 damage from contact moves, but double damage from Fire moves.",
		shortDesc: "This Pokemon takes 1/2 damage from contact moves, 2x damage from Fire moves.",
		// TODO: are either of these effects actually base power modifiers?
		onSourceModifyDamage: function (damage, source, target, move) {
			let mod = 1;
			if (move.flags['contact']) mod /= 2;
			return this.chainModify(mod);
		},
		id: "fluffy",
		name: "Fluffy",
		rating: 2.5,
		num: 218,
	},
	"forecast": {
		desc: "If this Pokemon is a Castform, its type changes to the current weather condition's type, except Sandstorm.",
		shortDesc: "Castform's type changes to the current weather condition's type, except Sandstorm.",
		onUpdate: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Castform' || pokemon.transformed) return;
			let forme = null;
			switch (this.effectiveWeather()) {
			case 'sunnyday':
			case 'desolateland':
				if (pokemon.template.speciesid !== 'castformsunny') forme = 'Castform-Sunny';
				break;
			case 'raindance':
			case 'primordialsea':
				if (pokemon.template.speciesid !== 'castformrainy') forme = 'Castform-Rainy';
				break;
			case 'hail':
				if (pokemon.template.speciesid !== 'castformsnowy') forme = 'Castform-Snowy';
				break;
			default:
				if (pokemon.template.speciesid !== 'castform') forme = 'Castform';
				break;
			}
			if (pokemon.isActive && forme) {
				pokemon.formeChange(forme);
				this.add('-formechange', pokemon, forme, '[msg]', '[from] ability: Forecast');
				pokemon.addVolatile('formecheck');
			}
		},
		id: "forecast",
		name: "Forecast",
		rating: 3,
		num: 59,
	},
	"forewarn": {
		desc: "On switch-in, this Pokemon is alerted to the move with the highest power, at random, known by an opposing Pokemon.",
		shortDesc: "On switch-in, this Pokemon is alerted to the foes' move with the highest power.",
		onStart: function (pokemon) {
			let targets = pokemon.side.foe.active;
			let warnMoves = [];
			let warnBp = 1;
			for (let i = 0; i < targets.length; i++) {
				if (targets[i].fainted) continue;
				for (let j = 0; j < targets[i].moveset.length; j++) {
					let move = this.getMove(targets[i].moveset[j].move);
					let bp = move.basePower;
					if (move.ohko) bp = 160;
					if (move.id === 'counter' || move.id === 'metalburst' || move.id === 'mirrorcoat') bp = 120;
					if (!bp && move.category !== 'Status') bp = 80;
					if (bp > warnBp) {
						warnMoves = [[move, targets[i]]];
						warnBp = bp;
					} else if (bp === warnBp) {
						warnMoves.push([move, targets[i]]);
					}
				}
			}
			if (!warnMoves.length) return;
			let warnMove = warnMoves[this.random(warnMoves.length)];
			this.add('-activate', pokemon, 'ability: Forewarn', warnMove[0], '[of] ' + warnMove[1]);
		},
		id: "forewarn",
		name: "Forewarn",
		rating: 1,
		num: 108,
	},
	"friendguard": {
		shortDesc: "This Pokemon's allies receive 3/4 damage from other Pokemon's attacks.",
		id: "friendguard",
		name: "Friend Guard",
		onAnyModifyDamage: function (damage, source, target, move) {
			if (target !== this.effectData.target && target.side === this.effectData.target.side) {
				this.debug('Friend Guard weaken');
				return this.chainModify(0.75);
			}
		},
		rating: 0,
		num: 132,
	},
	"frisk": {
		shortDesc: "On switch-in, this Pokemon identifies the held items of all opposing Pokemon.",
		onStart: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || foeactive[i].fainted) continue;
				if (foeactive[i].item) {
					this.add('-item', foeactive[i], foeactive[i].getItem().name, '[from] ability: Frisk', '[of] ' + pokemon, '[identify]');
				}
			}
		},
		id: "frisk",
		name: "Frisk",
		rating: 1.5,
		num: 119,
	},
	"fullmetalbody": {
		shortDesc: "Prevents other Pokemon from lowering this Pokemon's stat stages.",
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Full Metal Body", "[of] " + target);
		},
		isUnbreakable: true,
		id: "fullmetalbody",
		name: "Full Metal Body",
		rating: 2,
		num: 230,
	},
	"blazingbody": {
		shortDesc: "Prevents other Pokemon from lowering this Pokemon's stat stages.",
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Blazing Body", "[of] " + target);
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.id === 'sunsteelstrike') {
				move.type = 'Fire';
				if (move.category !== 'Status') pokemon.addVolatile('blazingbody');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				if (!pokemon.hasType('Fire')) {
					return this.chainModify([0x1800, 0x1000]);
				} else {
					return this.chainModify([0x1333, 0x1000]);
				}
			},
		},
		isUnbreakable: true,
		id: "blazingbody",
		name: "Blazing Body",
		rating: 3,
		num: 230,
	},
	"blazingheat": {
		shortDesc: "This Pokemon's attacks that are super effective against the target do 1.2x damage.",
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.type === 'Fire' && move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === "Ice" || move.type === "Fairy") {
				this.debug('Blazing Heat neutralize');
				return this.chainModify(0.5);
			}
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Blazing Heat", "[of] " + target);
		},
		id: "blazingheat",
		name: "Blazing Heat",
		rating: 3,
		num: 233,
	},
	"furcoat": {
		shortDesc: "This Pokemon's Defense is doubled.",
		onModifyDefPriority: 6,
		onModifyDef: function (def) {
			return this.chainModify(2);
		},
		id: "furcoat",
		name: "Fur Coat",
		rating: 3.5,
		num: 169,
	},
	"galewings": {
		shortDesc: "If this Pokemon is at full HP, its Flying-type moves have their priority increased by 1.",
		onModifyPriority: function (priority, pokemon, target, move) {
			if (move && move.type === 'Flying' && pokemon.hp === pokemon.maxhp) return priority + 1;
		},
		id: "galewings",
		name: "Gale Wings",
		rating: 3,
		num: 177,
	},
	"galvanize": {
		desc: "This Pokemon's Normal-type moves become Electric-type moves and have their power multiplied by 1.2. This effect comes after other effects that change a move's type, but before Ion Deluge and Electrify's effects.",
		shortDesc: "This Pokemon's Normal-type moves become Electric type and have 1.2x power.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.type === 'Normal' && move.id !== 'naturalgift' && !move.isZ) {
				move.type = 'Electric';
				if (move.category !== 'Status') pokemon.addVolatile('galvanize');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x1333, 0x1000]);
			},
		},
		id: "galvanize",
		isSuffix: true,
		name: "Galvanize",
		rating: 4,
		num: 206,
	},
	"gluttony": {
		shortDesc: "When this Pokemon has 1/2 or less of its maximum HP, it uses certain Berries early.",
		id: "gluttony",
		name: "Gluttony",
		rating: 1,
		num: 82,
	},
	"gooey": {
		shortDesc: "Pokemon making contact with this Pokemon have their Speed lowered by 1 stage.",
		onAfterDamage: function (damage, target, source, effect) {
			if (effect && effect.flags['contact']) {
				this.add('-ability', target, 'Gooey');
				this.boost({spe: -1}, source, target, null, true);
			}
		},
		id: "gooey",
		name: "Gooey",
		rating: 2.5,
		num: 183,
	},
	"grasspelt": {
		shortDesc: "If Grassy Terrain is active, this Pokemon's Defense is multiplied by 1.5.",
		onModifyDefPriority: 6,
		onModifyDef: function (pokemon) {
			if (this.isTerrain('grassyterrain')) return this.chainModify(1.5);
		},
		id: "grasspelt",
		name: "Grass Pelt",
		rating: 0.5,
		num: 179,
	},
	"grassysurge": {
		shortDesc: "On switch-in, this Pokemon summons Grassy Terrain.",
		onStart: function (source) {
			this.setTerrain('grassyterrain');
		},
		id: "grassysurge",
		isNonstandard: true,
		name: "Grassy Surge",
		rating: 4,
		num: 229,
	},
	"guts": {
		desc: "If this Pokemon has a major status condition, its Attack is multiplied by 1.5; burn's physical damage halving is ignored.",
		shortDesc: "If this Pokemon is statused, its Attack is 1.5x; ignores burn halving physical damage.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Guts');
			this.add('-message', "" + pokemon.name + " is standing tall!");
		},
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, pokemon) {
			if (pokemon.status) {
				return this.chainModify(1.5);
			}
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'brn' || effect.id === 'par' || effect.id === 'psn' || effect.id === 'tox') {
				return false;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.add('-ability', pokemon, 'Guts');
			this.add('-message', "" + pokemon.name + " won't back down!");
		},
		id: "guts",
		name: "Guts",
		rating: 3,
		num: 62,
	},
	"indignation": {
		desc: "If this Pokemon has a major status condition, its Attack and SpA are multiplied by 1.3.",
		shortDesc: "If this Pokemon is statused, its Attack and SpA is 1.3x.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, pokemon) {
			if (pokemon.status) {
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			if (pokemon.status) {
				return this.chainModify(1.5);
			}
		},
		id: "indignation",
		name: "Indignation",
		rating: 3,
	},
	"formatdrive": {
		shortDesc: "This Pokemon's moves and their effects ignore the Abilities of other Pokemon.",
		onSwitchIn: function (pokemon) {
			this.add('-ability', pokemon, 'Format Drive');
			this.add('-message', "" + pokemon.name + " has become corrupted!");
		},
		onStart: function (pokemon) {
			let item = pokemon.getItem();
			if (!item.isMemory) {
				if (!pokemon.setType('???')) return;
				this.add('-start', pokemon, 'typechange', '???', '[from] Format Drive');
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onModifyMove: function (move) {
			move.ignoreAbility = true;
		},
		id: "formatdrive",
		isBreaker: true,
		name: "Format Drive",
		rating: 3.5,
		num: 104,
	},
	"shieldpower": {
		desc: "If this Pokemon has a major status condition, its Attack and SpA are multiplied by 1.3.",
		shortDesc: "If this Pokemon is statused, its Attack and SpA is 1.3x.",
		onStart: function (pokemon) {
			let item = pokemon.getItem();
			if (!item.isMemory) {
				if (!pokemon.setType('???')) return;
				this.add('-start', pokemon, 'typechange', '???', '[from] Shield Power');
			}
		},
		onModifyDefPriority: 5,
		onModifyDef: function (def, pokemon) {
			if (pokemon.baseTemplate.baseSpecies === 'Porygon2' && pokemon.volatiles['activechange']) {
				return this.chainModify(1.5);
			}
		},
		onModifySpDPriority: 5,
		onModifySpD: function (spd, pokemon) {
			if (pokemon.baseTemplate.baseSpecies === 'Porygon2' && pokemon.volatiles['activechange']) {
				return this.chainModify(1.5);
			}
		},
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Shield Power');
				this.add('-message', "" + pokemon.name + " has become fortified!");
			}
		},
		isUnbreakable: true,
		id: "shieldpower",
		name: "Shield Power",
		rating: 3,
	},
	"resolution": {
		desc: "If this Pokemon has a major status condition, its Attack is multiplied by 1.5; burn's physical damage halving is ignored.",
		shortDesc: "If this Pokemon is statused, its Attack is 1.5x; ignores burn halving physical damage.",
		onStart: function (pokemon) {
			let item = pokemon.getItem();
			if (!item.isMemory) {
				if (!pokemon.setType('???')) return;
				this.add('-start', pokemon, 'typechange', '???', '[from] Resolution');
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x2000, 0x1000]);
			}
		},
		id: "resolution",
		name: "Resolution",
		rating: 3,
		num: 265,
	},
	"powersurge": {
		desc: ".",
		shortDesc: ".",
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && !source.volatiles['powersurgecheck']) {
				this.boost({atk:1, spa:1}, source);
				source.addVolatile('powersurgecheck');
			}
		},
		id: "powersurge",
		name: "Power Surge",
		rating: 3,
		num: 267,
	},
	"harvest": {
		desc: "If the last item this Pokemon used is a Berry, there is a 50% chance it gets restored at the end of each turn. If Sunny Day is active, this chance is 100%.",
		shortDesc: "If last item used is a Berry, 50% chance to restore it each end of turn. 100% in Sun.",
		id: "harvest",
		name: "Harvest",
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland']) || this.random(2) === 0) {
				if (pokemon.hp && !pokemon.item && this.getItem(pokemon.lastItem).isBerry) {
					pokemon.setItem(pokemon.lastItem);
					this.add('-item', pokemon, pokemon.getItem(), '[from] ability: Harvest');
				}
			}
		},
		rating: 2.5,
		num: 139,
	},
	"healer": {
		desc: "There is a 30% chance of curing an adjacent ally's major status condition at the end of each turn.",
		shortDesc: "30% chance of curing an adjacent ally's status at the end of each turn.",
		id: "healer",
		name: "Healer",
		onResidualOrder: 5,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			let allyActive = pokemon.side.active;
			if (allyActive.length === 1) {
				return;
			}
			for (let i = 0; i < allyActive.length; i++) {
				if (allyActive[i] && allyActive[i].hp && this.isAdjacent(pokemon, allyActive[i]) && allyActive[i].status && this.random(10) < 3) {
					this.add('-activate', pokemon, 'ability: Healer');
					allyActive[i].cureStatus();
				}
			}
		},
		rating: 0,
		num: 131,
	},
	"heatproof": {
		desc: "The power of Fire-type attacks against this Pokemon is halved, and burn damage taken is halved.",
		shortDesc: "The power of Fire-type attacks against this Pokemon is halved; burn damage halved.",
		onBasePowerPriority: 7,
		onSourceBasePower: function (basePower, attacker, defender, move) {
			if (move.type === 'Fire') {
				return this.chainModify(0.5);
			}
		},
		onDamage: function (damage, target, source, effect) {
			if (effect && effect.id === 'brn') {
				return damage / 2;
			}
		},
		id: "heatproof",
		name: "Heatproof",
		rating: 2.5,
		num: 85,
	},
	"heavymetal": {
		shortDesc: "This Pokemon's weight is doubled.",
		onModifyWeight: function (weight) {
			return weight * 2;
		},
		id: "heavymetal",
		name: "Heavy Metal",
		rating: -1,
		num: 134,
	},
	"honeygather": {
		shortDesc: "No competitive use.",
		id: "honeygather",
		name: "Honey Gather",
		rating: 0,
		num: 118,
	},
	"hugepower": {
		shortDesc: "This Pokemon's Attack is doubled.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk) {
			return this.chainModify(2);
		},
		id: "hugepower",
		name: "Huge Power",
		rating: 5,
		num: 37,
	},
	"burningbeast": {
		shortDesc: "This Pokemon's Defenses are increased when holding a Choice Item.",
		onModifyDefPriority: 5,
		onModifyDef: function (def, pokemon) {
			if (pokemon.item === 'choicescarf' || pokemon.item === 'choiceband' || pokemon.item === 'choicespecs') {
				return this.chainModify(1.5);
			}
		},
		onModifySpDPriority: 5,
		onModifySpD: function (spd, pokemon) {
			if (pokemon.item === 'choicescarf' || pokemon.item === 'choiceband' || pokemon.item === 'choicespecs') {
				return this.chainModify(1.5);
			}
		},
		id: "burningbeast",
		name: "Burning Beast",
		rating: 2.5,
		num: 37,
	},
	"torrentialbeast": {
		shortDesc: "This Pokemon's Offenses are increased when holding a Choice Item.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, pokemon) {
			if (pokemon.item === 'choicescarf' || pokemon.item === 'choiceband' || pokemon.item === 'choicespecs') {
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			if (pokemon.item === 'choicescarf' || pokemon.item === 'choiceband' || pokemon.item === 'choicespecs') {
				return this.chainModify(1.5);
			}
		},
		id: "torrentialbeast",
		name: "Torrential Beast",
		rating: 4.5,
		num: 37,
	},
	"thunderousbeast": {
		shortDesc: "This Pokemon's is immune to being Choice Locked.",
		onUpdate: function (pokemon) {
			if (pokemon.volatiles['choicelock']) {
				this.add('-activate', pokemon, 'ability: Thunder Beast');
				pokemon.removeVolatile('choicelock');
			}
		},
		onTryAddVolatile: function (status, pokemon) {
			if (status.id === 'choicelock') return null;
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['thunderousbeasteffect']) target.removeVolatile('thunderousbeasteffect');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['thunderousbeasteffect']) defender.addVolatile('thunderousbeasteffect');
		},
		isBeast: true,
		id: "thunderousbeast",
		name: "Thunderous Beast",
		rating: 4.5,
		num: 37,
	},
	"hustle": {
		desc: "This Pokemon's Attack is multiplied by 1.5 and the accuracy of its physical attacks is multiplied by 0.8.",
		shortDesc: "This Pokemon's Attack is 1.5x and accuracy of its physical attacks is 0.8x.",
		// This should be applied directly to the stat as opposed to chaining witht he others
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk) {
			return this.modify(atk, 1.5);
		},
		onModifyMove: function (move) {
			if (move.category === 'Physical' && typeof move.accuracy === 'number') {
				move.accuracy *= 0.8;
			}
		},
		id: "hustle",
		name: "Hustle",
		rating: 3,
		num: 55,
	},
	"hydration": {
		desc: "This Pokemon has its major status condition cured at the end of each turn if Rain Dance is active.",
		shortDesc: "This Pokemon has its status cured at the end of each turn if Rain Dance is active.",
		onResidualOrder: 5,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.status && this.isWeather(['raindance', 'primordialsea'])) {
				this.debug('hydration');
				this.add('-activate', pokemon, 'ability: Hydration');
				pokemon.cureStatus();
			}
		},
		id: "hydration",
		name: "Hydration",
		rating: 2,
		num: 93,
	},
	"hypercutter": {
		shortDesc: "Prevents other Pokemon from lowering this Pokemon's Attack stat stage.",
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			if (boost['atk'] && boost['atk'] < 0) {
				delete boost['atk'];
				if (!effect.secondaries) this.add("-fail", target, "unboost", "Attack", "[from] ability: Hyper Cutter", "[of] " + target);
			}
		},
		id: "hypercutter",
		name: "Hyper Cutter",
		rating: 1.5,
		num: 52,
	},
	"icebody": {
		desc: "If Hail is active, this Pokemon restores 1/10 of its maximum HP, rounded down, at the end of each turn. This Pokemon takes no damage from Hail.",
		shortDesc: "If Hail is active, this Pokemon heals 1/10 of its max HP each turn; immunity to Hail.",
		onWeather: function (target, source, effect) {
			if (effect.id === 'hail') {
				this.heal(target.maxhp / 5);
			}
		},
		onImmunity: function (type, pokemon) {
			if (type === 'hail') return false;
		},
		id: "icebody",
		name: "Ice Body",
		rating: 4.5,
		num: 115,
	},
	"illuminate": {
		shortDesc: "Has competitive use.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && (move.type === 'Electric' || move.type === 'Fairy' || move.type === 'Fire')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Dark' || move.type === 'Poison') {
				this.debug('Illuminate neutralize');
				return this.chainModify(0.5);
			}
		},
		id: "illuminate",
		name: "Illuminate",
		rating: 3,
		num: 35,
	},
	"illusion": {
		desc: "When this Pokemon switches in, it appears as the last unfainted Pokemon in its party until it takes direct damage from another Pokemon's attack. This Pokemon's actual level and HP are displayed instead of those of the mimicked Pokemon.",
		shortDesc: "This Pokemon appears as the last Pokemon in the party until it takes direct damage.",
		onBeforeSwitchIn: function (pokemon) {
			pokemon.illusion = null;
			let i;
			for (i = pokemon.side.pokemon.length - 1; i > pokemon.position; i--) {
				if (!pokemon.side.pokemon[i]) continue;
				if (!pokemon.side.pokemon[i].fainted) break;
			}
			if (!pokemon.side.pokemon[i]) return;
			if (pokemon === pokemon.side.pokemon[i]) return;
			pokemon.illusion = pokemon.side.pokemon[i];
		},
		// illusion clearing is hardcoded in the damage function
		id: "illusion",
		name: "Illusion",
		rating: 4.5,
		num: 149,
	},
	"immunity": {
		shortDesc: "This Pokemon cannot be poisoned. Gaining this Ability while poisoned cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.status === 'psn' || pokemon.status === 'tox') {
				this.add('-activate', pokemon, 'ability: Immunity');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'psn' && status.id !== 'tox') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Immunity');
			return false;
		},
		id: "immunity",
		name: "Immunity",
		rating: 2,
		num: 17,
	},
	"imposter": {
		desc: "On switch-in, this Pokemon Transforms into the opposing Pokemon that is facing it. If there is no Pokemon at that position, this Pokemon does not Transform.",
		shortDesc: "On switch-in, this Pokemon Transforms into the opposing Pokemon that is facing it.",
		id: "imposter",
		isNonstandard: true,
		name: "Imposter",
		isUnreleased: true,
		rating: 4.5,
		num: 150,
	},
	"infiltrator": {
		desc: "This Pokemon's moves ignore substitutes and the opposing side's Reflect, Light Screen, Safeguard, and Mist.",
		shortDesc: "Moves ignore substitutes and opposing Reflect, Light Screen, Safeguard, and Mist.",
		onModifyMove: function (move) {
			move.infiltrates = true;
		},
		id: "infiltrator",
		name: "Infiltrator",
		rating: 3,
		num: 151,
	},
	"innardsout": {
		desc: "If this Pokemon is knocked out with a move, that move's user loses HP equal to the amount of damage inflicted on this Pokemon.",
		shortDesc: "If this Pokemon is KOed with a move, that move's user loses an equal amount of HP.",
		id: "innardsout",
		name: "Innards Out",
		onAfterDamageOrder: 1,
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.effectType === 'Move' && !target.hp) {
				this.damage(damage / 3, source, target);
			}
		},
		rating: 2.5,
		num: 215,
	},
	"innerfocus": {
		shortDesc: "This Pokemon cannot be made to flinch.",
		onFlinch: false,
		id: "innerfocus",
		name: "Inner Focus",
		rating: 1.5,
		num: 39,
	},
	"insomnia": {
		shortDesc: "This Pokemon cannot fall asleep. Gaining this Ability while asleep cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.status === 'slp') {
				this.add('-activate', pokemon, 'ability: Insomnia');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'slp') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Insomnia');
			return false;
		},
		id: "insomnia",
		name: "Insomnia",
		rating: 2,
		num: 15,
	},
	"intimidate": {
		desc: "On switch-in, this Pokemon lowers the Attack of adjacent opposing Pokemon by 1 stage. Pokemon behind a substitute are immune.",
		shortDesc: "On switch-in, this Pokemon lowers the Attack of adjacent opponents by 1 stage.",
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (!pokemon.hp) return;
			for (let i = 0; i < pokemon.side.foe.active.length; i++) {
				let target = pokemon.side.foe.active[i];
				if (!target || !target.hp) continue;
				if (target.hp) {
					this.damage(target.maxhp / 10, target, pokemon);
				}
			}
		},
		id: "intimidate",
		name: "Intimidate",
		rating: 4,
		num: 22,
	},
	"spectralveil": {
		desc: ".",
		shortDesc: ".",
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.heal(pokemon.maxhp / 10);
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, target, source);
			return null;
		},
		onAllyTryHitSide: function (target, source, move) {
			if (target.side === source.side || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, this.effectData.target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "spectralveil",
		name: "Spectral Veil",
		rating: 4,
		num: 22,
	},
	"specveilold": {
		desc: ".",
		shortDesc: ".",
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			this.heal(pokemon.maxhp / 16);
			if (!pokemon.hp) return;
			for (let i = 0; i < pokemon.side.foe.active.length; i++) {
				let target = pokemon.side.foe.active[i];
				if (!target || !target.hp) continue;
				if (target.hp) {
					this.damage(target.maxhp / 16, target, pokemon);
				}
			}
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, target, source);
			return null;
		},
		onAllyTryHitSide: function (target, source, move) {
			if (target.side === source.side || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, this.effectData.target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "specveilold",
		isNonstandard: true,
		name: "SpecVeil Old",
		rating: 5,
		num: 22,
	},
	"ironbarbs": {
		desc: "Pokemon making contact with this Pokemon lose 1/8 of their maximum HP, rounded down.",
		shortDesc: "Pokemon making contact with this Pokemon lose 1/8 of their max HP.",
		onAfterDamageOrder: 1,
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.flags['contact']) {
				this.damage(source.maxhp / 8, source, target);
			}
		},
		id: "ironbarbs",
		name: "Iron Barbs",
		rating: 3,
		num: 160,
	},
	"ironfist": {
		desc: "This Pokemon's punch-based attacks have their power multiplied by 1.3.",
		shortDesc: "This Pokemon's punch-based attacks have 1.3x power. Sucker Punch is not boosted.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['punch']) {
				this.debug('Iron Fist boost');
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "ironfist",
		name: "Iron Fist",
		rating: 3,
		num: 89,
	},
	"perfectsword": {
		desc: "This Pokemon's sword-based attacks have their power multiplied by 1.5.",
		shortDesc: "This Pokemon's sword-based attacks have 1.5x power.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['sword']) {
				this.debug('Perfect Sword boost');
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "perfectsword",
		name: "Perfect Sword",
		rating: 3,
		num: 89,
	},
	"sharpenedsword": {
		desc: "This Pokemon's sword-based attacks have their power multiplied by 1.5.",
		shortDesc: "This Pokemon's sword-based attacks have 1.5x power.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['sword']) {
				this.debug('Perfect Sword boost');
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		id: "sharpenedsword",
		name: "Sharpened Sword",
		rating: 3,
		num: 89,
	},
	"sharpness": {
		desc: "This Pokemon's punch-based attacks have their power multiplied by 1.3.",
		shortDesc: "This Pokemon's punch-based attacks have 1.3x power. Sucker Punch is not boosted.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['slicing']) {
				this.debug('Sharpness boost');
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "sharpness",
		name: "Sharpness",
		rating: 3.5,
		num: 89,
	},
	"justified": {
		shortDesc: "This Pokemon's Attack is raised by 1 stage after it is damaged by a Dark-type move.",
		onAfterDamage: function (damage, target, source, effect) {
			if (effect && effect.type === 'Dark') {
				this.boost({atk:2});
			}
		},
		id: "justified",
		name: "Justified",
		rating: 2,
		num: 154,
	},
	"keeneye": {
		desc: "Prevents other Pokemon from lowering this Pokemon's accuracy stat stage. This Pokemon ignores a target's evasiveness stat stage.",
		shortDesc: "This Pokemon's accuracy can't be lowered by others; ignores their evasiveness stat.",
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			if (boost['accuracy'] && boost['accuracy'] < 0) {
				delete boost['accuracy'];
				if (!effect.secondaries) this.add("-fail", target, "unboost", "accuracy", "[from] ability: Keen Eye", "[of] " + target);
			}
		},
		onModifyMove: function (move) {
			move.ignoreEvasion = true;
			move.willCrit = true;
		},
		id: "keeneye",
		name: "Keen Eye",
		rating: 3,
		num: 51,
	},
	"klutz": {
		desc: "This Pokemon's held item has no effect. This Pokemon cannot use Fling successfully. Macho Brace, Power Anklet, Power Band, Power Belt, Power Bracer, Power Lens, and Power Weight still have their effects.",
		shortDesc: "This Pokemon's held item has no effect, except Macho Brace. Fling cannot be used.",
		// Item suppression implemented in BattlePokemon.ignoringItem() within battle-engine.js
		onModifyMove: function (move, source, target) {
			if (!move || target === source || (move.category !== 'Physical' && move.category !== 'Special')) return;
			if (!move.secondaries) {
				move.secondaries = [];
			}
			move.secondaries.push({
				chance: 50,
				volatileStatus: 'takeitem',
				ability: this.getAbility('klutz'),
			});
		},
		id: "klutz",
		name: "Klutz",
		rating: 2,
		num: 103,
	},
	"klutzbackup": {
		desc: "This Pokemon's held item has no effect. This Pokemon cannot use Fling successfully. Macho Brace, Power Anklet, Power Band, Power Belt, Power Bracer, Power Lens, and Power Weight still have their effects.",
		shortDesc: "This Pokemon's held item has no effect, except Macho Brace. Fling cannot be used.",
		// Item suppression implemented in BattlePokemon.ignoringItem() within battle-engine.js
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move && (move.category === 'Physical' || move.category === 'Special') && (this.random(2) === 0) && target.hp) {
				let item = target.takeItem()
				if (item) {
					this.add('-ability', pokemon, 'Klutz');
					this.add('-enditem', target, item.name);
				}
			}
		},
		id: "klutzbackup",
		isNonstandard: true,
		name: "Klutz Backup",
		rating: 2,
		num: 103,
	},
	"goldentouch": {
		shortDesc: "This Pokemon's contact moves have a 30% chance of poisoning.",
		onModifyMove: function (move, source, target) {
			if (!move || (move.category !== 'Physical' && move.category !== 'Special')) return;
			if (!move.secondaries) {
				move.secondaries = [];
			}
			move.secondaries.push({
				chance: 100,
				volatileStatus: 'nyasudrop',
				ability: this.getAbility('goldentouch'),
			});
		},
		id: "goldentouch",
		name: "Golden Touch",
		rating: 4,
		num: 143,
	},
	"leafguard": {
		desc: "If Sunny Day is active, this Pokemon cannot gain a major status condition and Rest will fail for it.",
		shortDesc: "If Sunny Day is active, this Pokemon cannot be statused and Rest will fail for it.",
		onSetStatus: function (status, target, source, effect) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				if (effect && effect.status) this.add('-immune', target, '[msg]', '[from] ability: Leaf Guard');
				return false;
			}
		},
		onTryAddVolatile: function (status, target) {
			if (status.id === 'yawn' && this.isWeather(['sunnyday', 'desolateland'])) {
				this.add('-immune', target, '[msg]', '[from] ability: Leaf Guard');
				return null;
			}
		},
		id: "leafguard",
		name: "Leaf Guard",
		rating: 1,
		num: 102,
	},
	"levitate": {
		desc: "This Pokemon is immune to Ground. Gravity, Ingrain, Smack Down, Thousand Arrows, and Iron Ball nullify the immunity.",
		shortDesc: "This Pokemon is immune to Ground; Gravity/Ingrain/Smack Down/Iron Ball nullify it.",
		// airborneness implemented in battle-engine.js:BattlePokemon#isGrounded
		id: "levitate",
		name: "Levitate",
		rating: 3.5,
		num: 26,
	},
	"lightmetal": {
		shortDesc: "This Pokemon's weight is halved.",
		onModifyWeight: function (weight) {
			return weight / 2;
		},
		id: "lightmetal",
		name: "Light Metal",
		rating: 1,
		num: 135,
	},
	"lightningrod": {
		desc: "This Pokemon is immune to Electric-type moves and raises its Special Attack by 1 stage when hit by an Electric-type move. If this Pokemon is not the target of a single-target Electric-type move used by another Pokemon, this Pokemon redirects that move to itself if it is within the range of that move.",
		shortDesc: "This Pokemon draws Electric moves to itself to raise Sp. Atk by 1; Electric immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Electric') {
				if (!this.boost({spa:1})) {
					this.add('-immune', target, '[msg]', '[from] ability: Lightning Rod');
				}
				return null;
			}
		},
		onAnyRedirectTarget: function (target, source, source2, move) {
			if (move.type !== 'Electric' || move.id in {firepledge:1, grasspledge:1, waterpledge:1}) return;
			if (this.validTarget(this.effectData.target, source, move.target)) {
				if (this.effectData.target !== target) {
					this.add('-activate', this.effectData.target, 'ability: Lightning Rod');
				}
				return this.effectData.target;
			}
		},
		id: "lightningrod",
		name: "Lightning Rod",
		rating: 3.5,
		num: 32,
	},
	"limber": {
		shortDesc: "This Pokemon cannot be paralyzed. Gaining this Ability while paralyzed cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				this.add('-activate', pokemon, 'ability: Limber');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Limber');
			return false;
		},
		id: "limber",
		name: "Limber",
		rating: 1.5,
		num: 7,
	},
	"liquidooze": {
		shortDesc: "This Pokemon damages those draining HP from it for as much as they would heal.",
		id: "liquidooze",
		onSourceTryHeal: function (damage, target, source, effect) {
			this.debug("Heal is occurring: " + target + " <- " + source + " :: " + effect.id);
			let canOoze = {drain: 1, leechseed: 1};
			if (canOoze[effect.id]) {
				this.damage(damage);
				return 0;
			}
		},
		name: "Liquid Ooze",
		rating: 1.5,
		num: 64,
	},
	"liquidvoice": {
		desc: "This Pokemon's sound-based moves become Water-type moves. This effect comes after other effects that change a move's type, but before Ion Deluge and Electrify's effects.",
		shortDesc: "This Pokemon's sound-based moves become Water type.",
		onModifyMovePriority: -1,
		onModifyMove: function (move) {
			if (move.flags['sound']) {
				move.type = 'Water';
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.flags['sound']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "liquidvoice",
		name: "Liquid Voice",
		rating: 2.5,
		num: 204,
	},
	"longreach": {
		shortDesc: "This Pokemon's attacks do not make contact with the target.",
		onModifyMove: function (move) {
			delete move.flags['contact'];
		},
		id: "longreach",
		name: "Long Reach",
		rating: 1.5,
		num: 203,
	},
	"pokemonmaster": {
		shortDesc: "This Pokemon's attacks do not make contact with the target.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Pokemon Master');
			this.add('-message', "" + pokemon.name + " places its trust in you!");
		},
		onModifyMove: function (move) {
			delete move.flags['contact'];
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type !== 'Electric') {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "pokemonmaster",
		name: "Pokemon Master",
		rating: 3.5,
		num: 203,
	},
	"alolaschampion": {
		shortDesc: "This Pokemon's attacks do not make contact with the target.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Alola\'s Champion');
			this.add('-message', "" + pokemon.name + " is burning with passion!");
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && !pokemon.volatiles['zenryoku']) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod > 0) {
				this.debug('Alola neutralize');
				return this.chainModify(0.67);
			}
		},
		onBoost: function (boost, target, source, effect) {
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Alola\'s Champion", "[of] " + target);
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (!pokemon.volatiles['zenryoku']) {
				pokemon.addVolatile('zenryoku');
			}
			if ((!target || target.fainted || target.hp <= 0) && pokemon.volatiles['zenryoku']) {
				pokemon.removeVolatile('zenryoku');
			}
		},
		id: "alolaschampion",
		name: "Alola's Champion",
		rating: 3.5,
		num: 203,
	},
	"magicbounce": {
		desc: "This Pokemon blocks certain status moves and instead uses the move against the original user.",
		shortDesc: "This Pokemon blocks certain status moves and bounces them back to the user.",
		id: "magicbounce",
		name: "Magic Bounce",
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, target, source);
			return null;
		},
		onAllyTryHitSide: function (target, source, move) {
			if (target.side === source.side || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, this.effectData.target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		id: "magicbounce",
		name: "Magic Bounce",
		rating: 4.5,
		num: 156,
	},
	"magicguard": {
		desc: "This Pokemon can only be damaged by direct attacks. Curse and Substitute on use, Belly Drum, Pain Split, Struggle recoil, and confusion damage are considered direct damage.",
		shortDesc: "This Pokemon can only be damaged by direct attacks.",
		onDamage: function (damage, target, source, effect) {
			if (effect.effectType !== 'Move') {
				return false;
			}
		},
		onCriticalHit: false,
		id: "magicguard",
		name: "Magic Guard",
		rating: 4.5,
		num: 98,
	},
	"magician": {
		desc: "If this Pokemon has no item, it steals the item off a Pokemon it hits with an attack. Does not affect Doom Desire and Future Sight.",
		shortDesc: "If this Pokemon has no item, it steals the item off a Pokemon it hits with an attack.",
		onSourceHit: function (target, source, move) {
			if (!move || !target) return;
			if (target !== source && move.category !== 'Status') {
				if (source.item || source.volatiles['gem'] || source.volatiles['fling']) return;
				let yourItem = target.takeItem(source);
				if (!yourItem) return;
				if (!source.setItem(yourItem)) {
					target.item = yourItem.id; // bypass setItem so we don't break choicelock or anything
					return;
				}
				this.add('-item', source, yourItem, '[from] ability: Magician', '[of] ' + target);
			}
		},
		id: "magician",
		name: "Magician",
		rating: 1.5,
		num: 170,
	},
	"magmaarmor": {
		shortDesc: "This Pokemon cannot be frozen. Gaining this Ability while frozen cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.status === 'frz') {
				this.add('-activate', pokemon, 'ability: Magma Armor');
				pokemon.cureStatus();
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if ((move.category === 'Physical' || move.flags['hitsdef']) && !move.flags['hitsspd']) {
				this.debug('Magma Armor Neutralize');
				return this.chainModify(0.5);
			}
		},
		onImmunity: function (type, pokemon) {
			if (type === 'frz') return false;
		},
		id: "magmaarmor",
		name: "Magma Armor",
		rating: 3.5,
		num: 40,
	},
	"magnetpull": {
		desc: "Prevents adjacent opposing Steel-type Pokemon from choosing to switch out unless they are immune to trapping.",
		shortDesc: "Prevents adjacent Steel-type foes from choosing to switch.",
		onFoeTrapPokemon: function (pokemon) {
			let condition = pokemon.getAbility();
			if (condition.isBreaker) return;
			if (pokemon.hasType('Steel') && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, this.effectData.target)) {
				pokemon.tryTrap(true);
			}
		},
		onFoeMaybeTrapPokemon: function (pokemon, source) {
			if (!source) source = this.effectData.target;
			if ((!pokemon.knownType || pokemon.hasType('Steel')) && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, source)) {
				pokemon.maybeTrapped = true;
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0 && target.hasType('Steel')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "magnetpull",
		name: "Magnet Pull",
		rating: 4.5,
		num: 42,
	},
	"marvelscale": {
		desc: "If this Pokemon has a major status condition, its Defense is multiplied by 1.5.",
		shortDesc: "If this Pokemon is statused, its Defense is 1.5x.",
		onModifyDefPriority: 6,
		onModifyDef: function (def, pokemon) {
			if (pokemon.status) {
				return this.chainModify(1.5);
			}
		},
		id: "marvelscale",
		name: "Marvel Scale",
		rating: 2.5,
		num: 63,
	},
	"megalauncher": {
		desc: "This Pokemon's pulse moves have their power multiplied by 1.5. Heal Pulse restores 3/4 of a target's maximum HP, rounded half down.",
		shortDesc: "This Pokemon's pulse moves have 1.5x power. Heal Pulse heals 3/4 target's max HP.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['pulse']) {
				return this.chainModify(1.5);
			}
		},
		id: "megalauncher",
		name: "Mega Launcher",
		rating: 3.5,
		num: 178,
	},
	"merciless": {
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['shatter']) {
				this.debug('Merciless boost');
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "merciless",
		name: "Merciless",
		rating: 2,
		num: 196,
	},
	"psnstatusscript": {
		shortDesc: "This Pokemon's attacks are critical hits if the target is poisoned.",
		onModifyCritRatio: function (critRatio, source, target) {
			if (target && target.status in {'psn':1, 'tox':1}) return 5;
		},
		id: "psnstatusscript",
		isNonstandard: true,
		name: "Psn Status Script",
		rating: 2,
		num: 196,
	},
	"minus": {
		desc: "If an active ally has this Ability or the Ability Plus, this Pokemon's Special Attack is multiplied by 1.5.",
		shortDesc: "If an active ally has this Ability or the Ability Plus, this Pokemon's Sp. Atk is 1.5x.",
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			let allyActive = pokemon.side.active;
			if (allyActive.length === 1) {
				return;
			}
			for (let i = 0; i < allyActive.length; i++) {
				if (allyActive[i] && allyActive[i].position !== pokemon.position && !allyActive[i].fainted && allyActive[i].hasAbility(['minus', 'plus'])) {
					return this.chainModify(1.5);
				}
			}
		},
		id: "minus",
		name: "Minus",
		rating: 0,
		num: 58,
	},
	"mistysurge": {
		shortDesc: "On switch-in, this Pokemon summons Misty Terrain.",
		onStart: function (source) {
			this.setTerrain('mistyterrain');
		},
		id: "mistysurge",
		isNonstandard: true,
		name: "Misty Surge",
		rating: 4,
		num: 228,
	},
	"moldbreaker": {
		shortDesc: "This Pokemon's moves and their effects ignore the Abilities of other Pokemon.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Mold Breaker');
		},
		onModifyMove: function (move) {
			move.ignoreAbility = true;
		},
		id: "moldbreaker",
		isBreaker: true,
		name: "Mold Breaker",
		rating: 3.5,
		num: 104,
	},
	"moody": {
		desc: "This Pokemon has a random stat raised by 2 stages and another stat lowered by 1 stage at the end of each turn.",
		shortDesc: "Raises a random stat by 2 and lowers another stat by 1 at the end of each turn.",
		onSwitchIn: function (pokemon) {
			let stats = [];
			let boost = {};
			for (let statPlus in pokemon.baseStats) {
				if (pokemon.boosts[statPlus] < 6) {
					stats.push(statPlus);
				}
			}
			let randomStat = stats.length ? stats[this.random(stats.length)] : "";
			let randomStats = stats.length ? stats[this.random(stats.length)] : "";
			let randomStatr = stats.length ? stats[this.random(stats.length)] : "";
			let randomStatz = stats.length ? stats[this.random(stats.length)] : "";
			if (randomStat) {
				if (pokemon.item === 'cloversweet') {
					boost[randomStat] = 1;
				} else {
					boost[randomStat] = 2;
				}
			}
			if (randomStats) {
				if (pokemon.item === 'cloversweet') {
					boost[randomStats] = 1;
				} 
			}
			stats = [];
			for (let statMinus in pokemon.baseStats) {
				if (pokemon.boosts[statMinus] > -6 && statMinus !== randomStat) {
					stats.push(statMinus);
				}
			}
			randomStat = stats.length ? stats[this.random(stats.length)] : "";
			if (randomStat) boost[randomStat] = -1;

			this.boost(boost);
		},
		id: "moody",
		name: "Moody",
		rating: 5,
		num: 141,
	},
	"motordrive": {
		desc: "This Pokemon is immune to Electric-type moves and raises its Speed by 1 stage when hit by an Electric-type move.",
		shortDesc: "This Pokemon's Speed is raised 1 stage if hit by an Electric move; Electric immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Electric') {
				if (!this.boost({spe:1})) {
					this.add('-immune', target, '[msg]', '[from] ability: Motor Drive');
				}
				return null;
			}
		},
		id: "motordrive",
		name: "Motor Drive",
		rating: 3,
		num: 78,
	},
	"moxie": {
		desc: "This Pokemon's Attack is raised by 1 stage if it attacks and knocks out another Pokemon.",
		shortDesc: "This Pokemon's Attack is raised by 1 stage if it attacks and KOes another Pokemon.",
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && !source.volatiles['moxiecheck']) {
				this.boost({atk:1}, source);
				source.addVolatile('moxiecheck');
			}
		},
		id: "moxie",
		name: "Moxie",
		rating: 3.5,
		num: 153,
	},
	"multiscale": {
		shortDesc: "If this Pokemon is at full HP, damage taken from attacks is halved.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (target.hp >= target.maxhp && !move.flags['descale']) {
				this.debug('Multiscale weaken');
				return this.chainModify(0.5);
			}
		},
		id: "multiscale",
		name: "Multiscale",
		rating: 4,
		num: 136,
	},
	"dragonheart": {
		shortDesc: "If this Pokemon is at full HP, damage taken from attacks is halved.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if ((move.category === 'Physical' || move.flags['hitsdef']) && !move.flags['descale'] && !move.flags['hitsspd'] && target.hp >= target.maxhp / 2) {
				this.debug('Multiscale weaken');
				return this.chainModify(0.5);
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.positiveBoosts()) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "dragonheart",
		name: "Dragon Heart",
		rating: 4,
		num: 136,
	},
	"multitype": {
		shortDesc: "If this Pokemon is an Arceus, its type changes to match its held Plate or Z-Crystal.",
		// Multitype's type-changing itself is implemented in statuses.js
		onSwitchOut: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isPlate || item.isMemory) pokemon.heal(pokemon.maxhp / 3);
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Multitype neutralize');
				return this.chainModify(0.5);
			}
		},
		id: "multitype",
		name: "Multitype",
		switchHealing: true,
		rating: 4.5,
		num: 121,
	},
	"mummy": {
		desc: "Pokemon making contact with this Pokemon have their Ability changed to Mummy. Does not affect the Abilities Multitype or Stance Change.",
		shortDesc: "Pokemon making contact with this Pokemon have their Ability changed to Mummy.",
		id: "mummy",
		name: "Mummy",
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.flags['contact']) {
				let oldAbility = source.setAbility('mummy', source, 'mummy', true);
				if (oldAbility) {
					this.add('-activate', target, 'ability: Mummy', this.getAbility(oldAbility).name, '[of] ' + source);
				}
			}
		},
		rating: 2,
		num: 152,
	},
	"naturalcure": {
		shortDesc: "This Pokemon has its major status condition cured when it switches out.",
		onCheckShow: function (pokemon) {
			// This is complicated
			// For the most part, in-game, it's obvious whether or not Natural Cure activated,
			// since you can see how many of your opponent's pokemon are statused.
			// The only ambiguous situation happens in Doubles/Triples, where multiple pokemon
			// that could have Natural Cure switch out, but only some of them get cured.
			if (pokemon.side.active.length === 1) return;
			if (pokemon.showCure === true || pokemon.showCure === false) return;

			let active = pokemon.side.active;
			let cureList = [];
			let noCureCount = 0;
			for (let i = 0; i < active.length; i++) {
				let curPoke = active[i];
				// pokemon not statused
				if (!curPoke || !curPoke.status) {
					// this.add('-message', "" + curPoke + " skipped: not statused or doesn't exist");
					continue;
				}
				if (curPoke.showCure) {
					// this.add('-message', "" + curPoke + " skipped: Natural Cure already known");
					continue;
				}
				let template = Tools.getTemplate(curPoke.species);
				// pokemon can't get Natural Cure
				if (Object.values(template.abilities).indexOf('Natural Cure') < 0) {
					// this.add('-message', "" + curPoke + " skipped: no Natural Cure");
					continue;
				}
				// pokemon's ability is known to be Natural Cure
				if (!template.abilities['1'] && !template.abilities['H']) {
					// this.add('-message', "" + curPoke + " skipped: only one ability");
					continue;
				}
				// pokemon isn't switching this turn
				if (curPoke !== pokemon && !this.willSwitch(curPoke)) {
					// this.add('-message', "" + curPoke + " skipped: not switching");
					continue;
				}

				if (curPoke.hasAbility('naturalcure')) {
					// this.add('-message', "" + curPoke + " confirmed: could be Natural Cure (and is)");
					cureList.push(curPoke);
				} else {
					// this.add('-message', "" + curPoke + " confirmed: could be Natural Cure (but isn't)");
					noCureCount++;
				}
			}

			if (!cureList.length || !noCureCount) {
				// It's possible to know what pokemon were cured
				for (let i = 0; i < cureList.length; i++) {
					cureList[i].showCure = true;
				}
			} else {
				// It's not possible to know what pokemon were cured

				// Unlike a -hint, this is real information that battlers need, so we use a -message
				this.add('-message', "(" + cureList.length + " of " + pokemon.side.name + "'s pokemon " + (cureList.length === 1 ? "was" : "were") + " cured by Natural Cure.)");

				for (let i = 0; i < cureList.length; i++) {
					cureList[i].showCure = false;
				}
			}
		},
		onSwitchOut: function (pokemon) {
			if (!pokemon.status) return;

			// if pokemon.showCure is undefined, it was skipped because its ability
			// is known
			if (pokemon.showCure === undefined) pokemon.showCure = true;

			if (pokemon.showCure) this.add('-curestatus', pokemon, pokemon.status, '[from] ability: Natural Cure');
			pokemon.setStatus('');

			// only reset .showCure if it's false
			// (once you know a Pokemon has Natural Cure, its cures are always known)
			if (!pokemon.showCure) delete pokemon.showCure;
		},
		id: "naturalcure",
		name: "Natural Cure",
		rating: 3.5,
		num: 30,
	},
	"noguard": {
		shortDesc: "Every move used by or against this Pokemon will always hit.",
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move && (source === this.effectData.target || target === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		id: "noguard",
		name: "No Guard",
		rating: 4,
		num: 99,
	},
	"normalize": {
		desc: "This Pokemon's moves are changed to be Normal type and have their power multiplied by 1.2. This effect comes before other effects that change a move's type.",
		shortDesc: "This Pokemon's moves are changed to be Normal type and have 1.2x power.",
		onModifyMovePriority: 1,
		onModifyMove: function (move, pokemon) {
			if (!move.isZ && move.id !== 'struggle' && this.getMove(move.id).type !== 'Normal') {
				move.type = 'Normal';
			}
			if (move.category !== 'Status') pokemon.addVolatile('normalize');
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x14CD, 0x1000]);
			},
		},
		id: "normalize",
		isSuffix: true,
		name: "Normalize",
		rating: -1,
		num: 96,
	},
	"oblivious": {
		desc: "This Pokemon cannot be infatuated or taunted. Gaining this Ability while affected cures it.",
		shortDesc: "This Pokemon cannot be infatuated or taunted. Gaining this Ability cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.volatiles['attract']) {
				this.add('-activate', pokemon, 'ability: Oblivious');
				pokemon.removeVolatile('attract');
				this.add('-end', pokemon, 'move: Attract', '[from] ability: Oblivious');
			}
			if (pokemon.volatiles['taunt']) {
				this.add('-activate', pokemon, 'ability: Oblivious');
				pokemon.removeVolatile('taunt');
				// Taunt's volatile already sends the -end message when removed
			}
		},
		onImmunity: function (type, pokemon) {
			if (type === 'attract') return false;
		},
		onTryHit: function (pokemon, target, move) {
			if (move.id === 'attract' || move.id === 'captivate' || move.id === 'taunt') {
				this.add('-immune', pokemon, '[msg]', '[from] ability: Oblivious');
				return null;
			}
		},
		id: "oblivious",
		name: "Oblivious",
		rating: 1,
		num: 12,
	},
	"overcoat": {
		shortDesc: "This Pokemon is immune to powder moves and damage from Sandstorm or Hail.",
		onImmunity: function (type, pokemon) {
			if (type === 'sandstorm' || type === 'hail' || type === 'powder') return false;
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (move.flags['powder'] && target !== source && this.getImmunity('powder', target)) {
				this.add('-immune', target, '[msg]', '[from] ability: Overcoat');
				return null;
			}
		},
		id: "overcoat",
		name: "Overcoat",
		rating: 2.5,
		num: 142,
	},
	"overgrow": {
		desc: "When this Pokemon has 1/2 or less of its maximum HP, its attacking stat is multiplied by 1.5 while using a Grass-type attack.",
		shortDesc: "When this Pokemon has 1/2 or less of its max HP, its Grass attacks do 1.5x damage.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, attacker, defender, move) {
			if (move.type === 'Grass' && attacker.hp <= attacker.maxhp / 2) {
				this.debug('Overgrow boost');
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (atk, attacker, defender, move) {
			if (move.type === 'Grass' && attacker.hp <= attacker.maxhp / 2) {
				this.debug('Overgrow boost');
				return this.chainModify(1.5);
			}
		},
		id: "overgrow",
		name: "Overgrow",
		rating: 2,
		num: 65,
	},
	"owntempo": {
		shortDesc: "This Pokemon cannot be confused. Gaining this Ability while confused cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.volatiles['confusion']) {
				this.add('-activate', pokemon, 'ability: Own Tempo');
				pokemon.removeVolatile('confusion');
			}
		},
		onTryAddVolatile: function (status, pokemon) {
			if (status.id === 'confusion') return null;
		},
		onHit: function (target, source, move) {
			if (move && move.volatileStatus === 'confusion') {
				this.add('-immune', target, 'confusion', '[from] ability: Own Tempo');
			}
		},
		id: "owntempo",
		name: "Own Tempo",
		rating: 1,
		num: 20,
	},
	"parentalbond": {
		desc: "This Pokemon's damaging moves become multi-hit moves that hit twice. The second hit has its damage quartered. Does not affect multi-hit moves or moves that have multiple targets.",
		shortDesc: "This Pokemon's damaging moves hit twice. The second hit has its damage quartered.",
		onPrepareHit: function (source, target, move) {
			if (move.id in {iceball: 1, rollout: 1}) return;
			if (move.category !== 'Status' && !move.selfdestruct && !move.multihit && !move.flags['charge'] && !move.flags['preset'] && !move.spreadHit && !move.isZ) {
				move.multihit = 2;
				source.addVolatile('parentalbond');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower) {
				if (this.effectData.hit) {
					this.effectData.hit++;
					return this.chainModify(0.25);
				} else {
					this.effectData.hit = 1;
				}
			},
			onSourceModifySecondaries: function (secondaries, target, source, move) {
				if (move.id === 'secretpower' && this.effectData.hit < 2) {
					// hack to prevent accidentally suppressing King's Rock/Razor Fang
					return secondaries.filter(effect => effect.volatileStatus === 'flinch');
				}
			},
		},
		id: "parentalbond",
		name: "Parental Bond",
		rating: 5,
		num: 184,
	},
	"pickup": {
		shortDesc: "If this Pokemon has no item, it finds one used by an adjacent Pokemon this turn.",
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.item) return;
			let pickupTargets = [];
			let allActives = pokemon.side.active.concat(pokemon.side.foe.active);
			for (let i = 0; i < allActives.length; i++) {
				let target = allActives[i];
				if (target.lastItem && target.usedItemThisTurn && this.isAdjacent(pokemon, target)) {
					pickupTargets.push(target);
				}
			}
			if (!pickupTargets.length) return;
			let randomTarget = pickupTargets[this.random(pickupTargets.length)];
			pokemon.setItem(randomTarget.lastItem);
			randomTarget.lastItem = '';
			let item = pokemon.getItem();
			this.add('-item', pokemon, item, '[from] ability: Pickup');
		},
		id: "pickup",
		name: "Pickup",
		rating: 0.5,
		num: 53,
	},
	"pickpocket": {
		desc: "If this Pokemon has no item, it steals the item off a Pokemon that makes contact with it. This effect applies after all hits from a multi-hit move; Sheer Force prevents it from activating if the move has a secondary effect.",
		shortDesc: "If this Pokemon has no item, it steals the item off a Pokemon making contact with it.",
		onAfterMoveSecondary: function (target, source, move) {
			if (source && source !== target && move && move.flags['contact']) {
				if (target.item) {
					return;
				}
				let yourItem = source.takeItem(target);
				if (!yourItem) {
					return;
				}
				if (!target.setItem(yourItem)) {
					source.item = yourItem.id;
					return;
				}
				this.add('-item', target, yourItem, '[from] ability: Pickpocket', '[of] ' + source);
			}
		},
		id: "pickpocket",
		name: "Pickpocket",
		rating: 1,
		num: 124,
	},
	"pixilate": {
		desc: "This Pokemon's Normal-type moves become Fairy-type moves and have their power multiplied by 1.2. This effect comes after other effects that change a move's type, but before Ion Deluge and Electrify's effects.",
		shortDesc: "This Pokemon's Normal-type moves become Fairy type and have 1.2x power.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.type === 'Normal' && move.id !== 'naturalgift' && !move.isZ) {
				move.type = 'Fairy';
				if (move.category !== 'Status') pokemon.addVolatile('pixilate');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x1333, 0x1000]);
			},
		},
		id: "pixilate",
		isSuffix: true,
		name: "Pixilate",
		rating: 4,
		num: 182,
	},
	"plus": {
		desc: "If an active ally has this Ability or the Ability Minus, this Pokemon's Special Attack is multiplied by 1.5.",
		shortDesc: "If an active ally has this Ability or the Ability Minus, this Pokemon's Sp. Atk is 1.5x.",
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			let allyActive = pokemon.side.active;
			if (allyActive.length === 1) {
				return;
			}
			for (let i = 0; i < allyActive.length; i++) {
				if (allyActive[i] && allyActive[i].position !== pokemon.position && !allyActive[i].fainted && allyActive[i].hasAbility(['minus', 'plus'])) {
					return this.chainModify(1.5);
				}
			}
		},
		id: "plus",
		name: "Plus",
		rating: 0,
		num: 57,
	},
	"poisonheal": {
		desc: "If this Pokemon is poisoned, it restores 1/8 of its maximum HP, rounded down, at the end of each turn instead of losing HP.",
		shortDesc: "This Pokemon is healed by 1/8 of its max HP each turn when poisoned; no HP loss.",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Poison Heal');
				this.add('-message', "" + pokemon.name + " is surrounded by Toxins!");
				pokemon.trySetStatus('psn', pokemon);
			}
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'psn' || effect.id === 'tox') {
				this.heal(target.maxhp / 5);
				return false;
			}
		},
		onUpdate: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory && (pokemon.status !== 'psn' && pokemon.status !== 'tox')) {
				pokemon.trySetStatus('psn', pokemon);
			}
		},
		id: "poisonheal",
		name: "Poison Heal",
		rating: 4,
		num: 90,
	},
	"poisonpoint": {
		shortDesc: "30% chance a Pokemon making contact with this Pokemon will be poisoned.",
		onAfterDamage: function (damage, target, source, move) {
			if (move && move.flags['contact']) {
				if (this.random(10) < 3) {
					source.trySetStatus('psn', target);
				}
			}
		},
		id: "poisonpoint",
		name: "Poison Point",
		rating: 2,
		num: 38,
	},
	"poisontouch": {
		shortDesc: "This Pokemon's contact moves have a 30% chance of poisoning.",
		// upokecenter says this is implemented as an added secondary effect
		onModifyMove: function (move) {
			if (!move || !move.flags['contact']) return;
			if (!move.secondaries) {
				move.secondaries = [];
			}
			move.secondaries.push({
				chance: 30,
				status: 'psn',
				ability: this.getAbility('poisontouch'),
			});
		},
		id: "poisontouch",
		name: "Poison Touch",
		rating: 2,
		num: 143,
	},
	"powerconstruct": {
		desc: "If this Pokemon is a Zygarde in its 10% or 50% Forme, it changes to Complete Forme when it has 1/2 or less of its maximum HP at the end of the turn.",
		shortDesc: "If Zygarde 10%/50%, changes to Complete if at 1/2 max HP or less at end of turn.",
		onUpdate: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Zygarde' || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.template.speciesid === 'zygardecomplete' || (pokemon.hp > pokemon.maxhp / 2 && pokemon.item !== 'parkball')) return;
			this.add('-message', "You sense the presence of many cells!");
			this.add('-activate', pokemon, 'ability: Power Construct');
			let template = this.getTemplate('Zygarde-Complete');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-message', "" + pokemon.name + " transformed into its Complete Forme!");
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
			let newHP = Math.floor(Math.floor(2 * pokemon.template.baseStats['hp'] + pokemon.set.ivs['hp'] + Math.floor(pokemon.set.evs['hp'] / 4) + 100) * pokemon.level / 100 + 10);
			pokemon.hp = newHP;
			pokemon.maxhp = newHP;
			this.add('-heal', pokemon, pokemon.getHealth, '[silent]');
		},
		id: "powerconstruct",
		name: "Power Construct",
		rating: 4,
		num: 211,
	},
	"overmind": {
		shortDesc: "This Pokemon's Attack is doubled.",
		onUpdate: function (pokemon) {
			let over = Math.floor(Math.floor(2 * pokemon.template.baseStats['atk'] + pokemon.set.ivs['atk'] + Math.floor(pokemon.set.evs['atk'] / 4) + 100) * pokemon.level / 100 + 10);
			let mind = Math.floor(Math.floor(2 * pokemon.template.baseStats['spa'] + pokemon.set.ivs['spa'] + Math.floor(pokemon.set.evs['spa'] / 4) + 100) * pokemon.level / 100 + 10);
			let health = Math.floor(Math.floor(pokemon.hp));
			pokemon.stats.atk = Math.floor(Math.floor(over + health));
			pokemon.stats.spa = Math.floor(Math.floor(mind + health));
		},
		onBoost: function (boost, target, source, effect) {
			if (boost['atk'] && boost['atk'] > 0) {
				this.heal(target.maxhp / 4);
				delete boost['atk'];
			}
			if (boost['atk'] && boost['atk'] < 0) {
				this.damage(target.maxhp / 10);
				delete boost['atk'];
			}
			if (boost['spa'] && boost['spa'] > 0) {
				this.heal(target.maxhp / 4);
				delete boost['spa'];
			}
			if (boost['spa'] && boost['spa'] < 0) {
				this.damage(target.maxhp / 10);
				delete boost['spa'];
			}
		},
		id: "overmind",
		name: "Overmind",
		rating: 4.5,
		num: 37,
	},
	"powerconstruct2": {
		desc: "If this Pokemon is a Zygarde in its 10% or 50% Forme, it changes to Complete Forme when it has 1/2 or less of its maximum HP at the end of the turn.",
		shortDesc: "If Zygarde 10%/50%, changes to Complete if at 1/2 max HP or less at end of turn.",
		onUpdate: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Zygarde' || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.template.speciesid === 'zygardecomplete' || pokemon.hp > pokemon.maxhp / 2) return;
			this.add('-message', "You sense the presence of many cells!");
			this.add('-activate', pokemon, 'ability: Power Construct');
			let template = this.getTemplate('Zygarde-Complete');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-message', "" + pokemon.name + " transformed into its Complete Forme!");
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
			let newHP = Math.floor(Math.floor(2 * pokemon.template.baseStats['hp'] + pokemon.set.ivs['hp'] + Math.floor(pokemon.set.evs['hp'] / 4) + 100) * pokemon.level / 100 + 10);
			pokemon.hp = newHP - (pokemon.maxhp - pokemon.hp);
			pokemon.maxhp = newHP;
			this.add('-heal', pokemon, pokemon.getHealth, '[silent]');
		},
		id: "powerconstruct2",
		isNonstandard: true,
		name: "Power Construct2",
		rating: 4,
		num: 211,
	},
	"dragonpower": {
		shortDesc: "This Pokemon's Attack and Special Attack stats get increased by 1.2x.",
		onSwitchIn: function (pokemon) {
			this.add('-ability', pokemon, 'Dragon Power');
			this.add('-message', "" + pokemon.name + " is consumed with dragon energy!");
		},
		onModifyDamage: function (damage, source, target, move) {
			if ((move.type === 'Dragon' || move.type === 'Ice') && move.priority < 1 && move.typeMod > 0) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onSwitchOut: function (pokemon) {
			if (!pokemon.status) return;
			if (pokemon.status) {
				this.add('-ability', pokemon, 'Dragon Power');
				this.add('-curestatus', pokemon, pokemon.status);
				pokemon.setStatus('');
			}
		},
		onModifyMove: function (move) {
			move.ignoreAbility = true;
		},
		id: "dragonpower",
		name: "Dragon Power",
		isBreaker: true,
		rating: 4,
		num: 241,
	},
	"propeller": {
		shortDesc: "This Pokemon's Attack and Special Attack stats get increased by 1.2x.",
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if ((move && move.type === 'Flying') && user.hp >= user.maxhp) {
				return this.chainModify([0x2000, 0x1000]);
			}
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if ((!target || target.fainted || target.hp <= 0) && move.type === 'Flying' && !pokemon.volatiles['propellerused']) {
				if (pokemon.getStat('atk', false, true) >= pokemon.getStat('spa', false, true)) {
					this.boost({atk:1});
					pokemon.addVolatile('propellerused');
				} else {
					this.boost({spa:1});
					pokemon.addVolatile('propellerused');
				}
			}
		},
		id: "propeller",
		name: "Propeller",
		rating: 4,
		num: 241,
	},
	"powerofalchemy": {
		desc: "This Pokemon copies the Ability of an ally that faints. Abilities that cannot be copied are Flower Gift, Forecast, Illusion, Imposter, Multitype, Stance Change, Trace, Wonder Guard, and Zen Mode.",
		shortDesc: "This Pokemon copies the Ability of an ally that faints.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Power of Alchemy');
			this.add('-message', "" + pokemon.name + " is exercising its power!");
			pokemon.addVolatile('poaground');
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && (move.id === 'psystrike' || move.id === 'psyshock')) return;
			if (!target.volatiles['activechange']) return;
			if (move && move.effectType === 'Move' && type === 'Poison' && (move.type === 'Psychic') && !move.flags['exempt']) {
				return 0;
			}
		},
		onSourceBasePower: function (basePower, attacker, defender, move) {
			if ((move.category === 'Physical' || move.category === 'Special') && move.flags['burst']) {
				return this.chainModify(0.67);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			let condition = source.getAbility();
			if ((!condition.isMewtwo && !source.volatiles['mewtwoabilityflag']) && !source.volatiles['poastatboostignore'] && ((source.boosts.atk >= 1 && move.category === 'Physical') || (source.boosts.spa >= 1 && move.category === 'Special'))) {
				this.debug('Alchemy Neutralize');
				return this.chainModify(0.5);
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (effect.id === 'tailwind' || effect.id === 'trickroom') {
				this.attrLastMove('[still]');
				this.add('-activate', this.effectData.target, 'ability: Power of Alchemy');
				this.add('-message', "" + source.name + " cannot use this move!");
				return false;
			}
		},
		onCriticalHit: false,
		id: "powerofalchemy",
		name: "Power of Alchemy",
		rating: 4,
		num: 223,
	},
	"powerofalchemyold": {
		desc: "This Pokemon copies the Ability of an ally that faints. Abilities that cannot be copied are Flower Gift, Forecast, Illusion, Imposter, Multitype, Stance Change, Trace, Wonder Guard, and Zen Mode.",
		shortDesc: "This Pokemon copies the Ability of an ally that faints.",
		onAllyFaint: function (target) {
			if (!this.effectData.target.hp) return;
			let ability = this.getAbility(target.ability);
			let bannedAbilities = {comatose:1, flowergift:1, forecast:1, illusion:1, imposter:1, multitype:1, stancechange:1, trace:1, wonderguard:1, zenmode:1};
			if (bannedAbilities[target.ability]) return;
			this.add('-ability', this.effectData.target, ability, '[from] ability: Power of Alchemy', '[of] ' + target);
			this.effectData.target.setAbility(ability);
		},
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Light Inversion');
			this.add('-message', "" + pokemon.name + " is emitting a strange light!");
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Psychic' && (move.type === 'Dark' || move.type === 'Ghost') && !move.flags['exempt']) {
				return -2;
			} else if (move && move.effectType === 'Move' && type === 'Ghost' && (move.type === 'Dragon' || move.type === 'Fairy') && !move.flags['exempt']) {
				return 1;
			} else if (move && move.effectType === 'Move' && move.type === 'Psychic' && !move.flags['exempt']) {
				return 0;
			}
		},
		id: "powerofalchemyold",
		isNonstandard: true,
		name: "Power of Alchemy Old",
		rating: 0,
		num: 223,
	},
	"prankster": {
		shortDesc: "This Pokemon's Status moves have priority raised by 1, but Dark types are immune.",
		onModifyPriority: function (priority, pokemon, target, move) {
			if (pokemon.hp >= pokemon.maxhp / 2 && !pokemon.status && move && move.category === 'Status') {
				return priority + 1;
			}
		},
		onModifyMove: function (pokemon, move) {
			if (pokemon.hp >= pokemon.maxhp / 2 && !pokemon.status && move && move.category === 'Status') {
				move.pranksterBoosted = true;
			}
		},
		id: "prankster",
		name: "Prankster",
		rating: 4,
		num: 158,
	},
	"blissful": {
		shortDesc: ".",
		onModifyPriority: function (priority, pokemon, target, move) {
			if (!pokemon.status && move && move.type === 'Normal' && pokemon.hp <= pokemon.maxhp / 2) {
				return priority + 1;
			}
		},
		onModifyMove: function (move) {
			if (move && move.type === 'Normal') {
				move.blissfulBoosted = true;
			}
		},
		id: "blissful",
		name: "Blissful",
		rating: 2,
		num: 158,
	},
	"nimble": {
		shortDesc: "This Pokemon's Status moves have priority raised by 1, but Dark types are immune.",
		onModifyPriority: function (priority, pokemon, target, move) {
			if (move && move.category === 'Status') {
				return priority + 1;
			}
		},
		onModifyMove: function (pokemon, move) {
			if (move && move.category === 'Status') {
				move.nimbleBoosted = true;
			}
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).flags['parastatus']) {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		id: "nimble",
		name: "Nimble",
		rating: 4,
		num: 158,
	},
	"pressure": {
		desc: "If this Pokemon is the target of an opposing Pokemon's move, that move loses one additional PP.",
		shortDesc: "If this Pokemon is the target of a foe's move, that move loses one additional PP.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Pressure');
		},
		onDeductPP: function (target, source) {
			if (target.side === source.side) return;
			return 1;
		},
		id: "pressure",
		name: "Pressure",
		rating: 1.5,
		num: 46,
	},
	"windstreamer": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Wind Streamer');
			this.add('-message', "" + pokemon.name + " is waiting for a tailwind!");
		},
		onResidualOrder: 99,
		onResidualSubOrder: 6,
		onResidual: function (pokemon) {
			if (pokemon.volatiles['tailwindflag'] && !pokemon.volatiles['tailwindcheck'] && pokemon.side.sideConditions['tailwind']) {
				pokemon.switchFlag = true;
			}
		},
		id: "windstreamer",
		name: "Wind Streamer",
		rating: 3.5,
		num: 46,
	},
	"airforce": {
		desc: ".",
		shortDesc: "Implemented in Tailwind itself.",
		id: "airforce",
		name: "Air Force",
		rating: 2.5,
		num: 46,
	},
	"gorillatactics": {
		shortDesc: "Hits hard and Choicelocks.",
		onStart: function (pokemon) {
			if (pokemon.volatiles['generallock']) {
				this.debug('removing generallock: ' + pokemon.volatiles.generallock);
			}
			pokemon.removeVolatile('generallock');
		},
		onModifyMove: function (move, pokemon) {
			pokemon.addVolatile('generallock');
		},
		onModifyAtkPriority: 1,
		onModifyAtk: function (atk) {
			return this.chainModify(1.5);
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Gorilla Tactics boost');
				return this.chainModify(1.5);
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Ice' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		isDeciding: true,
		id: "gorillatactics",
		name: "Gorilla Tactics",
		rating: 4.5,
		num: 25,
	},
	"spacepower": {
		desc: ".",
		shortDesc: ".",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory || pokemon.template.species === 'Eternatus-Eternamax') {
				if (pokemon.getNature().plus === 'atk') {
					pokemon.addVolatile('eternatk');
				} else if (pokemon.getNature().plus === 'def') {
					pokemon.addVolatile('eterndef');
				} else if (pokemon.getNature().plus === 'spa') {
					pokemon.addVolatile('eternspa');
				} else if (pokemon.getNature().plus === 'spd') {
					pokemon.addVolatile('eternspd');
				} else if (pokemon.getNature().plus === 'spe') {
					pokemon.addVolatile('eternspestart');
				} else if (pokemon.getNature().plus !== 'atk' && pokemon.getNature().plus !== 'def' && pokemon.getNature().plus !== 'spa' && pokemon.getNature().plus !== 'spd' && pokemon.getNature().plus !== 'spe') {
					pokemon.addVolatile('stardust');
				} else {
					pokemon.addVolatile('stardust');
				}
			}
		},
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Space Power');
			this.add('-message', "" + pokemon.name + " is radiating an intense cosmic energy!");
		},
		onModifyMove: function (move) {
			if (move && (move.category === 'Physical' || move.category === 'Special')) {
				move.ignoreAbility = true;
			}
		},
		id: "spacepower",
		isBreaker: true,
		name: "Space Power",
		rating: 3.5,
		num: 46,
	},
	"antipathy": {
		desc: "While this Pokemon is burned, the power of its special attacks is multiplied by 1.5.",
		shortDesc: "While this Pokemon is burned, its special attacks have 1.5x power.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Antipathy');
			if (pokemon.baseTemplate.species === 'Mewtwo' || pokemon.template.species === 'Mewtwo-Mega-X' || pokemon.template.species === 'Mewtwo-Mega-Y') {
				this.add('-message', "" + pokemon.name + " is focused only on defeating its foes!");
			} else {
				this.add('-message', "" + pokemon.name + " is brimming with antipathy!");
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if ((defender.positiveBoosts()) || defender.item === 'powerbracer' || defender.hasAbility('unaware') || (move.category === 'Special' && defender.item === 'assaultvest') || (defender.item === 'choiceband' || defender.item === 'choicescarf' || defender.item === 'choicespecs')) {
				return this.chainModify(1.5);
			}
		},
		id: "antipathy",
		name: "Antipathy",
		rating: 3,
		num: 138,
	},
	"unseenfist": {
		shortDesc: ".",
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && move.type === 'Dragon' && !move.flags['exempt']) {
				return -1;
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			let unseen = defender.getItem();
			let fist = defender.getAbility();
			if (defender.positiveBoosts() && (!unseen.isChoice && !fist.isDeciding)) {
				return this.chainModify(1.5);
			} else if (unseen.isChoice || fist.isDeciding) {
				return this.chainModify(2);
			}
		},
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, pokemon) {
			if (pokemon.volatiles['activechange'] && pokemon.volatiles['allowunseenboost']) {
				return this.chainModify(1.3);
			}
		},
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				if (pokemon.item !== 'steelmemory' && pokemon.item !== 'darkmemory' && pokemon.item !== 'fairymemory' && pokemon.item !== 'fightingmemory') {
					this.add('-ability', pokemon, 'Unseen Fist');
					this.add('-message', "" + pokemon.name + " has unlocked its true potential!");
					pokemon.addVolatile('allowunseenboost');
				} else {
					this.add('-ability', pokemon, 'Unseen Fist');
					this.add('-message', "" + pokemon.name + " has already unlocked its potential!");
				}
			}
		},
		onModifyMove: function (move) {
			if (move.multihit && move.multihit.length) {
				move.multihit = move.multihit[1];
			}
			if (move.multiaccuracy) {
				delete move.multiaccuracy;
			}
		},
		id: "unseenfist",
		name: "Unseen Fist",
		rating: 3.5,
		num: 111,
	},
	"goonpatrol": {
		desc: ".",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.category === 'Physical' && pokemon.side.faintedLastTurn) {
				return this.chainModify(1.5);
			}
		},
		id: "goonpatrol",
		name: "Goon Patrol",
		rating: 3,
		num: 138,
	},
	"pacify": {
		desc: "On switch-in, this Pokemon lowers the Attack of adjacent opposing Pokemon by 1 stage. Pokemon behind a substitute are immune.",
		shortDesc: "On switch-in, this Pokemon lowers the Attack of adjacent opponents by 1 stage.",
		onStart: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			let activated = false;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || !this.isAdjacent(foeactive[i], pokemon)) continue;
				if (!activated) {
					this.add('-ability', pokemon, 'Pacify', 'boost');
					activated = true;
				}
				if (foeactive[i].volatiles['substitute'] || foeactive[i].volatiles['fortitude'] || foeactive[i].hasAbility(['psychicpower', 'mirrorarmor', 'formatdrive', 'moldbreaker', 'teravolt', 'turboblaze', 'dragonpower', 'spacepower', 'mirrorshadow', 'aurabreak'])) {
					this.add('-immune', foeactive[i], '[msg]');
				} else {
					this.boost({atk: -1}, foeactive[i], pokemon);
				}
			}
		},
		id: "pacify",
		name: "Pacify",
		rating: 3.5,
		num: 22,
	},
	"inveigle": {
		desc: "On switch-in, this Pokemon lowers the Special Attack of adjacent opposing Pokemon by 1 stage. Pokemon behind a substitute are immune.",
		shortDesc: "On switch-in, this Pokemon lowers the Special Attack of adjacent opponents by 1 stage.",
		onStart: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			let activated = false;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || !this.isAdjacent(foeactive[i], pokemon)) continue;
				if (!activated) {
					this.add('-ability', pokemon, 'Inveigle', 'boost');
					activated = true;
				}
				if (foeactive[i].volatiles['substitute'] || foeactive[i].volatiles['fortitude'] || foeactive[i].hasAbility(['psychicpower', 'mirrorarmor', 'formatdrive', 'moldbreaker', 'teravolt', 'turboblaze', 'dragonpower', 'spacepower', 'mirrorshadow', 'aurabreak'])) {
					this.add('-immune', foeactive[i], '[msg]');
				} else {
					this.boost({spa: -1}, foeactive[i], pokemon);
				}
			}
		},
		id: "inveigle",
		name: "Inveigle",
		rating: 3.5,
		num: 22,
	},
	"petrify": {
		desc: "On switch-in, this Pokemon lowers the Attack of adjacent opposing Pokemon by 1 stage. Pokemon behind a substitute are immune.",
		shortDesc: "On switch-in, this Pokemon lowers the Attack of adjacent opponents by 1 stage.",
		onStart: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			let activated = false;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || !this.isAdjacent(foeactive[i], pokemon)) continue;
				if (!activated) {
					this.add('-ability', pokemon, 'Inveigle', 'boost');
					activated = true;
				}
				if (foeactive[i].volatiles['substitute'] || foeactive[i].volatiles['fortitude'] || foeactive[i].hasAbility(['psychicpower', 'mirrorarmor', 'formatdrive', 'moldbreaker', 'teravolt', 'turboblaze', 'dragonpower', 'spacepower', 'mirrorshadow', 'aurabreak'])) {
					this.add('-immune', foeactive[i], '[msg]');
				} else {
					this.boost({def: -1}, foeactive[i], pokemon);
				}
			}
		},
		id: "petrify",
		name: "Petrify",
		rating: 3,
		num: 22,
	},
	"domineer": {
		desc: "On switch-in, this Pokemon lowers the Attack of adjacent opposing Pokemon by 1 stage. Pokemon behind a substitute are immune.",
		shortDesc: "On switch-in, this Pokemon lowers the Attack of adjacent opponents by 1 stage.",
		onStart: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			let activated = false;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || !this.isAdjacent(foeactive[i], pokemon)) continue;
				if (!activated) {
					this.add('-ability', pokemon, 'Inveigle', 'boost');
					activated = true;
				}
				if (foeactive[i].volatiles['substitute'] || foeactive[i].volatiles['fortitude'] || foeactive[i].hasAbility(['psychicpower', 'mirrorarmor', 'formatdrive', 'moldbreaker', 'teravolt', 'turboblaze', 'dragonpower', 'spacepower', 'mirrorshadow', 'aurabreak'])) {
					this.add('-immune', foeactive[i], '[msg]');
				} else {
					this.boost({spd: -1}, foeactive[i], pokemon);
				}
			}
		},
		id: "domineer",
		name: "Domineer",
		rating: 3,
		num: 22,
	},
	"architect": {
		shortDesc: "This Pokemon's hammer moves have their power multiplied by 1.5.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['hammer']) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "architect",
		name: "Architect",
		rating: 3,
		num: 181,
	},
	"primordialsea": {
		desc: "On switch-in, the weather becomes heavy rain that prevents damaging Fire-type moves from executing, in addition to all the effects of Rain Dance. This weather remains in effect until this Ability is no longer active for any Pokemon, or the weather is changed by Delta Stream or Desolate Land.",
		shortDesc: "On switch-in, heavy rain begins until this Ability is not active in battle.",
		onStart: function (source) {
			this.setWeather('primordialsea');
			if (source.template.species === 'Kyogre-Primal' && source.item === 'blueorb') {
				if (!source.setType('Water')) return;
				this.add('-start', source, 'typechange', 'Water', '[from] Primordial Sea');
				if (!source.addType('Ice')) return;
				this.add('-start', source, 'typeadd', 'Ice', '[from] Primordial Sea');
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.template.species !== 'Kyogre-Primal' || pokemon.item !== 'blueorb') return;
			if (move && (move.type === 'Water' || move.type === 'Ice')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (target.template.species !== 'Kyogre-Primal' || target.item !== 'blueorb') return;
			if (move && move.effectType === 'Move' && typeMod > 0 && type === 'Ice' && !move.flags['exempt']) {
				return 0;
			}
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (pokemon, target, move) {
			if (pokemon.template.species === 'Kyogre-Primal' && pokemon.item === 'blueorb') {
				pokemon.addVolatile('blueburst');
			}
		},
		onAnySetWeather: function (target, source, weather) {
			if (this.getWeather().id === 'primordialsea' && !(weather.id in {desolateland:1, primordialsea:1, deltastream:1})) return false;
		},
		onEnd: function (pokemon) {
			if (this.weatherData.source !== pokemon) return;
			for (let i = 0; i < this.sides.length; i++) {
				for (let j = 0; j < this.sides[i].active.length; j++) {
					let target = this.sides[i].active[j];
					if (target === pokemon) continue;
					if (target && target.hp && target.hasAbility('primordialsea')) {
						this.weatherData.source = target;
						return;
					}
				}
			}
			this.clearWeather();
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				this.add('-activate', pokemon, 'ability: Primordial Sea');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Primordial Sea');
			return false;
		},
		isUnbreakable: true,
		setRain: true,
		setPrimordial: true,
		id: "primordialsea",
		name: "Primordial Sea",
		rating: 5,
		num: 189,
	},
	"prismarmor": {
		shortDesc: "This Pokemon receives 3/4 damage from supereffective attacks.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod > 0) {
				this.debug('Prism Armor neutralize');
				return this.chainModify(0.75);
			}
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'recoil' && this.activeMove.id !== 'struggle') return null;
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.recoil && move.category !== 'Status') {
				this.heal(pokemon.lastDamage / 3, pokemon, pokemon, null, null);
			}
		},
		isUnbreakable: true,
		id: "prismarmor",
		name: "Prism Armor",
		rating: 3,
		num: 232,
	},
	"icescales": {
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if ((move.category === 'Special' || move.flags['hitsspd']) && !move.flags['hitsdef']) {
				this.debug('Ice Scales Neutralize');
				return this.chainModify(0.5);
			}
		},
		id: "icescales",
		name: "Ice Scales",
		rating: 3,
		num: 232,
	},
	"frostshield": {
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if ((move.category === 'Special' || move.flags['hitsspd']) && !move.flags['hitsdef']) {
				this.debug('Frost Shield Neutralize');
				return this.chainModify(0.67);
			}
		},
		onFoeBasePower: function (basePower, attacker, defender, move) {
			if (this.effectData.target !== defender) return;
			if ((move.category === 'Physical' || move.category === 'Special') && move.type === 'Fire') {
				return this.chainModify(0.5);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "frostshield",
		name: "Frost Shield",
		rating: 3,
		num: 232,
	},
	"flamingshield": {
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (((move.category === 'Physical' || move.flags['hitsdef']) && move.typeMod <= 0) && !move.flags['hitsspd']) {
				this.debug('Flaming Shield Neutralize');
				return this.chainModify(0.67);
			}
		},
		id: "flamingshield",
		isNonstandard: true,
		name: "Flaming Shield",
		rating: 3,
		num: 232,
	},
	"protean": {
		desc: "This Pokemon's type changes to match the type of the move it is about to use. This effect comes after all effects that change a move's type.",
		shortDesc: "This Pokemon's type changes to match the type of the move it is about to use.",
		onSwitchIn: function (pokemon) {
			if (pokemon.hasType('Electric')) pokemon.addVolatile('proteanelectric');
			if (pokemon.hasType('Fire')) pokemon.addVolatile('profire');
			if (pokemon.hasType('Ice')) pokemon.addVolatile('proteanice');
			if (pokemon.hasType('Poison')) pokemon.addVolatile('propoison');
		},
		onPrepareHit: function (source, target, move) {
			if (move.hasBounced) return;
			let type = move.type;
			if (type && source.getTypes().join() !== type) {
				if (!source.setType(type)) return;
				this.add('-start', source, 'typechange', type, '[from] Protean');
			}
		},
		id: "protean",
		name: "Protean",
		rating: 4,
		num: 168,
	},
	"psychicsurge": {
		shortDesc: "On switch-in, this Pokemon summons Psychic Terrain.",
		onStart: function (source) {
			this.setTerrain('psychicterrain');
		},
		id: "psychicsurge",
		isNonstandard: true,
		name: "Psychic Surge",
		rating: 4,
		num: 227,
	},
	"purepower": {
		shortDesc: "This Pokemon's Attack is doubled.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk) {
			return this.chainModify(2);
		},
		id: "purepower",
		name: "Pure Power",
		rating: 5,
		num: 74,
	},
	"queenlymajesty": {
		desc: "While this Pokemon is active, priority moves from opposing Pokemon targeted at allies are prevented from having an effect.",
		shortDesc: "While this Pokemon is active, allies are protected from opposing priority moves.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['kick']) {
				this.debug('Queenly Majesty boost');
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "queenlymajesty",
		name: "Queenly Majesty",
		rating: 3.5,
		num: 214,
	},
	"quickfeet": {
		desc: "If this Pokemon has a major status condition, its Speed is multiplied by 1.5; the Speed drop from paralysis is ignored.",
		shortDesc: "If this Pokemon is statused, its Speed is 1.5x; ignores Speed drop from paralysis.",
		onModifySpe: function (spe, pokemon) {
			if (pokemon.status) {
				return this.chainModify(1.5);
			}
		},
		id: "quickfeet",
		name: "Quick Feet",
		rating: 2.5,
		num: 95,
	},
	"raindish": {
		desc: "If Rain Dance is active, this Pokemon restores 1/10 of its maximum HP, rounded down, at the end of each turn.",
		shortDesc: "If Rain Dance is active, this Pokemon heals 1/10 of its max HP each turn.",
		onWeather: function (target, source, effect) {
			if (effect.id === 'raindance' || effect.id === 'primordialsea') {
				this.heal(target.maxhp / 5);
			}
		},
		id: "raindish",
		name: "Rain Dish",
		rating: 3,
		num: 44,
	},
	"rattled": {
		desc: "This Pokemon's Speed is raised by 1 stage if hit by a Bug-, Dark-, or Ghost-type attack.",
		shortDesc: "This Pokemon's Speed is raised 1 stage if hit by a Bug-, Dark-, or Ghost-type attack.",
		onAfterDamage: function (damage, target, source, effect) {
			if (effect && (effect.type === 'Dark' || effect.type === 'Bug' || effect.type === 'Ghost')) {
				this.boost({spe:1});
			}
		},
		id: "rattled",
		name: "Rattled",
		rating: 1.5,
		num: 155,
	},
	"machspeed": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Mach Speed');
			this.add('-message', "" + pokemon.name + " is raring to go!");
		},
		onModifySpePriority: 5,
		onModifySpe: function (spe, pokemon) {
			if (pokemon.hp >= pokemon.maxhp) {
				return this.chainModify(2);
			}
		},
		onFlinch: false,
		id: "machspeed",
		name: "Mach Speed",
		rating: 4,
		num: 233,
	},
	"hyperspeed": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Hyper Speed');
			this.add('-message', "" + pokemon.name + " is raring to go!");
		},
		onUpdate: function (pokemon) {
			if (!pokemon.volatiles['noheal']) pokemon.addVolatile('noheal');
		},
		onModifySpePriority: 5,
		onModifySpe: function (spe, pokemon) {
			if (pokemon.hp >= pokemon.maxhp / 2) {
				return this.chainModify(2);
			}
		},
		onAfterMoveSecondarySelf: function (source, target, move) {
			if (source && source !== target && move && move.category !== 'Status' && !move.ohko) {
				this.damage(source.maxhp / 8, source, source);
			}
		},
		id: "hyperspeed",
		name: "Hyper Speed",
		rating: 4,
		num: 233,
	},
	"exterminator": {
		desc: ".",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if ((move && move.type === 'Bug') && ((move.category === 'Physical') || move.category === 'Special')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Exterminator boost');
				return this.chainModify(1.3);
			}
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Bug'] = true;
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "exterminator",
		name: "Exterminator",
		rating: 4,
		num: 233,
	},
	"equilibrium": {
		desc: ".",
		shortDesc: ".",
		onAnyModifyBoost: function (boosts, target) {
			let source = this.effectData.target;
			if (source === target) return;
			if (source === this.activePokemon && target === this.activeTarget) {
				boosts['def'] = 0;
				boosts['spd'] = 0;
				boosts['evasion'] = 0;
			}
			if (target === this.activePokemon && source === this.activeTarget) {
				boosts['atk'] = 0;
				boosts['spa'] = 0;
				boosts['def'] = 0;
				boosts['spd'] = 0;
				boosts['accuracy'] = 0;
			}
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Normal'] = true;
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (source.volatiles['choicelock'] || source.volatiles['generallock']) {
				this.debug('Noble Guard Neutralize');
				return this.chainModify(0.5);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "equilibrium",
		name: "Equilibrium",
		rating: 3.5,
		num: 91,
	},
	"noability": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'No Ability');
			this.add('-message', "" + pokemon.name + " has no ability!");
		},
		id: "noability",
		name: "No Ability",
		rating: 0,
		num: 233,
	},
	"speedpledge": {
		desc: ".",
		shortDesc: ".",
		onModifySpePriority: 5,
		onModifySpe: function (spe, pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4) {
				return this.chainModify(2);
			}
		},
		id: "speedpledge",
		name: "Speed Pledge",
		rating: 3,
		num: 233,
	},
	"plantpower": {
		desc: ".",
		shortDesc: ".",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				return this.chainModify(1.5);
			}
		},
		onModifyDefPriority: 5,
		onModifyDef: function (def, pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				return this.chainModify(1.5);
			}
		},
		onModifySpDPriority: 5,
		onModifySpD: function (spd, pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				return this.chainModify(1.5);
			}
		},
		onModifySpePriority: 5,
		onModifySpe: function (spe, pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				return this.chainModify(1.5);
			}
		},
		id: "plantpower",
		name: "Plant Power",
		rating: 3,
		num: 233,
	},
	"focused": {
		desc: "Increases the user's evasion stat.",
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Dark') {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		id: "focused",
		name: "Focused",
		rating: 4,
		num: 238,
	},
	"memoryarmor": {
		desc: ".",
		shortDesc: ".",
		onModifyDefPriority: 5,
		onModifyDef: function (def, pokemon) {
			if (pokemon.volatiles['activechange']) {
				return this.chainModify(1.5);
			}
		},
		onModifySpDPriority: 5,
		onModifySpD: function (spd, pokemon) {
			if (pokemon.volatiles['activechange']) {
				return this.chainModify(1.5);
			}
		},
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Memory Armor');
				this.add('-message', "" + pokemon.name + " has become fortified!");
			}
		},
		isUnbreakable: true,
		id: "memoryarmor",
		name: "Memory Armor",
		rating: 4,
		num: 236,
	},
	"rocksteady": {
		desc: "While this Pokemon has 1/2 or less of its maximum HP, its offensive stats increase.",
		shortDesc: "While this Pokemon has 1/2 or less of its maximum HP, its offensive stats increase.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				return this.chainModify(2);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.volatiles['mustrecharge']) {
				this.add('-activate', pokemon, 'ability: Rock Steady');
				pokemon.removeVolatile('mustrecharge');
			}
		},
		onTryAddVolatile: function (status, pokemon) {
			if (status.id === 'mustrecharge') return null;
		},
		id: "rocksteady",
		name: "Rock Steady",
		rating: 3,
		num: 235,
	},
	"ironwill": {
		desc: "While this Pokemon has 1/2 or less of its maximum HP, it damages foes and sharpens it's defense.",
		shortDesc: "While this Pokemon has 1/2 or less of its maximum HP, it damages foes and sharpens it's defense",
		onModifyDefPriority: 5,
		onModifyDef: function (def, pokemon) {
			if (pokemon.hp >= pokemon.maxhp / 2) {
				return this.chainModify(2);
			}
		},
		onModifySpDPriority: 5,
		onModifySpD: function (spd, pokemon) {
			if (pokemon.hp >= pokemon.maxhp / 2) {
				return this.chainModify(2);
			}
		},
		id: "ironwill",
		name: "Iron Will",
		rating: 5,
		num: 236,
	},
	"fullbloom": {
		desc: "While this Pokemon has 1/2 or less of its maximum HP, its offensive stats increase.",
		shortDesc: "While this Pokemon has 1/2 or less of its maximum HP, its offensive stats increase.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.category === 'Special' && !move.isZ && move.id !== 'strangewave' && !move.flags['nocategoryswap']) {
				move.category = 'Physical';
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && !move.flags['exempt'] && typeMod > 0) {
				this.add('-message', "" + target.name + "'s Full Bloom is protecting it from opposing Super-Effective Moves!");
				return 0;
			}
		},
		id: "fullbloom",
		name: "Full Bloom",
		rating: 3,
		num: 237,
	},
	"receiver": {
		desc: "This Pokemon copies the Ability of an ally that faints. Abilities that cannot be copied are Flower Gift, Forecast, Illusion, Imposter, Multitype, Stance Change, Trace, Wonder Guard, and Zen Mode.",
		shortDesc: "This Pokemon copies the Ability of an ally that faints.",
		onAllyFaint: function (target) {
			if (!this.effectData.target.hp) return;
			let ability = this.getAbility(target.ability);
			let bannedAbilities = {comatose:1, flowergift:1, forecast:1, illusion:1, imposter:1, multitype:1, stancechange:1, trace:1, wonderguard:1, zenmode:1};
			if (bannedAbilities[target.ability]) return;
			this.add('-ability', this.effectData.target, ability, '[from] ability: Receiver', '[of] ' + target);
			this.effectData.target.setAbility(ability);
		},
		id: "receiver",
		name: "Receiver",
		rating: 0,
		num: 222,
	},
	"reckless": {
		desc: "This Pokemon's attacks with recoil or crash damage have their power multiplied by 1.2. Does not affect Struggle.",
		shortDesc: "This Pokemon's attacks with recoil or crash damage have 1.2x power; not Struggle.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.category === 'Special' && !move.isZ && move.id !== 'strangewave' && !move.flags['nocategoryswap']) {
				move.category = 'Physical';
				if (move.category !== 'Status') pokemon.addVolatile('reckless');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x1333, 0x1000]);
			},
		},
		id: "reckless",
		name: "Reckless",
		rating: 3,
		num: 120,
	},
	"refrigerate": {
		desc: "This Pokemon's Normal-type moves become Ice-type moves and have their power multiplied by 1.2. This effect comes after other effects that change a move's type, but before Ion Deluge and Electrify's effects.",
		shortDesc: "This Pokemon's Normal-type moves become Ice type and have 1.2x power.",
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (move.type === 'Normal' && move.id !== 'naturalgift' && !move.isZ) {
				move.type = 'Ice';
				if (move.category !== 'Status') pokemon.addVolatile('refrigerate');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0x1333, 0x1000]);
			},
		},
		id: "refrigerate",
		isSuffix: true,
		name: "Refrigerate",
		rating: 4,
		num: 174,
	},
	"regenerator": {
		shortDesc: "This Pokemon restores 1/2 of its maximum HP, rounded down, when it switches out.",
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 3);
		},
		id: "regenerator",
		name: "Regenerator",
		switchHealing: true,
		rating: 4,
		num: 144,
	},
	"superregenerator": {
		shortDesc: "This Pokemon restores 1/2 of its maximum HP, rounded down, when it switches out.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Super Regenerator');
			this.add('-message', "" + pokemon.name + " is brimming with eternal life!");
		},
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 2);
			if (!pokemon.side.sideConditions['regeneration']) {
				this.add('-ability', pokemon, 'Super Regenerator');
				this.add('-message', "" + pokemon.name + "'s Life Energy is radiating from all directions!");
				pokemon.side.addSideCondition('regeneration', pokemon, pokemon, null, null);
			}
		},
		isMemorized: true,
		id: "superregenerator",
		name: "Super Regenerator",
		switchHealing: true,
		rating: 5,
		num: 144,
	},
	"happydance": {
		shortDesc: "Every move used by or against this Pokemon will always hit.",
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move && (source === this.effectData.target || target === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		id: "happydance",
		name: "Happy Dance",
		rating: 4,
		num: 99,
	},
	"rivalry": {
		desc: "This Pokemon's attacks have their power multiplied by 1.25 against targets of the same gender or multiplied by 0.75 against targets of the opposite gender. There is no modifier if either this Pokemon or the target is genderless.",
		shortDesc: "This Pokemon's attacks do 1.25x on same gender targets; 0.75x on opposite gender.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Rivalry');
			this.add('-message', "" + pokemon.name + " is resigned to battle!");
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			if (pokemon.status) {
				return this.chainModify(1.5);
			}
		},
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'brn' || effect.id === 'par' || effect.id === 'psn' || effect.id === 'tox') {
				return false;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.add('-ability', pokemon, 'Rivalry');
			this.add('-message', "" + pokemon.name + " has no intention to surrender!");
		},
		id: "rivalry",
		name: "Rivalry",
		rating: 3,
		num: 79,
	},
	"rkssystem": {
		shortDesc: "If this Pokemon is a Silvally, its type changes to match its held Memory.",
		// RKS System's type-changing itself is implemented in statuses.js
		id: "rkssystem",
		name: "RKS System",
		rating: 4,
		num: 225,
	},
	"rockhead": {
		desc: "This Pokemon does not take recoil damage besides Struggle, Life Orb, and crash damage.",
		shortDesc: "This Pokemon does not take recoil damage besides Struggle/Life Orb/crash damage.",
		onDamage: function (damage, target, source, effect) {
			if (effect.id === 'recoil' && this.activeMove.id !== 'struggle') return null;
		},
		id: "rockhead",
		name: "Rock Head",
		rating: 3,
		num: 69,
	},
	"roughskin": {
		desc: "Pokemon making contact with this Pokemon lose 1/8 of their maximum HP, rounded down.",
		shortDesc: "Pokemon making contact with this Pokemon lose 1/8 of their max HP.",
		onAfterDamageOrder: 1,
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.flags['contact']) {
				this.damage(source.maxhp / 8, source, target);
			}
		},
		id: "roughskin",
		name: "Rough Skin",
		rating: 3,
		num: 24,
	},
	"runaway": {
		shortDesc: "No competitive use.",
		onTrapPokemonPriority: -10,
		onTrapPokemon: function (pokemon, target) {
			if (!pokemon.volatiles['setuptrapped']) {
				pokemon.trapped = pokemon.maybeTrapped = false;
			}
		},
		id: "runaway",
		name: "Run Away",
		rating: 3,
		num: 50,
	},
	"sandforce": {
		desc: "If Sandstorm is active, this Pokemon's Ground-, Rock-, and Steel-type attacks have their power multiplied by 1.3. This Pokemon takes no damage from Sandstorm.",
		shortDesc: "This Pokemon's Ground/Rock/Steel attacks do 1.3x in Sandstorm; immunity to it.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (this.isWeather('sandstorm')) {
				if (move.type === 'Rock' || move.type === 'Ground' || move.type === 'Steel') {
					this.debug('Sand Force boost');
					return this.chainModify([0x14CD, 0x1000]);
				}
			}
		},
		onImmunity: function (type, pokemon) {
			if (type === 'sandstorm') return false;
		},
		id: "sandforce",
		name: "Sand Force",
		rating: 2,
		num: 159,
	},
	"sandrush": {
		desc: "If Sandstorm is active, this Pokemon's Speed is doubled. This Pokemon takes no damage from Sandstorm.",
		shortDesc: "If Sandstorm is active, this Pokemon's Speed is doubled; immunity to Sandstorm.",
		onModifySpe: function (spe, pokemon) {
			if (this.isWeather('sandstorm')) {
				return this.chainModify(2);
			}
		},
		onImmunity: function (type, pokemon) {
			if (type === 'sandstorm') return false;
		},
		id: "sandrush",
		name: "Sand Rush",
		rating: 2.5,
		num: 146,
	},
	"sandstream": {
		shortDesc: "On switch-in, this Pokemon summons Sandstorm.",
		onStart: function (source) {
			if (source.item === 'roomservice') {
				this.add('-message', "" + source.name + "'s Room Service is evaporating the surrounding Sand with vibrant beams of Light!");
				this.setWeather('sunnyday');
			} else {
				this.setWeather('sandstorm');
			}
		},
		setSand: true,
		id: "sandstream",
		name: "Sand Stream",
		rating: 4.5,
		num: 45,
	},
	"sandveil": {
		desc: "If Sandstorm is active, this Pokemon's evasiveness is multiplied by 1.25. This Pokemon takes no damage from Sandstorm.",
		shortDesc: "If Sandstorm is active, this Pokemon's evasiveness is 1.25x; immunity to Sandstorm.",
		onImmunity: function (type, pokemon) {
			if (type === 'sandstorm') return false;
		},
		onModifyAccuracy: function (accuracy) {
			if (typeof accuracy !== 'number') return;
			if (this.isWeather('sandstorm')) {
				this.debug('Sand Veil - decreasing accuracy');
				return accuracy * 0.8;
			}
		},
		id: "sandveil",
		name: "Sand Veil",
		rating: 1.5,
		num: 8,
	},
	"sapsipper": {
		desc: "This Pokemon is immune to Grass-type moves and raises its Attack by 1 stage when hit by a Grass-type move.",
		shortDesc: "This Pokemon's Attack is raised 1 stage if hit by a Grass move; Grass immunity.",
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Grass') {
				if (!this.boost({atk:1})) {
					this.add('-immune', target, '[msg]', '[from] ability: Sap Sipper');
				}
				return null;
			}
		},
		onAllyTryHitSide: function (target, source, move) {
			if (target === this.effectData.target || target.side !== source.side) return;
			if (move.type === 'Grass') {
				this.boost({atk:1}, this.effectData.target);
			}
		},
		id: "sapsipper",
		name: "Sap Sipper",
		rating: 3.5,
		num: 157,
	},
	"schooling": {
		desc: "On switch-in, if this Pokemon is a Wishiwashi that is level 20 or above and has more than 1/4 of its maximum HP left, it changes to School Form. If it is in School Form and its HP drops to 1/4 of its maximum HP or less, it changes to Solo Form at the end of the turn. If it is in Solo Form and its HP is greater than 1/4 its maximum HP at the end of the turn, it changes to School Form.",
		shortDesc: "If user is Wishiwashi, changes to School Form if it has > 1/4 max HP, else Solo Form.",
		onStart: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Wishiwashi' || pokemon.level < 20 || pokemon.transformed) return;
			if (pokemon.hp > pokemon.maxhp / 4) {
				if (pokemon.template.speciesid === 'wishiwashi') {
					pokemon.formeChange('Wishiwashi-School');
					this.add('-formechange', pokemon, 'Wishiwashi-School', '[from] ability: Schooling');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid === 'wishiwashischool') {
					pokemon.formeChange('Wishiwashi');
					this.add('-formechange', pokemon, 'Wishiwashi', '[from] ability: Schooling');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		onResidualOrder: 27,
		onResidual: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Wishiwashi' || pokemon.level < 20 || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.hp > pokemon.maxhp / 4) {
				if (pokemon.template.speciesid === 'wishiwashi') {
					pokemon.formeChange('Wishiwashi-School');
					this.add('-formechange', pokemon, 'Wishiwashi-School', '[from] ability: Schooling');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid === 'wishiwashischool') {
					pokemon.formeChange('Wishiwashi');
					this.add('-formechange', pokemon, 'Wishiwashi', '[from] ability: Schooling');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		id: "schooling",
		name: "Schooling",
		rating: 2.5,
		num: 208,
	},
	"scrappy": {
		shortDesc: "This Pokemon can hit Ghost types with Normal- and Fighting-type moves.",
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Fighting'] = true;
				move.ignoreImmunity['Normal'] = true;
			}
		},
		id: "scrappy",
		name: "Scrappy",
		rating: 3,
		num: 113,
	},
	"spookypower": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && (move.type === 'Dragon' || move.type === 'Ghost')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		id: "spookypower",
		name: "Spooky Power",
		rating: 4,
		num: 253,
	},
	"transistor": {
		desc: ".",
		shortDesc: ".",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (move && move.type === 'Electric') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onModifySpePriority: 5,
		onModifySpe: function (spe, pokemon) {
			if (pokemon.volatiles['activechange']) {
				return this.chainModify(1.5);
			}
		},
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Transistor');
				this.add('-message', "" + pokemon.name + " has become energized!");
			}
		},
		id: "transistor",
		name: "Transistor",
		rating: 4,
		num: 253,
	},
	"dragonsmaw": {
		desc: ".",
		shortDesc: ".",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, attacker, defender, move) {
			if (move.type === 'Dragon') {
				this.debug('Dragon Maw boost');
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (spa, attacker, defender, move) {
			if (move.type === 'Dragon') {
				this.debug('Dragon Maw boost');
				return this.chainModify(1.5);
			}
		},
		onModifyMove: function (move) {
			delete move.flags['spout'];
		},
		id: "dragonsmaw",
		name: "Dragon's Maw",
		rating: 4,
		num: 253,
	},
	"combative": {
		shortDesc: "This Pokemon can hit Ground types with Electric-type moves.",
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Electric'] = true;
			}
		},
		id: "combative",
		isNonstandard: true,
		name: "Combative",
		rating: 3,
		num: 113,
	},
	"lightningtunnel": {
		shortDesc: "This Pokemon can hit Ground types with Electric-type moves.",
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Electric'] = true;
			}
		},
		id: "lightningtunnel",
		name: "Lightning Tunnel",
		rating: 3,
		num: 113,
	},
	"endlessearth": {
		shortDesc: "This Pokemon can hit Ground types with Electric-type moves.",
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Ground'] = true;
			}
		},
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Electric') {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Endless Earth');
				}
				return null;
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['endlesstypemod']) target.removeVolatile('endlesstypemod');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['endlesstypemod']) defender.addVolatile('endlesstypemod');
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "endlessearth",
		name: "Endless Earth",
		rating: 3,
		num: 113,
	},
	"diamondarmor": {
		desc: "While this Pokemon has 1/2 or less of its maximum HP, its offensive stats increase.",
		shortDesc: "While this Pokemon has 1/2 or less of its maximum HP, its offensive stats increase.",
		onEffectiveness: function (typeMod, target, type, move) {
			if (move && move.effectType === 'Move' && type === 'Rock' && (move.type === 'Ground') && !move.flags['exempt']) {
				return 0;
			}
		},
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (target === source || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, target, source);
			return null;
		},
		onAllyTryHitSide: function (target, source, move) {
			if (target.side === source.side || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, this.effectData.target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "diamondarmor",
		name: "Diamond Armor",
		rating: 3,
		num: 235,
	},
	"infinitevoltage": {
		shortDesc: "This Pokemon can hit Ground types with Electric-type moves.",
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.ignoreImmunity !== true) {
				move.ignoreImmunity['Electric'] = true;
			}
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target !== source) return;
			let showMsg = false;
			for (let i in boost) {
				if (effect.type === 'Electric' && (!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Infinite Voltage", "[of] " + target);
		},
		onModifyDamage: function (damage, source, target, move) {
			if (target.hasType('Ground')) {
				this.debug('Infinite Voltage boost');
				return this.chainModify(1.5);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "infinitevoltage",
		name: "Infinite Voltage",
		rating: 3,
		num: 113,
	},
	"perfectform": {
		desc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		shortDesc: "Increases the pokemon's Defense and Special Attack by 1.25x",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.category === 'Physical' && (basePower <= 120 || move.flags['scalar'] || move.flags['mewstrike']) && (move.priority < 1 && !move.flags['critical'] && !move.flags['super'])) {
				this.debug('Form boost');
				return this.chainModify(1.5);
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.category === 'Physical' && move && move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "perfectform",
		name: "Perfect Form",
		rating: 3,
		num: 186,
	},
	"serenegrace": {
		shortDesc: "This Pokemon's moves have their secondary effect chance doubled.",
		onModifyMovePriority: -2,
		onModifyMove: function (move) {
			if (move.secondaries) {
				this.debug('doubling secondary chance');
				for (let i = 0; i < move.secondaries.length; i++) {
					move.secondaries[i].chance *= 2;
				}
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category === 'Status' && (!move.flags['heal'] && !move.flags['healswitch'])) {
				this.heal(pokemon.maxhp / 5, pokemon, pokemon, null, null);
			} else if (move.category === 'Status' && (move.flags['heal'] || move.flags['healswitch'])) {
				this.heal(pokemon.maxhp / 10, pokemon, pokemon, null, null);
			}
		},
		id: "serenegrace",
		name: "Serene Grace",
		rating: 4,
		num: 32,
	},
	"shadowshield": {
		shortDesc: "If this Pokemon is at full HP, damage taken from attacks is halved.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (target.hp >= target.maxhp && !move.flags['descale']) {
				this.debug('Shadow Shield weaken');
				return this.chainModify(0.5);
			}
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target !== source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Shadow Shield", "[of] " + target);
		},
		isUnbreakable: true,
		id: "shadowshield",
		name: "Shadow Shield",
		rating: 4,
		num: 231,
	},
	"shadowtag": {
		desc: "Prevents adjacent opposing Pokemon from choosing to switch out unless they are immune to trapping or also have this Ability.",
		shortDesc: "Prevents adjacent foes from choosing to switch unless they also have this Ability.",
		onFoeTrapPokemon: function (pokemon) {
			let condition = pokemon.getAbility();
			if (condition.isBreaker) return;
			if (!pokemon.hasAbility('shadowtag') && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, this.effectData.target)) {
				pokemon.tryTrap(true);
			}
		},
		onFoeMaybeTrapPokemon: function (pokemon, source) {
			if (!source) source = this.effectData.target;
			if (!pokemon.hasAbility('shadowtag') && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, source)) {
				pokemon.maybeTrapped = true;
			}
		},
		id: "shadowtag",
		name: "Shadow Tag",
		rating: 5,
		num: 23,
	},
	"watertrap": {
		desc: "Prevents adjacent opposing Water-type Pokemon from choosing to switch out unless they are immune to trapping.",
		shortDesc: "Prevents adjacent Water-type foes from choosing to switch.",
		onFoeTrapPokemon: function (pokemon) {
			let condition = pokemon.getAbility();
			if (condition.isBreaker) return;
			if (pokemon.hasType('Water') && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, this.effectData.target)) {
				pokemon.tryTrap(true);
			}
		},
		onFoeMaybeTrapPokemon: function (pokemon, source) {
			if (!source) source = this.effectData.target;
			if ((!pokemon.knownType || pokemon.hasType('Water')) && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, source)) {
				pokemon.maybeTrapped = true;
			}
		},
		id: "watertrap",
		name: "Water Trap",
		rating: 4.5,
		num: 42,
	},
	"lifeforce": {
		desc: "Prevents adjacent opposing Water-type Pokemon from choosing to switch out unless they are immune to trapping.",
		shortDesc: "Prevents adjacent Water-type foes from choosing to switch.",
		onFoeTrapPokemon: function (pokemon) {
			let condition = pokemon.getAbility();
			if (condition.isBreaker) return;
			if (pokemon.hasType('Water') && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && !pokemon.hasAbility('eternalstream') && !pokemon.volatiles['waterdisc'] && this.isAdjacent(pokemon, this.effectData.target)) {
				pokemon.tryTrap(true);
			}
		},
		onFoeMaybeTrapPokemon: function (pokemon, source) {
			if (!source) source = this.effectData.target;
			if ((!pokemon.knownType || pokemon.hasType('Water')) && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && !pokemon.hasAbility('eternalstream') && !pokemon.volatiles['waterdisc'] && this.isAdjacent(pokemon, source)) {
				pokemon.maybeTrapped = true;
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === "Water") {
				this.debug('Life Force neutralize');
				return this.chainModify(0.67);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status) {
				this.add('-activate', pokemon, 'ability: Life Force');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Life Force');
			return false;
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (!pokemon.hp) return;
			for (let i = 0; i < pokemon.side.foe.active.length; i++) {
				let target = pokemon.side.foe.active[i];
				if (!target || !target.hp) continue;
				if (target.hasType('Water')) {
					this.damage(target.maxhp / 8, target, pokemon);
					this.heal(pokemon.maxhp / 8, pokemon);
				}
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "lifeforce",
		name: "Life Force",
		rating: 4.5,
		num: 42,
	},
	"candletrap": {
		desc: "Prevents adjacent opposing Ground-Type Pokemon from choosing to switch out unless they are immune to trapping.",
		shortDesc: "Prevents adjacent Ground-Type foes from choosing to switch.",
		onFoeTrapPokemon: function (pokemon) {
			let condition = pokemon.getAbility();
			if (condition.isBreaker) return;
			if ((pokemon.hasType('Ground') || pokemon.hasType('Fire')) && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, this.effectData.target)) {
				pokemon.tryTrap(true);
			}
		},
		onFoeMaybeTrapPokemon: function (pokemon, source) {
			if (!source) source = this.effectData.target;
			if ((!pokemon.knownType || (pokemon.hasType('Ground') || pokemon.hasType('Fire'))) && (!pokemon.hasType('Ghost') && !pokemon.hasType('Flying')) && this.isAdjacent(pokemon, source)) {
				pokemon.maybeTrapped = true;
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (!pokemon.hp) return;
			for (let i = 0; i < pokemon.side.foe.active.length; i++) {
				let target = pokemon.side.foe.active[i];
				if (!target || !target.hp) continue;
				if (target.hasType('Ground') || target.hasType('Fire')) {
					this.damage(target.maxhp / 4, target, pokemon);
					this.heal(pokemon.maxhp / 6, pokemon);
				}
			}
		},
		id: "candletrap",
		name: "Candle Trap",
		rating: 4.5,
		num: 42,
	},
	"shedskin": {
		desc: "This Pokemon has a 33% chance to have its major status condition cured at the end of each turn.",
		shortDesc: "This Pokemon has a 33% chance to have its status cured at the end of each turn.",
		onResidualOrder: 5,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.hp && pokemon.status && this.random(3) === 0) {
				this.debug('shed skin');
				this.add('-activate', pokemon, 'ability: Shed Skin');
				pokemon.cureStatus();
			}
		},
		id: "shedskin",
		name: "Shed Skin",
		rating: 3.5,
		num: 61,
	},
	"sheerforce": {
		desc: "This Pokemon's attacks with secondary effects have their power multiplied by 1.3, but the secondary effects are removed.",
		shortDesc: "This Pokemon's attacks with secondary effects have 1.3x power; nullifies the effects.",
		onModifyMove: function (move, pokemon) {
			if (move.secondaries) {
				delete move.secondaries;
				// Actual negation of `AfterMoveSecondary` effects implemented in scripts.js
				pokemon.addVolatile('sheerforce');
			}
		},
		id: "sheerforce",
		name: "Sheer Force",
		rating: 4,
		num: 125,
	},
	"supersheerforce": {
		desc: "This Pokemon's attacks with secondary effects have their power multiplied by 1.3, but the secondary effects are removed.",
		shortDesc: "This Pokemon's attacks with secondary effects have 1.3x power; nullifies the effects.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Super Sheer Force');
			this.add('-message', "" + pokemon.name + " is bursting with power!");
		},
		onModifyMove: function (move, pokemon) {
			if (move && (move.category === 'Physical' || move.category === 'Special')) {
				delete move.secondaries;
				pokemon.addVolatile('supersheerforce');
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		isMemorized: true,
		id: "supersheerforce",
		name: "Super Sheer Force",
		rating: 4,
		num: 125,
	},
	"shellarmor": {
		shortDesc: "This Pokemon cannot be struck by a critical hit.",
		onCriticalHit: false,
		id: "shellarmor",
		name: "Shell Armor",
		rating: 1,
		num: 75,
	},
	"shielddust": {
		shortDesc: "This Pokemon is not affected by the secondary effect of another Pokemon's attack.",
		onModifySecondaries: function (secondaries) {
			this.debug('Shield Dust prevent secondary');
			return secondaries.filter(effect => !!effect.self);
		},
		id: "shielddust",
		name: "Shield Dust",
		rating: 2.5,
		num: 19,
	},
	"shieldsdown": {
		desc: "If this Pokemon is a Minior, it changes to its Core forme if it has 1/2 or less of its maximum HP, and changes to Meteor Form if it has more than 1/2 its maximum HP. This check is done on switch-in and at the end of each turn. While in its Meteor Form, it cannot become affected by major status conditions.",
		shortDesc: "If Minior, switch-in/end of turn it changes to Core at 1/2 max HP or less, else Meteor.",
		onUpdate: function (pokemon) {
			if (!pokemon.isActive || pokemon.baseTemplate.baseSpecies !== 'Minior' || pokemon.transformed) return;
			if (pokemon.positiveBoosts()) {
				if (pokemon.template.speciesid !== 'minior') {
					pokemon.formeChange('Minior');
					this.add('-formechange', pokemon, 'Minior', '[msg]', '[from] ability: Shields Down');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid === 'miniormeteor') {
					pokemon.formeChange('Minior-Meteor');
					this.add('-formechange', pokemon, 'Minior-Meteor', '[msg]', '[from] ability: Shields Down');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (target.template.speciesid !== 'miniormeteor' || target.transformed) return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Shields Down');
			return false;
		},
		id: "shieldsdown",
		name: "Shields Down",
		rating: 2.5,
		num: 197,
	},
	"oldsdown": {
		desc: "If this Pokemon is a Minior, it changes to its Core forme if it has 1/2 or less of its maximum HP, and changes to Meteor Form if it has more than 1/2 its maximum HP. This check is done on switch-in and at the end of each turn. While in its Meteor Form, it cannot become affected by major status conditions.",
		shortDesc: "If Minior, switch-in/end of turn it changes to Core at 1/2 max HP or less, else Meteor.",
		onStart: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Minior' || pokemon.transformed) return;
			if (pokemon.hp > pokemon.maxhp / 2) {
				if (pokemon.template.speciesid === 'minior') {
					pokemon.formeChange('Minior-Meteor');
					this.add('-formechange', pokemon, 'Minior-Meteor', '[msg]', '[from] ability: Shields Down');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid !== 'minior') {
					pokemon.formeChange(pokemon.set.species);
					this.add('-formechange', pokemon, pokemon.set.species, '[msg]', '[from] ability: Shields Down');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		onResidualOrder: 27,
		onResidual: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Minior' || pokemon.transformed || !pokemon.hp) return;
			if (pokemon.hp > pokemon.maxhp / 2) {
				if (pokemon.template.speciesid === 'minior') {
					pokemon.formeChange('Minior-Meteor');
					this.add('-formechange', pokemon, 'Minior-Meteor', '[msg]', '[from] ability: Shields Down');
					pokemon.addVolatile('formecheck');
				}
			} else {
				if (pokemon.template.speciesid !== 'minior') {
					pokemon.formeChange(pokemon.set.species);
					this.add('-formechange', pokemon, pokemon.set.species, '[msg]', '[from] ability: Shields Down');
					pokemon.addVolatile('formecheck');
				}
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (target.template.speciesid !== 'miniormeteor' || target.transformed) return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Shields Down');
			return false;
		},
		id: "oldsdown",
		isNonstandard: true,
		name: "Old Shields Down",
		rating: 2.5,
		num: 197,
	},
	"simple": {
		shortDesc: "If this Pokemon's stat stages are raised or lowered, the effect is doubled instead.",
		onBoost: function (boost) {
			for (let i in boost) {
				boost[i] *= 2;
			}
		},
		id: "simple",
		name: "Simple",
		rating: 4,
		num: 86,
	},
	"skilllink": {
		shortDesc: "This Pokemon's multi-hit attacks always hit the maximum number of times.",
		onModifyMove: function (move) {
			if (move.multihit && move.multihit.length) {
				move.multihit = move.multihit[1];
			}
			if (move.multiaccuracy) {
				delete move.multiaccuracy;
			}
		},
		id: "skilllink",
		name: "Skill Link",
		rating: 4,
		num: 92,
	},
	"slowstart": {
		shortDesc: "On switch-in, this Pokemon's Attack and Speed are halved for 1 turn.",
		onModifyPriority: function (priority) {
			return Math.round(priority) - 0.1;
		},
		id: "slowstart",
		name: "Slow Start",
		rating: 3,
		num: 112,
	},
	"slushrush": {
		desc: "If Hail is active, this Pokemon's Speed is doubled. This Pokemon takes no damage from Hail.",
		shortDesc: "If Hail is active, this Pokemon's Speed is doubled; immunity to Hail.",
		onModifySpe: function (spe, pokemon) {
			if (this.isWeather('hail')) {
				return this.chainModify(2);
			}
		},
		onImmunity: function (type, pokemon) {
			if (type === 'hail') return false;
		},
		id: "slushrush",
		name: "Slush Rush",
		rating: 2.5,
		num: 202,
	},
	"sniper": {
		shortDesc: "If this Pokemon strikes with a critical hit, the damage is multiplied by 1.5.",
		onModifyDamage: function (damage, source, target, move) {
			if (move.crit) {
				this.debug('Sniper boost');
				return this.chainModify(1.5);
			}
		},
		id: "sniper",
		name: "Sniper",
		rating: 1,
		num: 97,
	},
	"snowcloak": {
		desc: "If Hail is active, this Pokemon's evasiveness is multiplied by 1.25. This Pokemon takes no damage from Hail.",
		shortDesc: "If Hail is active, this Pokemon's evasiveness is 1.25x; immunity to Hail.",
		onImmunity: function (type, pokemon) {
			if (type === 'hail') return false;
		},
		onModifyMove: function (move, source, target) {
			if (!move || (move.category !== 'Physical' && move.category !== 'Special')) return;
			if (!move.secondaries) {
				move.secondaries = [];
			}
			move.secondaries.push({
				chance: 15,
				status: 'frz',
				ability: this.getAbility('snowcloak'),
			});
		},
		id: "snowcloak",
		name: "Snow Cloak",
		rating: 3,
		num: 81,
	},
	"snowcloakold": {
		desc: "If Hail is active, this Pokemon's evasiveness is multiplied by 1.25. This Pokemon takes no damage from Hail.",
		shortDesc: "If Hail is active, this Pokemon's evasiveness is 1.25x; immunity to Hail.",
		onImmunity: function (type, pokemon) {
			if (type === 'hail') return false;
		},
		onModifyAccuracy: function (accuracy) {
			if (typeof accuracy !== 'number') return;
			if (this.isWeather('hail')) {
				this.debug('Snow Cloak - decreasing accuracy');
				return accuracy * 0.8;
			}
		},
		isNonstandard: true,
		id: "snowcloakold",
		name: "Snow Cloakold",
		rating: 1.5,
		num: 81,
	},
	"snowwarning": {
		shortDesc: "On switch-in, this Pokemon summons Hail.",
		onStart: function (source) {
			if (source.item === 'roomservice') {
				this.add('-message', "" + source.name + "'s Room Service is evaporating the Snow into a torrent of Water!");
				this.setWeather('raindance');
			} else {
				this.setWeather('hail');
			}
		},
		setSnow: true,
		id: "snowwarning",
		name: "Snow Warning",
		rating: 4,
		num: 117,
	},
	"solarpower": {
		desc: "If Sunny Day is active, this Pokemon's Special Attack is multiplied by 1.5 and it loses 1/8 of its maximum HP, rounded down, at the end of each turn.",
		shortDesc: "If Sunny Day is active, this Pokemon's Sp. Atk is 1.5x; loses 1/8 max HP per turn.",
		onModifySpAPriority: 5,
		onModifySpA: function (spa, pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				return this.chainModify(1.5);
			}
		},
		id: "solarpower",
		name: "Solar Power",
		rating: 2.5,
		num: 94,
	},
	"sandeater": {
		desc: "Pokemon's Grass-Type Moves have quadrupled power under Sandstorm.",
		shortDesc: "Pokemon's Grass-Type Moves have quadrupled power under Sandstorm.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if ((move && move.type === 'Grass') && this.isWeather(['sandstorm']) && !move.ignoreWeather && !move.boostSand && !move.ignoreSand) {
				return this.chainModify([0x4000, 0x1000]);
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.status && this.isWeather(['sandstorm'])) {
				this.debug('sandeater');
				this.add('-activate', pokemon, 'ability: Sand Eater');
				pokemon.cureStatus();
			}
		},
		onImmunity: function (type, pokemon) {
			if (type === 'sandstorm') return false;
		},
		id: "sandeater",
		name: "Sand Eater",
		rating: 3,
		num: 94,
	},
	"solidrock": {
		shortDesc: "This Pokemon receives 3/4 damage from supereffective attacks.",
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.typeMod > 0) {
				this.debug('Solid Rock neutralize');
				return this.chainModify(0.75);
			}
		},
		id: "solidrock",
		name: "Solid Rock",
		rating: 3,
		num: 116,
	},
	"soulheart": {
		desc: "This Pokemon's Special Attack is raised by 1 stage when another Pokemon faints.",
		shortDesc: "This Pokemon's Sp. Atk is raised by 1 stage when another Pokemon faints.",
		onSourceFaint: function (target, source, effect) {
			if (effect && effect.effectType === 'Move' && !source.volatiles['soulheartcheck']) {
				this.boost({spa:1}, source);
				source.addVolatile('soulheartcheck');
			}
		},
		id: "soulheart",
		name: "Soul-Heart",
		rating: 3.5,
		num: 220,
	},
	"soundproof": {
		shortDesc: "This Pokemon is immune to sound-based moves, including Heal Bell.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.flags['sound']) {
				this.add('-immune', target, '[msg]', '[from] ability: Soundproof');
				return null;
			}
		},
		onAllyTryHitSide: function (target, source, move) {
			if (move.flags['sound']) {
				this.add('-immune', this.effectData.target, '[msg]', '[from] ability: Soundproof');
			}
		},
		id: "soundproof",
		name: "Soundproof",
		rating: 2,
		num: 43,
	},
	"speedboost": {
		desc: "This Pokemon's Speed is raised by 1 stage at the end of each full turn it has been on the field.",
		shortDesc: "This Pokemon's Speed is raised 1 stage at the end of each full turn on the field.",
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && !pokemon.boosts.spe >= 1) {
				this.boost({spe:1});
			}
		},
		id: "speedboost",
		name: "Speed Boost",
		rating: 3.5,
		num: 3,
	},
	"heartless": {
		desc: "This Pokemon's Speed is raised by 1 stage at the end of each full turn it has been on the field.",
		shortDesc: "This Pokemon's Speed is raised 1 stage at the end of each full turn on the field.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if (pokemon.activeTurns <= 1) return;
			if (pokemon.activeTurns <= 2) {
				this.debug('Heartless 1 boost');
				return this.chainModify(1.2);
			} else if (pokemon.activeTurns <= 3) {
				this.debug('Heartless 2 boost');
				return this.chainModify(1.35);
			} else if (pokemon.activeTurns <= 4) {
				this.debug('Heartless 3 boost');
				return this.chainModify(1.5);
			} else if (pokemon.activeTurns <= 5) {
				this.debug('Heartless 4 boost');
				return this.chainModify(1.65);
			} else if (pokemon.activeTurns >= 6) {
				this.debug('Heartless 5 boost');
				return this.chainModify(1.8);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns <= 0) return;
			if (pokemon.activeTurns <= 1) {
				this.add('-ability', pokemon, 'Heartless');
				this.add('-message', "" + pokemon.name + "'s power has grown by x1.2!");
			} else if (pokemon.activeTurns <= 2) {
				this.add('-ability', pokemon, 'Heartless');
				this.add('-message', "" + pokemon.name + "'s power has grown by x1.35!");
			} else if (pokemon.activeTurns <= 3) {
				this.add('-ability', pokemon, 'Heartless');
				this.add('-message', "" + pokemon.name + "'s power has grown by x1.5!");
			} else if (pokemon.activeTurns <= 4) {
				this.add('-ability', pokemon, 'Heartless');
				this.add('-message', "" + pokemon.name + "'s power has grown by x1.65!");
			} else if (pokemon.activeTurns >= 5 && !pokemon.volatiles['heartlessfinish']) {
				this.add('-ability', pokemon, 'Heartless');
				this.add('-message', "" + pokemon.name + "'s power has grown by x1.8!");
				this.add('-message', "" + pokemon.name + " is at Max Power!");
				pokemon.addVolatile('heartlessfinish');
			}
		},
		id: "heartless",
		name: "Heartless",
		rating: 3,
		num: 3,
	},
	"chillingneigh": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			if (!pokemon.boosts.atk >= 1) {
				this.boost({atk:1});
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns >= 3 && !pokemon.volatiles['endcneigh']) {
				pokemon.addVolatile('endcneigh');
				pokemon.addVolatile('unsetcneigh');
				this.boost({atk:-1});
				pokemon.removeVolatile('unsetcneigh');
			} 
		},
		id: "chillingneigh",
		name: "Chilling Neigh",
		rating: 4.5,
		num: 88,
	},
	"grimneigh": {
		desc: ".",
		shortDesc: ".",
		onStart: function (pokemon) {
			if (!pokemon.boosts.spa >= 1) {
				this.boost({spa:1});
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns >= 3 && !pokemon.volatiles['endgneigh']) {
				pokemon.addVolatile('endgneigh');
				pokemon.addVolatile('unsetgneigh');
				this.boost({spa:-1});
				pokemon.removeVolatile('unsetgneigh');
			} 
		},
		id: "grimneigh",
		name: "Grim Neigh",
		rating: 4.5,
		num: 88,
	},
	"stakeout": {
		shortDesc: "This Pokemon's attacks deal double damage if the target switched in this turn.",
		onModifyDamage: function (damage, source, target) {
			if (!target.activeTurns) {
				this.debug('Stakeout boost');
				return this.chainModify(2);
			}
		},
		id: "stakeout",
		name: "Stakeout",
		rating: 2.5,
		num: 198,
	},
	"stall": {
		shortDesc: "This Pokemon moves last among Pokemon using the same or greater priority moves.",
		onModifyPriority: function (priority) {
			return Math.round(priority) - 0.1;
		},
		id: "stall",
		name: "Stall",
		rating: -1,
		num: 100,
	},
	"inertia": {
		shortDesc: "This Pokemon will always outspeed opponent if its Base Speed is higher.",
		onModifyPriority: function (priority, pokemon, target, move) {
			if (move && pokemon.volatiles['inertiacheck']) {
				return priority + 0.01;
			}
		},
		onUpdate: function (pokemon) {
			let foeactive = pokemon.side.foe.active;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i].volatiles['inertial']) foeactive[i].addVolatile('inertial');
				if (!foeactive[i] || foeactive[i].fainted) continue;
				if ((pokemon.baseStats.spe >= foeactive[i].baseStats.spe) && !pokemon.volatiles['inertiacheck']) {
					pokemon.addVolatile('inertiacheck');
				} else if ((pokemon.baseStats.spe < foeactive[i].baseStats.spe) && pokemon.volatiles['inertiacheck']) {
					pokemon.removeVolatile('inertiacheck');
				}
			}
		},
		id: "inertia",
		name: "Inertia",
		rating: 3,
		num: 100,
	},
	"stamina": {
		shortDesc: "Pokemon Restores health at the end of each turn.",
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 4);
		},
		id: "stamina",
		name: "Stamina",
		switchHealing: true,
		rating: 5,
		num: 192,
	},
	"mistyblessing": {
		shortDesc: "Pokemon Restores health at the end of each turn.",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Misty Blessing');
				this.add('-message', "" + pokemon.name + " is enveloped in a blissful mist!");
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.volatiles['activechange']) {
				this.heal(pokemon.maxhp / 10);
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Poison' || (move && move.category !== 'Status' && move.flags['spout'])) {
				this.debug('Misty neutralize');
				return this.chainModify(0.5);
			}
		},
		onSwitchOut: function (pokemon) {
			pokemon.heal(pokemon.maxhp / 4);
		},
		id: "mistyblessing",
		name: "Misty Blessing",
		switchHealing: true,
		rating: 5,
		num: 192,
	},
	"grassyblessing": {
		desc: ".",
		shortDesc: ".",
		onTryHit: function (target, source, move) {
			if (target !== source && (move.id === 'sparklewave' || move.id === 'uproar')) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Grassy Blessing');
				}
				return null;
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['grbl']) target.removeVolatile('grbl');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['grbl']) defender.addVolatile('grbl');
			if (move.type === 'Grass') move.flags['exempt'] = true;
		},
		id: "grassyblessing",
		name: "Grassy Blessing",
		rating: 3.5,
		num: 11,
	},
	"perpetuity": {
		shortDesc: "Pokemon Restores health at the end of each turn.",
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 10) {
				this.heal(pokemon.maxhp);
				if (pokemon.status) {
					this.add('-activate', pokemon, 'ability: Perpetuity');
					pokemon.cureStatus();
				}
			}
		},
		id: "perpetuity",
		name: "Perpetuity",
		rating: 2.5,
		num: 192,
	},
	"stancechange": {
		desc: "If this Pokemon is an Aegislash, it changes to Blade Forme before attempting to use an attacking move, and changes to Shield Forme before attempting to use King's Shield.",
		shortDesc: "If Aegislash, changes Forme to Blade before attacks and Shield before King's Shield.",
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (attacker.template.baseSpecies !== 'Aegislash' || attacker.transformed) return;
			if (move.category === 'Status' && move.id !== 'kingsshield') return;
			let targetSpecies = (move.id === 'kingsshield' ? 'Aegislash' : 'Aegislash-Blade');
			if (attacker.template.species !== targetSpecies && attacker.formeChange(targetSpecies)) {
				this.add('-formechange', attacker, targetSpecies, '[from] ability: Stance Change');
				attacker.addVolatile('formecheck');
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['sword']) {
				this.debug('Stance Change boost');
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		id: "stancechange",
		name: "Stance Change",
		rating: 5,
		num: 176,
	},
	"static": {
		shortDesc: "30% chance a Pokemon making contact with this Pokemon will be paralyzed.",
		onAfterDamage: function (damage, target, source, move) {
			if (move && move.flags['contact']) {
				if (this.random(10) < 3) {
					source.trySetStatus('par', target);
				}
			}
		},
		id: "static",
		name: "Static",
		rating: 2,
		num: 9,
	},
	"steadfast": {
		shortDesc: "If this Pokemon is statused, its Speed is raised by 2x.",
		onDragOutPriority: 1,
		onDragOut: function (pokemon) {
			this.add('-activate', pokemon, 'ability: Steadfast');
			this.boost({atk:1, spa:1});
			return null;
		},
		id: "steadfast",
		name: "Steadfast",
		rating: 3,
		num: 80,
	},
	"steelworker": {
		shortDesc: "This Pokemon's Steel-type attacks have their power multiplied by 1.5.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.type === 'Steel') {
				this.debug('Steelworker boost');
				return this.chainModify(1.5);
			}
		},
		id: "steelworker",
		name: "Steelworker",
		rating: 3,
		num: 200,
	},
	"stench": {
		shortDesc: "This Pokemon's attacks without a chance to flinch have a 10% chance to flinch.",
		onModifyMove: function (move) {
			if (move.category !== "Status") {
				this.debug('Adding Stench flinch');
				if (!move.secondaries) move.secondaries = [];
				for (let i = 0; i < move.secondaries.length; i++) {
					if (move.secondaries[i].volatileStatus === 'flinch') return;
				}
				move.secondaries.push({
					chance: 10,
					volatileStatus: 'flinch',
				});
			}
		},
		id: "stench",
		name: "Stench",
		rating: 0.5,
		num: 1,
	},
	"stickyhold": {
		shortDesc: "This Pokemon cannot lose its held item due to another Pokemon's attack.",
		onTakeItem: function (item, pokemon, source) {
			if (this.suppressingAttackEvents() && pokemon !== this.activePokemon || !pokemon.hp || pokemon.item === 'stickybarb') return;
			if ((source && source !== pokemon) || this.activeMove.id === 'knockoff') {
				this.add('-activate', pokemon, 'ability: Sticky Hold');
				return false;
			}
		},
		id: "stickyhold",
		name: "Sticky Hold",
		rating: 1.5,
		num: 60,
	},
	"stormdrain": {
		desc: "This Pokemon is immune to Water-type moves and raises its Special Attack by 1 stage when hit by a Water-type move. If this Pokemon is not the target of a single-target Water-type move used by another Pokemon, this Pokemon redirects that move to itself if it is within the range of that move.",
		shortDesc: "This Pokemon draws Water moves to itself to raise Sp. Atk by 1; Water immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Water') {
				if (!this.boost({spa:1})) {
					this.add('-immune', target, '[msg]', '[from] ability: Storm Drain');
				}
				return null;
			}
		},
		onAnyRedirectTarget: function (target, source, source2, move) {
			if (move.type !== 'Water' || move.id in {firepledge:1, grasspledge:1, waterpledge:1}) return;
			if (this.validTarget(this.effectData.target, source, move.target)) {
				if (this.effectData.target !== target) {
					this.add('-activate', this.effectData.target, 'ability: Storm Drain');
				}
				return this.effectData.target;
			}
		},
		id: "stormdrain",
		name: "Storm Drain",
		rating: 3.5,
		num: 114,
	},
	"strongjaw": {
		desc: "This Pokemon's bite-based attacks have their power multiplied by 1.5.",
		shortDesc: "This Pokemon's bite-based attacks have 1.5x power. Bug Bite is not boosted.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['bite']) {
				return this.chainModify(1.5);
			}
		},
		id: "strongjaw",
		name: "Strong Jaw",
		rating: 3,
		num: 173,
	},
	"sturdy": {
		desc: "If this Pokemon is at full HP, it survives one hit with at least 1 HP. OHKO moves fail when used against this Pokemon.",
		shortDesc: "If this Pokemon is at full HP, it survives one hit with at least 1 HP. Immune to OHKO.",
		onAfterDamageOrder: 1,
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.flags['contact']) {
				this.damage(source.maxhp / 8, source, target);
			}
		},
		id: "sturdy",
		name: "Sturdy",
		rating: 3,
		num: 5,
	},
	"suctioncups": {
		shortDesc: "This Pokemon cannot be forced to switch out by another Pokemon's attack or item.",
		onDragOutPriority: 1,
		onDragOut: function (pokemon) {
			this.add('-activate', pokemon, 'ability: Suction Cups');
			return null;
		},
		id: "suctioncups",
		name: "Suction Cups",
		rating: 2,
		num: 21,
	},
	"superluck": {
		shortDesc: "This Pokemon's critical hit ratio is raised by 1 stage.",
		onModifyCritRatio: function (critRatio) {
			return critRatio + 1;
		},
		id: "superluck",
		name: "Super Luck",
		rating: 1.5,
		num: 105,
	},
	"surgesurfer": {
		shortDesc: "If Electric Terrain is active, this Pokemon's Speed is doubled.",
		onModifySpe: function (spe) {
			if (this.isTerrain('electricterrain')) {
				return this.chainModify(2);
			}
		},
		id: "surgesurfer",
		name: "Surge Surfer",
		rating: 2,
		num: 207,
	},
	"swarm": {
		desc: "When this Pokemon has 1/3 or less of its maximum HP, rounded down, its attacking stat is multiplied by 1.5 while using a Bug-type attack.",
		shortDesc: "When this Pokemon has 1/3 or less of its max HP, its Bug attacks do 1.5x damage.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, attacker, defender, move) {
			if (move.type === 'Bug' && attacker.hp <= attacker.maxhp / 3) {
				this.debug('Swarm boost');
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (atk, attacker, defender, move) {
			if (move.type === 'Bug' && attacker.hp <= attacker.maxhp / 3) {
				this.debug('Swarm boost');
				return this.chainModify(1.5);
			}
		},
		id: "swarm",
		name: "Swarm",
		rating: 2,
		num: 68,
	},
	"sweetveil": {
		shortDesc: "This Pokemon and its allies cannot fall asleep.",
		id: "sweetveil",
		name: "Sweet Veil",
		onAllySetStatus: function (status, target, source, effect) {
			if (status.id === 'slp') {
				this.debug('Sweet Veil interrupts sleep');
				this.add('-activate', this.effectData.target, 'ability: Sweet Veil', '[of] ' + target);
				return null;
			}
		},
		onAllyTryAddVolatile: function (status, target) {
			if (status.id === 'yawn') {
				this.debug('Sweet Veil blocking yawn');
				this.add('-activate', this.effectData.target, 'ability: Sweet Veil', '[of] ' + target);
				return null;
			}
		},
		rating: 2,
		num: 175,
	},
	"swiftswim": {
		shortDesc: "If Rain Dance is active, this Pokemon's Speed is doubled.",
		onModifySpe: function (spe, pokemon) {
			if (this.isWeather(['raindance', 'primordialsea'])) {
				return this.chainModify(2);
			}
		},
		id: "swiftswim",
		name: "Swift Swim",
		rating: 2.5,
		num: 33,
	},
	"symbiosis": {
		desc: "If an ally uses its item, this Pokemon gives its item to that ally immediately. Does not activate if the ally's item was stolen or knocked off.",
		shortDesc: "If an ally uses its item, this Pokemon gives its item to that ally immediately.",
		onAllyAfterUseItem: function (item, pokemon) {
			let sourceItem = this.effectData.target.getItem();
			if (!sourceItem) return;
			if (!this.singleEvent('TakeItem', item, this.effectData.target.itemData, this.effectData.target, pokemon, this.effectData, item)) return;
			sourceItem = this.effectData.target.takeItem();
			if (!sourceItem) {
				return;
			}
			if (pokemon.setItem(sourceItem)) {
				this.add('-activate', this.effectData.target, 'ability: Symbiosis', sourceItem, '[of] ' + pokemon);
			}
		},
		id: "symbiosis",
		name: "Symbiosis",
		rating: 0,
		num: 180,
	},
	"synchronize": {
		desc: "If another Pokemon burns, paralyzes, poisons, or badly poisons this Pokemon, that Pokemon receives the same major status condition.",
		shortDesc: "If another Pokemon burns/poisons/paralyzes this Pokemon, it also gets that status.",
		onAfterSetStatus: function (status, target, source, effect) {
			if (!source || source === target) return;
			if (effect && effect.id === 'toxicspikes') return;
			if (status.id === 'slp' || status.id === 'frz') return;
			this.add('-activate', target, 'ability: Synchronize');
			source.trySetStatus(status, target, {status: status.id, id: 'synchronize'});
		},
		id: "synchronize",
		name: "Synchronize",
		rating: 2.5,
		num: 28,
	},
	"tangledfeet": {
		shortDesc: "This Pokemon's evasiveness is doubled as long as it is confused.",
		onModifyAccuracy: function (accuracy, target) {
			if (typeof accuracy !== 'number') return;
			if (target && target.volatiles['confusion']) {
				this.debug('Tangled Feet - decreasing accuracy');
				return accuracy * 0.5;
			}
		},
		id: "tangledfeet",
		name: "Tangled Feet",
		rating: 1,
		num: 77,
	},
	"tanglinghair": {
		shortDesc: "Pokemon making contact with this Pokemon have their Speed lowered by 1 stage.",
		onAfterDamage: function (damage, target, source, effect) {
			if (effect && effect.flags['contact']) {
				this.add('-ability', target, 'Tangling Hair');
				this.boost({spe: -1}, source, target, null, null, true);
			}
		},
		id: "tanglinghair",
		name: "Tangling Hair",
		rating: 2.5,
		num: 221,
	},
	"technician": {
		desc: "This Pokemon's moves of 60 power or less have their power multiplied by 1.5. Does affect Struggle.",
		shortDesc: "This Pokemon's moves of 60 power or less have 1.5x power. Includes Struggle.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (basePower <= 100 && (move.priority < 1 && !move.flags['super']) && !move.multihit) {
				this.debug('Technician boost');
				return this.chainModify(1.5);
			} else if (basePower <= 100 && (move.priority >= 1 || move.multihit)) {
				this.debug('Technician boost');
				return this.chainModify(1.3);
			}
		},
		id: "technician",
		name: "Technician",
		rating: 4,
		num: 101,
	},
	"strategist": {
		desc: "This Pokemon's moves of 60 power or less have their power multiplied by 1.5. Does affect Struggle.",
		shortDesc: "This Pokemon's moves of 60 power or less have 1.5x power. Includes Struggle.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if ((basePower <= 155 && move.type === 'Psychic' || (move.category === 'Special' && basePower <= 120 && move.type !== 'Psychic') || (move.category === 'Special' && (move.flags['increment'] || move.flags['scalar']))) && (!move.flags['burst'] && !move.flags['kinetic'] && !move.flags['isswave'] && move.priority < 1)) {
				this.debug('Strategist Boost');
				return this.chainModify(1.4);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "strategist",
		name: "Strategist",
		rating: 4,
		num: 101,
	},
	"telepathy": {
		shortDesc: "This Pokemon does not take damage from attacks made by its allies.",
		onTryHit: function (target, source, move) {
			if (target !== source && target.side === source.side && move.category !== 'Status') {
				this.add('-activate', target, 'ability: Telepathy');
				return null;
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.priority >= 1) {
				this.debug('Telepathy neutralize');
				return this.chainModify(0.67);
			}
		},
		id: "telepathy",
		name: "Telepathy",
		rating: 3,
		num: 140,
	},
	"teravolt": {
		shortDesc: "This Pokemon's moves and their effects ignore the Abilities of other Pokemon.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Teravolt');
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Electric' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onModifyDamage: function (damage, source, target, move) {
			if (source.hasType('Electric') && move.type === 'Electric' && move.typeMod > 0) {
				return this.chainModify([0x2000, 0x1000]);
			}
		},
		onModifyMove: function (move) {
			move.ignoreAbility = true;
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target !== source) return;
			let showMsg = false;
			for (let i in boost) {
				if (effect.type === 'Electric' && (!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Teravolt", "[of] " + target);
		},
		id: "teravolt",
		isBreaker: true,
		name: "Teravolt",
		rating: 3.5,
		num: 164,
	},
	"lightningforce": {
		shortDesc: "This Pokemon's moves and their effects ignore the Abilities of other Pokemon.",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				if (pokemon.item !== 'electricmemory') {
					this.add('-ability', pokemon, 'Lightning Force');
					this.add('-message', "" + pokemon.name + "'s Lightning Energy is overflowing!");
					pokemon.addVolatile('allowkokoboost');
				} else {
					this.add('-ability', pokemon, 'Lightning Force');
					this.add('-message', "" + pokemon.name + "'s power is already at its limit!");
				}
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			if ((move && move.type === 'Electric') && pokemon.volatiles['allowkokoboost']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if ((move.type === 'Electric' || move.type === 'Flying') && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onModifyMovePriority: -5,
		onModifyMove: function (move) {
			if (!move.ignoreImmunity) move.ignoreImmunity = {};
			if (move.id === 'voltswitch' && move.ignoreImmunity !== true) {
				move.ignoreImmunity['Electric'] = true;
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (target.volatiles['lightningforceeffect']) target.removeVolatile('lightningforceeffect');
		},
		onBeforeMovePriority: 0.5,
		onBeforeMove: function (attacker, defender, move) {
			if (!defender.volatiles['lightningforceeffect']) defender.addVolatile('lightningforceeffect');
			if (move.type === 'Electric' && defender.hasType('Fire')) move.flags['exempt'] = true;
		},
		id: "lightningforce",
		name: "Lightning Force",
		rating: 3.5,
		num: 1640,
	},
	"birdofprey": {
		desc: "This Pokemon receives 1/4 damage from contact moves.",
		shortDesc: "This Pokemon takes 1/4.",
		onSwitchIn: function (pokemon) {
			this.add('-ability', pokemon, 'Bird of Prey');
			this.add('-message', "" + pokemon.name + " is harboring malicious intentions!");
		},
		onBasePower: function (basePower, attacker, defender, move) {
			if (move) {
				return this.chainModify(0.5);
			}
		},
		onModifyMove: function (move, source, target) {
			if (target !== source && target.hp <= target.maxhp / 2) {
				this.add('-message', "" + source.name + " has abandoned all mercy!");
				move.ohko = true;
			}
		},
		id: "birdofprey",
		name: "Bird of Prey",
		rating: 4,
		num: 253,
	},
	"thickfat": {
		desc: "If a Pokemon uses a Fire- or Ice-type attack against this Pokemon, that Pokemon's attacking stat is halved when calculating the damage to this Pokemon.",
		shortDesc: "Fire/Ice-type moves against this Pokemon deal damage with a halved attacking stat.",
		onModifyAtkPriority: 6,
		onSourceModifyAtk: function (atk, attacker, defender, move) {
			if (move.type === 'Ice' || move.type === 'Fire') {
				this.debug('Thick Fat weaken');
				return this.chainModify(0.5);
			}
		},
		onModifySpAPriority: 5,
		onSourceModifySpA: function (atk, attacker, defender, move) {
			if (move.type === 'Ice' || move.type === 'Fire') {
				this.debug('Thick Fat weaken');
				return this.chainModify(0.5);
			}
		},
		id: "thickfat",
		name: "Thick Fat",
		rating: 3.5,
		num: 47,
	},
	"tintedlens": {
		shortDesc: "This Pokemon's attacks that are not very effective on a target deal double damage.",
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Tinted Lens boost');
				return this.chainModify(1.5);
			}
		},
		id: "tintedlens",
		name: "Tinted Lens",
		rating: 3.5,
		num: 110,
	},
	"spacelogic": {
		shortDesc: "This Pokemon's Water-Type attacks that are not very effective on a target deal quadruple damage.",
		onModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Water' && move.typeMod < 0) {
				this.debug('Space Logic boost');
				return this.chainModify(2);
			}
		},
		id: "spacelogic",
		name: "Space Logic",
		rating: 2.5,
		num: 110,
	},
	"eternalstream": {
		shortDesc: "This Pokemon's Water-Type attacks that are not very effective on a target deal quadruple damage.",
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Water' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Water' && move.typeMod < 0) {
				this.debug('Eternal Stream boost');
				return this.chainModify(2);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "eternalstream",
		name: "Eternal Stream",
		rating: 2.5,
		num: 110,
	},
	"etherealsky": {
		shortDesc: "This Pokemon's attacks that are not very effective on a target deal double damage.",
		onModifyDamage: function (damage, source, target, move) {
			if (move.typeMod < 0) {
				this.debug('Ethereal Stream boost');
				return this.chainModify(1.5);
			}
		},
		isUnbreakable: true,
		isMemorized: true,
		id: "etherealsky",
		name: "Ethereal Sky",
		rating: 3.5,
		num: 110,
	},
	"torrent": {
		desc: "When this Pokemon has 1/3 or less of its maximum HP, rounded down, its attacking stat is multiplied by 1.5 while using a Water-type attack.",
		shortDesc: "When this Pokemon has 1/3 or less of its max HP, its Water attacks do 1.5x damage.",
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, attacker, defender, move) {
			if (move.type === 'Water' && attacker.hp <= attacker.maxhp / 3) {
				this.debug('Torrent boost');
				return this.chainModify(1.5);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (atk, attacker, defender, move) {
			if (move.type === 'Water' && attacker.hp <= attacker.maxhp / 3) {
				this.debug('Torrent boost');
				return this.chainModify(1.5);
			}
		},
		id: "torrent",
		name: "Torrent",
		rating: 2,
		num: 67,
	},
	"toxicboost": {
		desc: "While this Pokemon is poisoned, the power of its physical attacks is multiplied by 1.5.",
		shortDesc: "While this Pokemon is poisoned, its physical attacks have 1.5x power.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if ((attacker.status === 'psn' || attacker.status === 'tox') && move.category === 'Physical') {
				return this.chainModify(1.5);
			}
		},
		id: "toxicboost",
		name: "Toxic Boost",
		rating: 3,
		num: 137,
	},
	"toughclaws": {
		shortDesc: "This Pokemon's contact moves have their power multiplied by 1.3.",
		onBasePowerPriority: 8,
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.flags['contact'] || move.flags['tactile']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		id: "toughclaws",
		name: "Tough Claws",
		rating: 3.5,
		num: 181,
	},
	"trace": {
		desc: "On switch-in, this Pokemon copies a random adjacent opposing Pokemon's Ability. If there is no Ability that can be copied at that time, this Ability will activate as soon as an Ability can be copied. Abilities that cannot be copied are Comatose, Disguise, Flower Gift, Forecast, Illusion, Imposter, Multitype, Schooling, Stance Change, Trace, and Zen Mode.",
		shortDesc: "On switch-in, or when it can, this Pokemon copies a random adjacent foe's Ability.",
		onStart: function (pokemon) {
			let possibleTargets = [];
			for (let i = 0; i < pokemon.side.foe.active.length; i++) {
				if (pokemon.side.foe.active[i] && !pokemon.side.foe.active[i].fainted) possibleTargets.push(pokemon.side.foe.active[i]);
			}
			while (possibleTargets.length) {
				let rand = 0;
				if (possibleTargets.length > 1) rand = this.random(possibleTargets.length);
				let target = possibleTargets[rand];
				let ability = this.getAbility(target.ability);
				let bannedAbilities = {comatose:1, disguise:1, flowergift:1, forecast:1, illusion:1, imposter:1, multitype:1, schooling:1, stancechange:1, trace:1, zenmode:1, impervious:1, desolateland:1, primordialsea:1, deltastream:1, psychoforce:1, psychicassault:1, psychicpower:1, hightenedmind:1, oppression:1, slowstart:1, malleate:1, climatechange:1, dragonascension:1, ensemble:1, moldbreaker:1, turboblaze:1, teravolt:1, regression:1, dragonpower:1, omnipotent:1, spacepower:1, formatdrive:1, aurabreak:1, mirrorshadow:1};
				if (bannedAbilities[target.ability]) {
					this.boost({spd:1});
					possibleTargets.splice(rand, 1);
					continue;
				}
				this.add('-ability', pokemon, ability, '[from] ability: Trace', '[of] ' + target);
				pokemon.setAbility(ability);
				return;
			}
		},
		id: "trace",
		name: "Trace",
		rating: 3,
		num: 36,
	},
	"triage": {
		shortDesc: "This Pokemon's healing moves have their priority increased by 3.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Triage');
			this.add('-message', "" + pokemon.name + " is brimming with energy!");
		},
		onModifyPriority: function (priority, pokemon, target, move) {
			if (pokemon.volatiles['inertial']) return;
			if (move && move.flags['heal']) {
				return priority + 2;
			}
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon, target) {
			if (move && move.flags['heal']) {
				if (move.category !== 'Status') pokemon.addVolatile('triage');
			}
		},
		effect: {
			duration: 1,
			onBasePowerPriority: 8,
			onBasePower: function (basePower, pokemon, target, move) {
				return this.chainModify([0xCCC, 0x1000]);
			},
		},
		id: "triage",
		name: "Triage",
		rating: 3.5,
		num: 205,
	},
	"truant": {
		shortDesc: "This Pokemon skips every other turn instead of using a move.",
		onBeforeMovePriority: 9,
		onBeforeMove: function (pokemon, target, move) {
			if (pokemon.removeVolatile('truant')) {
				this.add('cant', pokemon, 'ability: Truant');
				return false;
			}
			pokemon.addVolatile('truant');
		},
		effect: {
			duration: 2,
		},
		id: "truant",
		name: "Truant",
		rating: -2,
		num: 54,
	},
	"turboblaze": {
		shortDesc: "This Pokemon's moves and their effects ignore the Abilities of other Pokemon.",
		onStart: function (pokemon) {
			this.add('-ability', pokemon, 'Turboblaze');
		},
		onAnyAccuracy: function (accuracy, target, source, move) {
			if (move.type === 'Fire' && (source === this.effectData.target)) {
				return true;
			}
			return accuracy;
		},
		onModifyDamage: function (damage, source, target, move) {
			if (source.hasType('Fire') && move.type === 'Fire' && move.typeMod > 0) {
				return this.chainModify([0x2000, 0x1000]);
			}
		},
		onModifyMove: function (move) {
			move.ignoreAbility = true;
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target !== source) return;
			let showMsg = false;
			for (let i in boost) {
				if (effect.type === 'Fire' && (!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Turboblaze", "[of] " + target);
		},
		id: "turboblaze",
		isBreaker: true,
		name: "Turboblaze",
		rating: 3.5,
		num: 163,
	},
	"unaware": {
		desc: "This Pokemon ignores other Pokemon's Attack, Special Attack, and accuracy stat stages when taking damage, and ignores other Pokemon's Defense, Special Defense, and evasiveness stat stages when dealing damage.",
		shortDesc: "This Pokemon ignores other Pokemon's stat stages when taking or doing damage.",
		onAnyModifyBoost: function (boosts, target) {
			let source = this.effectData.target;
			if (source === target) return;
			if (source === this.activePokemon && target === this.activeTarget) {
				boosts['def'] = 0;
				boosts['spd'] = 0;
				boosts['evasion'] = 0;
			}
			if (target === this.activePokemon && source === this.activeTarget) {
				boosts['atk'] = 0;
				boosts['spa'] = 0;
				boosts['def'] = 0;
				boosts['spd'] = 0;
				boosts['accuracy'] = 0;
			}
		},
		id: "unaware",
		name: "Unaware",
		rating: 3,
		num: 109,
	},
	"unburden": {
		desc: "If this Pokemon loses its held item for any reason, its Speed is doubled. This boost is lost if it switches out or gains a new item or Ability.",
		shortDesc: "Speed is doubled on held item loss; boost is lost if it switches, gets new item/Ability.",
		onAfterUseItem: function (item, pokemon) {
			if (pokemon !== this.effectData.target) return;
			pokemon.addVolatile('unburden');
			this.add('-ability', pokemon, 'Unburden');
			this.add('-message', "" + pokemon.name + " has unlocked its true potential!");
		},
		onTakeItem: function (item, pokemon) {
			pokemon.addVolatile('unburden');
			this.add('-ability', pokemon, 'Unburden');
			this.add('-message', "" + pokemon.name + " has unlocked its true potential!");
		},
		onEnd: function (pokemon) {
			pokemon.removeVolatile('unburden');
		},
		effect: {
			onModifySpe: function (spe, pokemon) {
				if (!pokemon.item) {
					return this.chainModify(2);
				}
			},
		},
		id: "unburden",
		name: "Unburden",
		rating: 3.5,
		num: 84,
	},
	"unnerve": {
		shortDesc: "While this Pokemon is active, it prevents opposing Pokemon from using their Berries.",
		onPreStart: function (pokemon) {
			this.add('-ability', pokemon, 'Unnerve', pokemon.side.foe);
		},
		onFoeTryEatItem: false,
		id: "unnerve",
		name: "Unnerve",
		rating: 1.5,
		num: 127,
	},
	"victorystar": {
		shortDesc: "This Pokemon and its allies' moves have their accuracy multiplied by 1.1.",
		onAllyModifyMove: function (move) {
			if (typeof move.accuracy === 'number') {
				move.accuracy *= 1.1;
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (target.volatiles['activechange'] && move && !move.flags['exempt'] && move.effectType === 'Move' && typeMod > 0) {
				return 0;
			}
		},
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isMemory) {
				this.add('-ability', pokemon, 'Victory Star');
				this.add('-message', "" + pokemon.name + " has cast aside its Weaknesses!");
			}
		},
		isUnbreakable: true,
		id: "victorystar",
		name: "Victory Star",
		rating: 2.5,
		num: 162,
	},
	"vitalspirit": {
		shortDesc: "This Pokemon cannot fall asleep. Gaining this Ability while asleep cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.status === 'slp') {
				this.add('-activate', pokemon, 'ability: Vital Spirit');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'slp') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Vital Spirit');
			return false;
		},
		id: "vitalspirit",
		name: "Vital Spirit",
		rating: 2,
		num: 72,
	},
	"voltabsorb": {
		desc: "This Pokemon is immune to Electric-type moves and restores 1/4 of its maximum HP, rounded down, when hit by an Electric-type move.",
		shortDesc: "This Pokemon heals 1/4 of its max HP when hit by Electric moves; Electric immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Electric') {
				if (!this.heal(target.maxhp / 4)) {
					this.add('-immune', target, '[msg]', '[from] ability: Volt Absorb');
				}
				return null;
			}
		},
		id: "voltabsorb",
		name: "Volt Absorb",
		rating: 3.5,
		num: 10,
	},
	"waterabsorb": {
		desc: "This Pokemon is immune to Water-type moves and restores 1/4 of its maximum HP, rounded down, when hit by a Water-type move.",
		shortDesc: "This Pokemon heals 1/4 of its max HP when hit by Water moves; Water immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Water') {
				if (!this.heal(target.maxhp / 4)) {
					this.add('-immune', target, '[msg]', '[from] ability: Water Absorb');
				}
				return null;
			}
		},
		id: "waterabsorb",
		name: "Water Absorb",
		rating: 3.5,
		num: 11,
	},
	"eartheater": {
		desc: "This Pokemon is immune to Ground-type moves and restores 1/4 of its maximum HP, rounded down, when hit by a Ground-type move.",
		shortDesc: "This Pokemon heals 1/4 of its max HP when hit by Ground moves; Ground immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Ground') {
				if (!this.heal(target.maxhp / 4)) {
					this.add('-immune', target, '[msg]', '[from] ability: Earth Eater');
				}
				return null;
			}
		},
		id: "eartheater",
		name: "Earth Eater",
		rating: 4,
		num: 11,
	},
	"battlebastion": {
		desc: "This Pokemon is immune to Ground-type moves and restores 1/4 of its maximum HP, rounded down, when hit by a Ground-type move.",
		shortDesc: "This Pokemon heals 1/4 of its max HP when hit by Ground moves; Ground immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Ground') {
				if (!this.heal(target.maxhp / 4)) {
					this.add('-immune', target, '[msg]', '[from] ability: Earth Eater');
				}
				return null;
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (effect.id === 'tailwindunused' || effect.id === 'trickroomunused') {
				this.attrLastMove('[still]');
				this.add('-activate', this.effectData.target, 'ability: Utility Lock');
				this.add('-message', "" + source.name + " cannot use this move!");
				return false;
			}
		},
		id: "battlebastion",
		name: "Battle Bastion",
		rating: 5,
		num: 11,
	},
	"icecoat": {
		desc: ".",
		shortDesc: ".",
		onSourceModifyDamage: function (damage, source, target, move) {
			if ((!source.hasAbility('intrepidsword') && !source.hasAbility('pokemonmaster')) && move.type === "Fire") {
				this.debug('Ice Coat neutralize');
				return this.chainModify(0.25);
			}
		},
		onModifyDef: function (def, pokemon) {
			if (this.isWeather(['hail'])) {
				return this.chainModify(1.5);
			}
		},
		onModifySpD: function (spd, pokemon) {
			if (this.isWeather(['hail'])) {
				return this.chainModify(1.5);
			}
		},
		id: "icecoat",
		name: "Ice Coat",
		rating: 3.5,
		num: 11,
	},
	"mirrorarmor": {
		shortDesc: "This Pokemon can hit Ground types with Electric-type moves.",
		onTryHit: function (target, source, move) {
			if (target !== source && target.hp >= target.maxhp / 2 && move.type === 'Ghost') {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Mirror Armor');
				}
				return null;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.status) {
				this.heal(pokemon.maxhp / 5);
			}
		},
		id: "mirrorarmor",
		name: "Mirror Armor",
		rating: 3,
		num: 113,
	},
	"impervious": {
		desc: ".",
		shortDesc: ".",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isBerry) {
				this.add('-ability', pokemon, 'Impervious');
				this.add('-message', "" + pokemon.name + " is blocking " + item.onBuffer + "-Type attacks!");
			}
		},
		onTryHit: function (target, source, move) {
			if (target !== source && (move.type === 'Bug' && target.item === 'tangaberry' || move.type === 'Dark' && target.item === 'colburberry' || move.type === 'Dragon' && target.item === 'habanberry' || move.type === 'Electric' && target.item === 'wacanberry' || move.type === 'Fighting' && target.item === 'chopleberry' || move.type === 'Fire' && target.item === 'occaberry' || move.type === 'Fairy' && target.item === 'roseliberry' || move.type === 'Flying' && target.item === 'cobaberry' || move.type === 'Ghost' && target.item === 'kasibberry' || move.type === 'Grass' && target.item === 'rindoberry' || move.type === 'Ground' && target.item === 'shucaberry' || move.type === 'Ice' && target.item === 'yacheberry' || move.type === 'Normal' && target.item === 'chilanberry' || move.type === 'Poison' && target.item === 'kebiaberry' || move.type === 'Psychic' && target.item === 'payapaberry' || move.type === 'Rock' && target.item === 'chartiberry' || move.type === 'Steel' && target.item === 'babiriberry' || move.type === 'Water' && target.item === 'passhoberry' || move.type === '???' && target.item === 'enigmaberry')) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Impervious');
				}
				return null;
			}
		},
		id: "impervious",
		name: "Impervious",
		rating: 3,
		num: 11,
	},
	"omnipotent": {
		desc: ".",
		shortDesc: ".",
		onSwitchIn: function (pokemon) {
			let item = pokemon.getItem();
			if (item.isBerry) {
				this.add('-ability', pokemon, 'Omnipotent');
				this.add('-message', "" + pokemon.name + " is overflowing with " + item.onBuffer + "-Type energy!");
			}
		},
		onBasePowerPriority: 8,
		onBasePower: function (basePower, pokemon, target, move) {
			let judgment = pokemon.getItem();
			if (pokemon.template.species !== 'Arceus') return;
			if (!judgment.isBerry) return;
			if (move.type === judgment.onBuffer) {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onTryHit: function (target, source, move) {
			if (target !== source && target.template.species === 'Arceus' && (move.type === 'Bug' && target.item === 'tangaberry' || move.type === 'Dark' && target.item === 'colburberry' || move.type === 'Dragon' && target.item === 'habanberry' || move.type === 'Electric' && target.item === 'wacanberry' || move.type === 'Fighting' && target.item === 'chopleberry' || move.type === 'Fire' && target.item === 'occaberry' || move.type === 'Fairy' && target.item === 'roseliberry' || move.type === 'Flying' && target.item === 'cobaberry' || move.type === 'Ghost' && target.item === 'kasibberry' || move.type === 'Grass' && target.item === 'rindoberry' || move.type === 'Ground' && target.item === 'shucaberry' || move.type === 'Ice' && target.item === 'yacheberry' || move.type === 'Normal' && target.item === 'chilanberry' || move.type === 'Poison' && target.item === 'kebiaberry' || move.type === 'Psychic' && target.item === 'payapaberry' || move.type === 'Rock' && target.item === 'chartiberry' || move.type === 'Steel' && target.item === 'babiriberry' || move.type === 'Water' && target.item === 'passhoberry' || move.type === '???' && target.item === 'enigmaberry')) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Omnipotent');
				}
				return null;
			}
		},
		onModifyMove: function (move, pokemon) {
			let foundation = pokemon.getItem();
			if (pokemon.template.species !== 'Arceus') return;
			if (foundation.isMemory && pokemon.volatiles['activechange'] && move.type === 'Normal') return;
			if (pokemon.volatiles['mewtwobunused']) return;
			if ((move.type !== pokemon.types[0] && move.type !== pokemon.types[1]) && move.type !== foundation.onMemory && (move.category === 'Physical' || move.category === 'Special')) {
				move.hasSTAB = true;
				move.stab = 1.3;
			}
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (pokemon.positiveBoosts()) {
					if ((this.getMove(moves[i].move).flags['heal'] || this.getMove(moves[i].move).flags['autoheal']) && !this.getMove(moves[i].move).flags['healswitch']) {
						pokemon.disableMove(moves[i].id);
					}
				}
			}
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.priority >= 1 && target.template.species === 'Arceus') {
				this.debug('Omnipotent neutralize');
				return this.chainModify(0.5);
			}
		},
		id: "omnipotent",
		name: "Omnipotent",
		rating: 5,
		num: 11,
	},
	"mischievous": {
		desc: "This Pokemon's Speed is raised by 1 stage at the end of each full turn it has been on the field.",
		shortDesc: "This Pokemon's Speed is raised 1 stage at the end of each full turn on the field.",
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if ((this.getMove(moves[i].move).flags['heal'] || this.getMove(moves[i].move).flags['autoheal']) || this.getMove(moves[i].move).flags['healswitch'] || this.getMove(moves[i].move).flags['switch']) {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns) {
				let pokemonactive = pokemon.side.active;
				let activated = false;
				for (let i = 0; i < pokemonactive.length; i++) {
				if (!pokemonactive[i]) continue;
					if (this.runEvent('DragOut', pokemonactive[i], null, null)) {
						this.dragIn(pokemonactive[i].side, pokemonactive[i].position);
					}
				}
			}
		},
		onBasePower: function (basePower, attacker, defender, move) {
			if (move && (move.category === 'Physical' || move.category === 'Special') && move.flags['switchfoe']) {
				return this.chainModify(0.5);
			}
		},
		id: "mischievous",
		name: "Mischievous",
		rating: 3.5,
		num: 3,
	},
	"utilitylock": {
		desc: "This Pokemon is immune to Water-type moves and restores 1/4 of its maximum HP, rounded down, when hit by a Water-type move.",
		shortDesc: "This Pokemon heals 1/4 of its max HP when hit by Water moves; Water immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.flags['field']) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] ability: Utility Lock');
				}
				return null;
			}
		},
		onFoeTryMove: function (target, source, effect) {
			if (effect.id === 'tailwind' || effect.id === 'trickroom' || effect.id === 'junglehealing') {
				this.attrLastMove('[still]');
				this.add('-activate', this.effectData.target, 'ability: Utility Lock');
				this.add('-message', "" + source.name + " cannot use this move!");
				return false;
			}
		},
		id: "utilitylock",
		isLocker: true,
		name: "Utility Lock",
		rating: 3.5,
		num: 11,
	},
	"metalabsorb": {
		desc: "This Pokemon is immune to Water-type moves and restores 1/4 of its maximum HP, rounded down, when hit by a Water-type move.",
		shortDesc: "This Pokemon heals 1/4 of its max HP when hit by Water moves; Water immunity.",
		onTryHit: function (target, source, move) {
			if (target !== source && move.type === 'Steel') {
				if (!this.heal(target.maxhp / 4)) {
					this.add('-immune', target, '[msg]', '[from] ability: Metal Absorb');
				}
				return null;
			}
		},
		id: "metalabsorb",
		name: "Metal Absorb",
		rating: 3,
		num: 11,
	},
	"waterbubble": {
		desc: "This Pokemon's Water-type attacks have their power doubled, the power of Fire-type attacks against this Pokemon is halved, and this Pokemon cannot be burned. Gaining this Ability while burned cures it.",
		shortDesc: "This Pokemon's Water power is 2x; it can't be burned; Fire power against it is halved.",
		onBasePowerPriority: 7,
		onSourceBasePower: function (basePower, attacker, defender, move) {
			if (move.type === 'Fire') {
				return this.chainModify(0.5);
			}
		},
		onBasePower: function (basePower, attacker, defender, move) {
			if (move.type === 'Water') {
				return this.chainModify(2);
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'brn') {
				this.add('-activate', pokemon, 'ability: Water Bubble');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'brn') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Water Bubble');
			return false;
		},
		id: "waterbubble",
		isNonstandard: true,
		name: "Water Bubble",
		rating: 4,
		num: 199,
	},
	"watercompaction": {
		shortDesc: "This Pokemon's Defense is raised 2 stages after it is damaged by a Water-type move.",
		onAfterDamage: function (damage, target, source, effect) {
			if (effect && effect.type === 'Water') {
				this.boost({def:2});
			}
		},
		id: "watercompaction",
		isNonstandard: true,
		name: "Water Compaction",
		rating: 2,
		num: 195,
	},
	"waterveil": {
		shortDesc: "This Pokemon cannot be burned. Gaining this Ability while burned cures it.",
		onUpdate: function (pokemon) {
			if (pokemon.status === 'brn') {
				this.add('-activate', pokemon, 'ability: Water Veil');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'brn') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] ability: Water Veil');
			return false;
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (!target.hasType('Water')) return;
			if (move && move.effectType === 'Move' && type !== 'Water' && !move.flags['exempt'] && typeMod > 0) {
				return 0;
			}
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: Water Veil", "[of] " + target);
		},
		id: "waterveil",
		name: "Water Veil",
		rating: 3.5,
		num: 41,
	},
	"weakarmor": {
		desc: "If a physical attack hits this Pokemon, its Defense is lowered by 1 stage and its Speed is raised by 2 stages.",
		shortDesc: "If a physical attack hits this Pokemon, Defense is lowered by 1, Speed is raised by 2.",
		onAfterDamage: function (damage, target, source, move) {
			if (move.category === 'Physical') {
				this.boost({def:-1, spe:2});
			}
		},
		id: "weakarmor",
		name: "Weak Armor",
		rating: 1,
		num: 133,
	},
	"whitesmoke": {
		shortDesc: "Prevents other Pokemon from lowering this Pokemon's stat stages.",
		onBoost: function (boost, target, source, effect) {
			if (source && target === source) return;
			let showMsg = false;
			for (let i in boost) {
				if ((!target.volatiles['fairytest'] && !target.volatiles['unsetcneigh'] && !target.volatiles['unsetgneigh'] && !target.volatiles['clearbypass']) && boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] ability: White Smoke", "[of] " + target);
		},
		id: "whitesmoke",
		name: "White Smoke",
		rating: 2,
		num: 73,
	},
	"wimpout": {
		shortDesc: "This Pokemon switches out when it reaches 1/2 or less of its maximum HP.",
		onAfterMoveSecondary: function (target, source, move) {
			if (!source || source === target || !target.hp || !move.totalDamage) return;
			if (target.hp <= target.maxhp / 2 && target.hp + move.totalDamage > target.maxhp / 2) {
				if (!this.canSwitch(target.side) || target.forceSwitchFlag || target.switchFlag) return;
				target.switchFlag = true;
				source.switchFlag = false;
				this.add('-activate', target, 'ability: Wimp Out');
			}
		},
		id: "wimpout",
		name: "Wimp Out",
		rating: 2,
		num: 193,
	},
	"wonderguard": {
		shortDesc: "This Pokemon can only be damaged by supereffective moves and indirect damage.",
		onModifyDefPriority: 6,
		onModifyDef: function (def) {
			return this.chainModify(1.1);
		},
		id: "wonderguard",
		name: "Wonder Guard",
		rating: 5,
		num: 25,
	},
	"wonderskin": {
		desc: "All non-damaging moves that check accuracy have their accuracy changed to 50% when used on this Pokemon. This change is done before any other accuracy modifying effects.",
		shortDesc: "Status moves with accuracy checks are 50% accurate when used on this Pokemon.",
		onModifyAccuracyPriority: 10,
		onModifyAccuracy: function (accuracy, target, source, move) {
			if (move.category === 'Status' && typeof move.accuracy === 'number') {
				this.debug('Wonder Skin - setting accuracy to 50');
				return 50;
			}
		},
		id: "wonderskin",
		name: "Wonder Skin",
		rating: 2,
		num: 147,
	},
	"zenmode": {
		desc: "If this Pokemon is a Darmanitan, it changes to Zen Mode if it has 1/2 or less of its maximum HP at the end of a turn. If Darmanitan's HP is above 1/2 of its maximum HP at the end of a turn, it changes back to Standard Mode. If Darmanitan loses this Ability while in Zen Mode it reverts to Standard Mode immediately.",
		shortDesc: "If Darmanitan, at end of turn changes Mode to Standard if > 1/2 max HP, else Zen.",
		onResidualOrder: 27,
		onResidual: function (pokemon) {
			if (pokemon.baseTemplate.baseSpecies !== 'Darmanitan' || pokemon.transformed) {
				return;
			}
			if (pokemon.hp <= pokemon.maxhp / 2 && pokemon.template.speciesid === 'darmanitan') {
				pokemon.addVolatile('zenmode');
			} else if (pokemon.hp > pokemon.maxhp / 2 && pokemon.template.speciesid === 'darmanitanzen') {
				pokemon.addVolatile('zenmode'); // in case of base Darmanitan-Zen
				pokemon.removeVolatile('zenmode');
			}
		},
		onEnd: function (pokemon) {
			if (!pokemon.volatiles['zenmode'] || !pokemon.hp) return;
			pokemon.transformed = false;
			delete pokemon.volatiles['zenmode'];
			if (pokemon.formeChange('Darmanitan')) {
				this.add('-formechange', pokemon, 'Darmanitan', '[silent]');
			}
		},
		effect: {
			onStart: function (pokemon) {
				if (pokemon.template.speciesid === 'darmanitanzen' || !pokemon.formeChange('Darmanitan-Zen')) return;
				this.add('-formechange', pokemon, 'Darmanitan-Zen', '[from] ability: Zen Mode');
				pokemon.addVolatile('formecheck');
			},
			onEnd: function (pokemon) {
				if (!pokemon.formeChange('Darmanitan')) return;
				this.add('-formechange', pokemon, 'Darmanitan', '[from] ability: Zen Mode');
				pokemon.addVolatile('formecheck');
			},
		},
		id: "zenmode",
		name: "Zen Mode",
		rating: -1,
		num: 161,
	},

	// CAP
	"mountaineer": {
		shortDesc: "On switch-in, this Pokemon avoids all Rock-type attacks and Stealth Rock.",
		onDamage: function (damage, target, source, effect) {
			if (effect && effect.id === 'stealthrock') {
				return false;
			}
		},
		onTryHit: function (target, source, move) {
			if (move.type === 'Rock' && !target.activeTurns) {
				this.add('-immune', target, '[msg]', '[from] ability: Mountaineer');
				return null;
			}
		},
		id: "mountaineer",
		isNonstandard: true,
		name: "Mountaineer",
		rating: 3.5,
		num: -2,
	},
	"rebound": {
		desc: "On switch-in, this Pokemon blocks certain status moves and instead uses the move against the original user.",
		shortDesc: "On switch-in, blocks certain status moves and bounces them back to the user.",
		id: "rebound",
		isNonstandard: true,
		name: "Rebound",
		onTryHitPriority: 1,
		onTryHit: function (target, source, move) {
			if (this.effectData.target.activeTurns) return;

			if (target === source || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, target, source);
			return null;
		},
		onAllyTryHitSide: function (target, source, move) {
			if (this.effectData.target.activeTurns) return;

			if (target.side === source.side || move.hasBounced || !move.flags['reflectable']) {
				return;
			}
			let newMove = this.getMoveCopy(move.id);
			newMove.hasBounced = true;
			this.useMove(newMove, this.effectData.target, source);
			return null;
		},
		effect: {
			duration: 1,
		},
		rating: 3.5,
		num: -3,
	},
	"persistent": {
		shortDesc: "The duration of certain field effects is increased by 2 turns if used by this Pokemon.",
		id: "persistent",
		isNonstandard: true,
		name: "Persistent",
		// implemented in the corresponding move
		rating: 3.5,
		num: -4,
	},
};
