'use strict';

exports.BattleItems = {
	"enigmaplate": {
		id: "enigmaplate",
		name: "Enigma Plate",
		spritenum: 610,
		onPlate: '???',
		onStart: function (pokemon) {
			let item = pokemon.getItem();
			if (!item.isMemory && pokemon.baseTemplate.num === 493) {
				if (!pokemon.setType('???')) return;
				this.add('-start', pokemon, 'typechange', '???', '[from] Enigma Plate');
				this.add('-ability', pokemon, 'Multitype', '[from] Enigma Plate');
				pokemon.setAbility('Multitype');
				this.add('-message', "The Enigma Plate transformed " + pokemon.name + " into a ???-Type!");
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === '???') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Normal",
		num: -6,
		gen: 6,
		isNonstandard: true,
		desc: "Holder's ???-type attacks have 1.2x power. Judgment is ??? type.",
	},
	"bugmemory": {
		id: "bugmemory",
		name: "Bug Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Bug',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Bug')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('exterminator')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Bug' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Bug') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"darkmemory": {
		id: "darkmemory",
		name: "Dark Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Dark',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Dark')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('darkaura')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Dark' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Dark') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"dragonmemory": {
		id: "dragonmemory",
		name: "Dragon Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Dragon',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Dragon')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('regenerator')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Dragon' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Dragon') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"electricmemory": {
		id: "electricmemory",
		name: "Electric Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Electric',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Electric')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('infinitevoltage')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onModifyDamage: function (damage, source, target, move) {
			return this.chainModify([0x1000, 0x1000]);
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Electric' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Electric') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"fairymemory": {
		id: "fairymemory",
		name: "Fairy Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Fairy',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Fairy')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('fairyaura')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fairy' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Fairy') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"fightingmemory": {
		id: "fightingmemory",
		name: "Fighting Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Fighting',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Fighting')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('perfectform')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fighting' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Fighting') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"firememory": {
		id: "firememory",
		name: "Fire Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Fire',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Fire')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('sheerforce')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fire' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Fire') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"flyingmemory": {
		id: "flyingmemory",
		name: "Flying Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Flying',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Flying')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('etherealsky')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Flying' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Flying') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"ghostmemory": {
		id: "ghostmemory",
		name: "Ghost Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Ghost',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Ghost')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('spectralforce')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Ghost' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Ghost') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"grassmemory": {
		id: "grassmemory",
		name: "Grass Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Grass',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Grass')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('lifeforce')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Grass' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Grass') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"groundmemory": {
		id: "groundmemory",
		name: "Ground Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Ground',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Ground')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('endlessearth')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Ground' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Ground') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"icememory": {
		id: "icememory",
		name: "Ice Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Ice',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Ice')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('frostshield')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Ice' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Ice') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"upgrade": {
		id: "upgrade",
		name: "Up-Grade",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Normal',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Normal')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('nobleguard')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Normal' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Normal') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"poisonmemory": {
		id: "poisonmemory",
		name: "Poison Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Poison',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Poison')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('doubledown')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Poison' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Poison') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"psychicmemory": {
		id: "psychicmemory",
		name: "Psychic Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Psychic',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Psychic')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('strategist')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Psychic' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Psychic') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"rockmemory": {
		id: "rockmemory",
		name: "Rock Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Rock',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Rock')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('diamondarmor')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Rock' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Rock') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"steelmemory": {
		id: "steelmemory",
		name: "Steel Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Steel',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Steel')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('compactarmor')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Steel' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Steel') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"watermemory": {
		id: "watermemory",
		name: "Water Memory",
		spritenum: 0,
		isMemory: true,
		onMemory: 'Water',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('Water')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('eternalstream')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Water' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('Water') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},
	"dubiousdisc": {
		id: "dubiousdisc",
		name: "Dubious Disc",
		spritenum: 0,
		isMemory: true,
		onMemory: '???',
		onSwitchIn: function (pokemon) {
			pokemon.getTypes();
			if (pokemon.hasType('???')) pokemon.addVolatile('memoryboost');
			pokemon.addVolatile('pokestabcheck');
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('activechange');
			pokemon.addVolatile('memorycheck');
			if (!pokemon.hasAbility('oversight')) {
				pokemon.addVolatile('abilitycheck');
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === '???' && !user.volatiles['memoryboost']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 1,
		onResidual: function (pokemon) {
			if (pokemon.activeTurns && (!pokemon.hasType('???') || pokemon.volatiles['formecheck'])) {
				pokemon.addVolatile('memorycheck');
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 684,
		gen: 2,
		desc: "If holder is a Porygon, its Attack and Sp. Atk are increased.",
	},

	// Assist Drives

	"assistdrive": {
		id: "assistdrive",
		name: "Assist Drive",
		spritenum: 0,
		isAssist: true,
		onAssist: '???',
		noRecycle: true,
		onModifySpePriority: 5,
		onModifySpe: function (spe, pokemon) {
			if (pokemon.template.baseStats.spe <= 100) {
				return this.chainModify(10000);
			} else {
				return 100;
			}
		},
		onModifyPriority: function (priority, pokemon) {
			if (pokemon.template.baseStats.spe <= 100) {
				return priority - 10;
			}
		},
		onSwitchIn: function (pokemon) {
			if (!this.canSwitch(pokemon.side)) return;
			pokemon.getTypes();
			pokemon.addVolatile('assistcheck');
			pokemon.addVolatile('assistarbitration');
			pokemon.addVolatile('assistend');
			pokemon.switchFlag = true;
			if (pokemon.template.species === 'Calyrex-Shadow' || pokemon.template.species === 'Cresselia' || pokemon.template.species === 'Darkrai' || pokemon.template.species === 'Eternatus' || pokemon.template.species === 'Groudon' || pokemon.template.species === 'Ho-Oh' || pokemon.template.species === 'Kyogre' || pokemon.template.species === 'Lugia' || pokemon.template.species === 'Meloetta' || pokemon.template.species === 'Meowscarada' || pokemon.template.species === 'Mew' || pokemon.template.species === 'Rayquaza' || pokemon.template.species === 'Shaymin' || pokemon.template.species === 'Xerneas' || pokemon.template.species === 'Yveltal') {
				pokemon.addVolatile('disablebonuses');
			}
		},
		onUpdate: function (pokemon) {
			if (!this.canSwitch(pokemon.side) || pokemon.volatiles['confirmfaint']) return;
			if (pokemon.useItem()) {
				pokemon.addVolatile('confirmfaint');
			}
		},
		onBoost: function (boost, target, source, effect) {
			let showMsg = false;
			for (let i in boost) {
				if (boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[of] " + target);
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 100,
		gen: 2,
		desc: ".",
	},

	// Battle Items

	"abilityshield": {
		id: "abilityshield",
		name: "Ability Shield",
		spritenum: 249,
		fling: {
			basePower: 30,
		},
		onUpdate: function (pokemon) {
			let ability = pokemon.getAbility();
			if (ability.isBreaker && pokemon.item === 'abilityshield' && !pokemon.volatiles['ashieldboost']) pokemon.addVolatile('ashieldboost');
		},
		onModifyMove: function (move, pokemon, target) {
			let condition = target.getAbility();
			if ((move.category === 'Physical' || move.category === 'Special') && !condition.isLocker) {
				move.ignoreAbility = true;
			}
		},
		onAfterMoveSecondarySelf: function (source, target, move) {
			let ability = source.getAbility();
			let condition = target.getAbility();
			if (source.volatiles['thiswillstopthecodefromactivatingbutpreserveitshoulditbeneeded'] && (source && source !== target && move && (move.category === 'Physical' || move.category === 'Special')) && (!ability.isBreaker && !ability.isMewtwo) && !condition.isLocker) {
				this.damage(source.maxhp / 10, source, source, this.getItem('abilityshield'));
			}
		},
		num: 270,
		gen: 4,
		desc: "Holder's attacks do 1.3x damage, and it loses 1/10 its max HP after the attack.",
	},
	"abomasite": {
		id: "abomasite",
		name: "Abomasite",
		spritenum: 575,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Abomasnow') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Abomasnow-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Abomasnow') return false;
			return true;
		},
		num: 674,
		gen: 6,
		desc: "If holder is an Abomasnow, this item allows it to Mega Evolve in battle.",
	},
	"absolite": {
		id: "absolite",
		name: "Absolite",
		spritenum: 576,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Absol') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Absol-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Absol') return false;
			return true;
		},
		num: 677,
		gen: 6,
		desc: "If holder is an Absol, this item allows it to Mega Evolve in battle.",
	},
	"absorbbulb": {
		id: "absorbbulb",
		name: "Absorb Bulb",
		spritenum: 2,
		fling: {
			basePower: 30,
		},
		onAfterDamage: function (damage, target, source, move) {
			if (move.type === 'Water' && target.useItem()) {
				this.boost({spa: 1});
			}
		},
		num: 545,
		gen: 5,
		desc: "Raises holder's Sp. Atk by 1 stage if hit by a Water-type attack. Single use.",
	},
	"adamantorb": {
		id: "adamantorb",
		name: "Adamant Orb",
		spritenum: 4,
		fling: {
			basePower: 60,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && user.baseTemplate.species === 'Dialga' && (move.type === 'Steel' || move.type === 'Dragon')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 483) || pokemon.baseTemplate.num === 483) {
				return false;
			}
			return true;
		},
		num: 135,
		gen: 4,
		desc: "If holder is a Dialga, its Steel- and Dragon-type attacks have 1.2x power.",
	},
	"aerodactylite": {
		id: "aerodactylite",
		name: "Aerodactylite",
		spritenum: 577,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Aerodactyl') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Aerodactyl-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Aerodactyl') return false;
			return true;
		},
		num: 672,
		gen: 6,
		desc: "If holder is an Aerodactyl, this item allows it to Mega Evolve in battle.",
	},
	"aggronite": {
		id: "aggronite",
		name: "Aggronite",
		spritenum: 578,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Aggron') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Aggron-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Aggron') return false;
			return true;
		},
		num: 667,
		gen: 6,
		desc: "If holder is an Aggron, this item allows it to Mega Evolve in battle.",
	},
	"aguavberry": {
		id: "aguavberry",
		name: "Aguav Berry",
		spritenum: 5,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Dragon",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(pokemon.maxhp / 3);
			if (pokemon.getNature().minus === 'spd') {
				pokemon.addVolatile('confusion');
			}
		},
		num: 162,
		gen: 3,
		desc: "Restores 1/8 max HP when at 1/2 max HP or less. May confuse. Single use.",
	},
	"airballoon": {
		id: "airballoon",
		name: "Air Balloon",
		spritenum: 6,
		fling: {
			basePower: 10,
		},
		onStart: function (target) {
			if (!target.ignoringItem() && !this.getPseudoWeather('gravity')) {
				this.add('-item', target, 'Air Balloon');
			}
		},
		onImmunity: function (type) {
			if (type === 'Ground') return false;
		},
		onAfterDamage: function (damage, target, source, effect) {
			this.debug('effect: ' + effect.id);
			if (effect.effectType === 'Move' && effect.id !== 'confused') {
				this.add('-enditem', target, 'Air Balloon');
				target.item = '';
				this.itemData = {id: '', target: this};
				this.runEvent('AfterUseItem', target, null, null, 'airballoon');
			}
		},
		onAfterSubDamage: function (damage, target, source, effect) {
			this.debug('effect: ' + effect.id);
			if (effect.effectType === 'Move' && effect.id !== 'confused') {
				this.add('-enditem', target, 'Air Balloon');
				target.setItem('');
			}
		},
		num: 541,
		gen: 5,
		desc: "Holder is immune to Ground-type attacks. Pops when holder is hit.",
	},
	"alakazite": {
		id: "alakazite",
		name: "Alakazite",
		spritenum: 579,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Alakazam') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Alakazam-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Alakazam') return false;
			return true;
		},
		num: -6,
		gen: 6,
		desc: "If holder is an Alakazam, this item allows it to Mega Evolve in battle.",
	},
	"altarianite": {
		id: "altarianite",
		name: "Altarianite",
		spritenum: 615,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Altaria') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Altaria-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Altaria') return false;
			return true;
		},
		num: 755,
		gen: 6,
		desc: "If holder is an Altaria, this item allows it to Mega Evolve in battle.",
	},
	"ampharosite": {
		id: "ampharosite",
		name: "Ampharosite",
		spritenum: 580,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Ampharos') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Ampharos-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Ampharos') return false;
			return true;
		},
		num: -6,
		gen: 6,
		desc: "If holder is an Ampharos, this item allows it to Mega Evolve in battle.",
	},
	"apicotberry": {
		id: "apicotberry",
		name: "Apicot Berry",
		spritenum: 10,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Ground",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || (pokemon.hp <= pokemon.maxhp / 2 && pokemon.hasAbility('gluttony'))) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			this.boost({spd:1});
		},
		num: 205,
		gen: 3,
		desc: "Raises holder's Sp. Def by 1 stage when at 1/4 max HP or less. Single use.",
	},
	"armorfossil": {
		id: "armorfossil",
		name: "Armor Fossil",
		spritenum: 12,
		fling: {
			basePower: 100,
		},
		num: 104,
		gen: 4,
		desc: "Can be revived into Shieldon.",
	},
	"aspearberry": {
		id: "aspearberry",
		name: "Aspear Berry",
		spritenum: 13,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Ice",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'frz') {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			if (pokemon.status === 'frz') {
				pokemon.cureStatus();
			}
		},
		num: 153,
		gen: 3,
		desc: "Holder is cured if it is frozen. Single use.",
	},
	"assaultvest": {
		id: "assaultvest",
		name: "Assault Vest",
		spritenum: 581,
		fling: {
			basePower: 80,
		},
		onModifySpDPriority: 1,
		onModifySpD: function (spd) {
			return this.chainModify(1.5);
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).category === 'Status') {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		num: -6,
		gen: 6,
		desc: "Holder's Sp. Def is 1.5x, but it can only select damaging moves.",
	},
	"audinite": {
		id: "audinite",
		name: "Audinite",
		spritenum: 617,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Audino') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Audino-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Audino') return false;
			return true;
		},
		num: 757,
		gen: 6,
		desc: "If holder is an Audino, this item allows it to Mega Evolve in battle.",
	},
	"babiriberry": {
		id: "babiriberry",
		name: "Babiri Berry",
		spritenum: 17,
		isBerry: true,
		onBuffer: 'Steel',
		naturalGift: {
			basePower: 80,
			type: "Steel",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Steel' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 199,
		gen: 4,
		desc: "Halves damage taken from a supereffective Steel-type attack. Single use.",
	},
	"banettite": {
		id: "banettite",
		name: "Banettite",
		spritenum: 582,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Banette') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Banette-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Banette') return false;
			return true;
		},
		num: 668,
		gen: 6,
		desc: "If holder is a Banette, this item allows it to Mega Evolve in battle.",
	},
	"beastball": {
		id: "beastball",
		name: "Beast Ball",
		spritenum: 106,
		fling: {
			basePower: 70,
		},
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Eternatus') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Eternatus-Eternamax');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Eternatus') return false;
			return true;
		},
		num: 250,
		gen: 2,
		desc: "Holder's Dragon-type attacks have 1.2x power.",
	},
	"beedrillite": {
		id: "beedrillite",
		name: "Beedrillite",
		spritenum: 628,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Beedrill') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Beedrill-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Beedrill') return false;
			return true;
		},
		num: 770,
		gen: 6,
		desc: "If holder is a Beedrill, this item allows it to Mega Evolve in battle.",
	},
	"belueberry": {
		id: "belueberry",
		name: "Belue Berry",
		spritenum: 21,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Electric",
		},
		num: 183,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"berryjuice": {
		id: "berryjuice",
		name: "Berry Juice",
		spritenum: 22,
		fling: {
			basePower: 30,
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (this.isWeather(['hail']) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(75);
			} else if (!this.isWeather(['hail']) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(30);
			}
		},
		num: 43,
		gen: 2,
		desc: "Restores 20 HP when at 1/2 max HP or less. Single use.",
	},
	"bigroot": {
		id: "bigroot",
		name: "Big Root",
		spritenum: 29,
		fling: {
			basePower: 10,
		},
		onTryHealPriority: 1,
		onTryHeal: function (damage, target, source, effect) {
			let heals = {drain: 1, leechseed: 1, ingrain: 1, aquaring: 1};
			if (heals[effect.id]) {
				return Math.ceil((damage * 1.3) - 0.5); // Big Root rounds half down
			}
		},
		num: 296,
		gen: 4,
		desc: "Holder gains 1.3x HP from draining moves, Aqua Ring, Ingrain, and Leech Seed.",
	},
	"bindingband": {
		id: "bindingband",
		name: "Binding Band",
		spritenum: 31,
		fling: {
			basePower: 30,
		},
		// implemented in statuses
		num: 544,
		gen: 5,
		desc: "Holder's partial-trapping moves deal 1/6 max HP per turn instead of 1/8.",
	},
	"blackbelt": {
		id: "blackbelt",
		name: "Black Belt",
		spritenum: 32,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fighting') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 241,
		gen: 2,
		desc: "Holder's Fighting-type attacks have 1.2x power.",
	},
	"blacksludge": {
		id: "blacksludge",
		name: "Black Sludge",
		spritenum: 34,
		fling: {
			basePower: 30,
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.hasType('Poison') && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 7);
			} else if (!pokemon.hasType('Poison')) {
				this.damage(pokemon.maxhp / 8);
			}
		},
		num: 281,
		gen: 4,
		desc: "Each turn, if holder is a Poison type, restores 1/16 max HP; loses 1/8 if not.",
	},
	"blackglasses": {
		id: "blackglasses",
		name: "Black Glasses",
		spritenum: 35,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Dark') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 240,
		gen: 2,
		desc: "Holder's Dark-type attacks have 1.2x power.",
	},
	"blastoisinite": {
		id: "blastoisinite",
		name: "Blastoisinite",
		spritenum: 583,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Blastoise') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Blastoise-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Blastoise') return false;
			return true;
		},
		num: -6,
		gen: 6,
		desc: "If holder is a Blastoise, this item allows it to Mega Evolve in battle.",
	},
	"blazikenite": {
		id: "blazikenite",
		name: "Blazikenite",
		spritenum: 584,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Blaziken') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Blaziken-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Blaziken') return false;
			return true;
		},
		num: 664,
		gen: 6,
		desc: "If holder is a Blaziken, this item allows it to Mega Evolve in battle.",
	},
	"blueorb": {
		id: "blueorb",
		name: "Blue Orb",
		spritenum: 41,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Kyogre') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Kyogre-Primal');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-primal', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Kyogre') return false;
			return true;
		},
		num: -6,
		gen: 6,
		desc: "If holder is a Kyogre, this item triggers its Primal Reversion in battle.",
	},
	"blukberry": {
		id: "blukberry",
		name: "Bluk Berry",
		spritenum: 44,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Fire",
		},
		num: 165,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"brightpowder": {
		id: "brightpowder",
		name: "Bright Powder",
		spritenum: 51,
		fling: {
			basePower: 10,
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if ((pokemon.hasType('Fairy') || pokemon.hasType('Dark')) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 10);
			}
		},
		num: 213,
		gen: 2,
		desc: "The accuracy of attacks against the holder is 0.9x.",
	},
	"buggem": {
		id: "buggem",
		name: "Bug Gem",
		spritenum: 53,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Bug') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Bug Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 558,
		gen: 5,
		desc: "Holder's first successful Bug-type attack will have 1.3x power. Single use.",
	},
	"burndrive": {
		id: "burndrive",
		name: "Burn Drive",
		spritenum: 54,
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 649) || pokemon.baseTemplate.num === 649) {
				return false;
			}
			return true;
		},
		onDrive: 'Fire',
		forcedForme: "Genesect-Burn",
		num: 118,
		gen: 5,
		desc: "Holder's Techno Blast is Fire type.",
	},
	"cameruptite": {
		id: "cameruptite",
		name: "Cameruptite",
		spritenum: 625,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Camerupt') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Camerupt-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Camerupt') return false;
			return true;
		},
		num: 767,
		gen: 6,
		desc: "If holder is a Camerupt, this item allows it to Mega Evolve in battle.",
	},
	"cellbattery": {
		id: "cellbattery",
		name: "Cell Battery",
		noRecycle: true,
		spritenum: 60,
		fling: {
			basePower: 30,
		},
		onAfterDamage: function (damage, target, source, move) {
			if (move.type === 'Electric' && target.useItem()) {
				this.boost({atk: 1});
			}
		},
		num: 546,
		gen: 5,
		desc: "Raises holder's Attack by 1 if hit by an Electric-type attack. Single use.",
	},
	"charcoal": {
		id: "charcoal",
		name: "Charcoal",
		spritenum: 61,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fire') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 249,
		gen: 2,
		desc: "Holder's Fire-type attacks have 1.2x power.",
	},
	"charizarditex": {
		id: "charizarditex",
		name: "Charizardite X",
		spritenum: 585,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Charizard') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Charizard-Mega-X');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Charizard') return false;
			return true;
		},
		num: 660,
		gen: 6,
		desc: "If holder is a Charizard, this item allows it to Mega Evolve in battle.",
	},
	"charizarditey": {
		id: "charizarditey",
		name: "Charizardite Y",
		spritenum: 586,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Charizard') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Charizard-Mega-Y');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Charizard') return false;
			return true;
		},
		num: 678,
		gen: 6,
		desc: "If holder is a Charizard, this item allows it to Mega Evolve in battle.",
	},
	"chartiberry": {
		id: "chartiberry",
		name: "Charti Berry",
		spritenum: 62,
		isBerry: true,
		onBuffer: 'Rock',
		naturalGift: {
			basePower: 80,
			type: "Rock",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Rock' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 195,
		gen: 4,
		desc: "Halves damage taken from a supereffective Rock-type attack. Single use.",
	},
	"cheriberry": {
		id: "cheriberry",
		name: "Cheri Berry",
		spritenum: 63,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Fire",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			if (pokemon.status === 'par') {
				pokemon.cureStatus();
			}
		},
		num: 149,
		gen: 3,
		desc: "Holder cures itself if it is paralyzed. Single use.",
	},
	"cherishball": {
		id: "cherishball",
		name: "Cherish Ball",
		spritenum: 64,
		num: 16,
		gen: 4,
		desc: "A rare Poke Ball that has been crafted to commemorate an occasion.",
	},
	"chestoberry": {
		id: "chestoberry",
		name: "Chesto Berry",
		spritenum: 65,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Water",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'slp') {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			if (pokemon.status === 'slp') {
				pokemon.cureStatus();
			}
		},
		num: 150,
		gen: 3,
		desc: "Holder wakes up if it is asleep. Single use.",
	},
	"chilanberry": {
		id: "chilanberry",
		name: "Chilan Berry",
		spritenum: 66,
		isBerry: true,
		onBuffer: 'Normal',
		naturalGift: {
			basePower: 80,
			type: "Normal",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Normal' && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 200,
		gen: 4,
		desc: "Halves damage taken from a Normal-type attack. Single use.",
	},
	"chilldrive": {
		id: "chilldrive",
		name: "Chill Drive",
		spritenum: 67,
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 649) || pokemon.baseTemplate.num === 649) {
				return false;
			}
			return true;
		},
		onDrive: 'Ice',
		forcedForme: "Genesect-Chill",
		num: 119,
		gen: 5,
		desc: "Holder's Techno Blast is Ice type.",
	},
	"choiceband": {
		id: "choiceband",
		name: "Choice Band",
		spritenum: 68,
		fling: {
			basePower: 10,
		},
		onSwitchIn: function (pokemon) {
			this.add('-message', "" + pokemon.name + " is holding a powerful item!");
		},
		onStart: function (pokemon) {
			if (pokemon.volatiles['choicelock']) {
				this.debug('removing choicelock: ' + pokemon.volatiles.choicelock);
			}
			pokemon.removeVolatile('choicelock');
		},
		onModifyMove: function (move, pokemon) {
			pokemon.addVolatile('choicelock');
		},
		onModifyAtkPriority: 1,
		onModifyAtk: function (atk) {
			return this.chainModify(1.5);
		},
		onUpdate: function (pokemon) {
			if (pokemon.hasAbility(['beastboost', 'bulldozer', 'download', 'hugepower', 'illusion', 'libero', 'parlortrick', 'purepower', 'protean'])) {
				pokemon.eatItem();
			}
		},
		isChoice: true,
		num: 220,
		gen: 3,
		desc: "Holder's Attack is 1.3x, but it can only select the first move it executes.",
	},
	"choicescarf": {
		id: "choicescarf",
		name: "Choice Scarf",
		spritenum: 69,
		fling: {
			basePower: 10,
		},
		onSwitchIn: function (pokemon) {
			this.add('-message', "" + pokemon.name + " is holding a powerful item!");
		},
		onStart: function (pokemon) {
			if (pokemon.volatiles['choicelock']) {
				this.debug('removing choicelock: ' + pokemon.volatiles.choicelock);
			}
			pokemon.removeVolatile('choicelock');
		},
		onModifyMove: function (move, pokemon) {
			pokemon.addVolatile('choicelock');
		},
		onModifySpe: function (pokemon, spe) {
			return this.chainModify(1.5);
		},
		onUpdate: function (pokemon) {
			if (pokemon.hasAbility(['beastboost', 'bulldozer', 'download', 'dualwielder', 'hugepower', 'illusion', 'libero', 'parlortrick', 'purepower', 'protean'])) {
				pokemon.eatItem();
			}
		},
		isChoice: true,
		num: 287,
		gen: 4,
		desc: "Holder's Speed is 1.5x, but it can only select the first move it executes.",
	},
	"choicespecs": {
		id: "choicespecs",
		name: "Choice Specs",
		spritenum: 70,
		fling: {
			basePower: 10,
		},
		onSwitchIn: function (pokemon) {
			this.add('-message', "" + pokemon.name + " is holding a powerful item!");
		},
		onStart: function (pokemon) {
			if (pokemon.volatiles['choicelock']) {
				this.debug('removing choicelock: ' + pokemon.volatiles.choicelock);
			}
			pokemon.removeVolatile('choicelock');
		},
		onModifyMove: function (move, pokemon) {
			pokemon.addVolatile('choicelock');
		},
		onModifySpAPriority: 1,
		onModifySpA: function (spa) {
			return this.chainModify(1.5);
		},
		onUpdate: function (pokemon) {
			if (pokemon.hasAbility(['beastboost', 'bulldozer', 'download', 'dualwielder', 'hugepower', 'illusion', 'libero', 'parlortrick', 'purepower', 'protean'])) {
				pokemon.eatItem();
			}
		},
		isChoice: true,
		num: 297,
		gen: 4,
		desc: "Holder's Sp. Atk is 1.5x, but it can only select the first move it executes.",
	},
	"chopleberry": {
		id: "chopleberry",
		name: "Chople Berry",
		spritenum: 71,
		isBerry: true,
		onBuffer: 'Fighting',
		naturalGift: {
			basePower: 80,
			type: "Fighting",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Fighting' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 189,
		gen: 4,
		desc: "Halves damage taken from a supereffective Fighting-type attack. Single use.",
	},
	"clawfossil": {
		id: "clawfossil",
		name: "Claw Fossil",
		spritenum: 72,
		fling: {
			basePower: 100,
		},
		num: 100,
		gen: 3,
		desc: "Can be revived into Anorith.",
	},
	"cobaberry": {
		id: "cobaberry",
		name: "Coba Berry",
		spritenum: 76,
		isBerry: true,
		onBuffer: 'Flying',
		naturalGift: {
			basePower: 80,
			type: "Flying",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Flying' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 192,
		gen: 4,
		desc: "Halves damage taken from a supereffective Flying-type attack. Single use.",
	},
	"colburberry": {
		id: "colburberry",
		name: "Colbur Berry",
		spritenum: 78,
		isBerry: true,
		onBuffer: 'Dark',
		naturalGift: {
			basePower: 80,
			type: "Dark",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Dark' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 198,
		gen: 4,
		desc: "Halves damage taken from a supereffective Dark-type attack. Single use.",
	},
	"cornnberry": {
		id: "cornnberry",
		name: "Cornn Berry",
		spritenum: 81,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Bug",
		},
		num: 175,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"coverfossil": {
		id: "coverfossil",
		name: "Cover Fossil",
		spritenum: 85,
		fling: {
			basePower: 100,
		},
		num: 572,
		gen: 5,
		desc: "Can be revived into Tirtouga.",
	},
	"custapberry": {
		id: "custapberry",
		name: "Custap Berry",
		spritenum: 86,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Ghost",
		},
		onModifyPriority: function (priority, pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || (pokemon.hp <= pokemon.maxhp / 2 && pokemon.hasAbility('gluttony'))) {
				if (pokemon.eatItem()) {
					this.add('-activate', pokemon, 'Custap Berry');
					pokemon.removeVolatile('custapberry');
					return priority + 0.1;
				}
			}
		},
		num: 210,
		gen: 4,
		desc: "Holder moves first in its priority bracket when at 1/4 max HP or less. Single use.",
	},
	"damprock": {
		id: "damprock",
		name: "Damp Rock",
		spritenum: 88,
		fling: {
			basePower: 60,
		},
		num: 285,
		gen: 4,
		desc: "Holder's use of Rain Dance lasts 8 turns instead of 5.",
	},
	"darkgem": {
		id: "darkgem",
		name: "Dark Gem",
		spritenum: 89,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Dark') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Dark Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 562,
		gen: 5,
		desc: "Holder's first successful Dark-type attack will have 1.3x power. Single use.",
	},
	"deepseascale": {
		id: "deepseascale",
		name: "DeepSeaScale",
		spritenum: 93,
		fling: {
			basePower: 30,
		},
		onModifySpDPriority: 2,
		onModifySpD: function (spd, pokemon) {
			if (pokemon.baseTemplate.species === 'Clamperl') {
				return this.chainModify(2);
			}
		},
		num: 227,
		gen: 3,
		desc: "If holder is a Clamperl, its Sp. Def is doubled.",
	},
	"deepseatooth": {
		id: "deepseatooth",
		name: "DeepSeaTooth",
		spritenum: 94,
		fling: {
			basePower: 90,
		},
		onModifySpAPriority: 1,
		onModifySpA: function (spa, pokemon) {
			if (pokemon.baseTemplate.species === 'Clamperl') {
				return this.chainModify(2);
			}
		},
		num: 226,
		gen: 3,
		desc: "If holder is a Clamperl, its Sp. Atk is doubled.",
	},
	"destinyknot": {
		id: "destinyknot",
		name: "Destiny Knot",
		spritenum: 95,
		fling: {
			basePower: 10,
		},
		onAttractPriority: -100,
		onAttract: function (target, source) {
			this.debug('attract intercepted: ' + target + ' from ' + source);
			if (!source || source === target) return;
			if (!source.volatiles.attract) source.addVolatile('attract', target);
		},
		num: 280,
		gen: 4,
		desc: "If holder becomes infatuated, the other Pokemon also becomes infatuated.",
	},
	"diancite": {
		id: "diancite",
		name: "Diancite",
		spritenum: 624,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Diancie') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Diancie-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Diancie') return false;
			return true;
		},
		num: 764,
		gen: 6,
		desc: "If holder is a Diancie, this item allows it to Mega Evolve in battle.",
	},
	"diveball": {
		id: "diveball",
		name: "Dive Ball",
		spritenum: 101,
		num: 7,
		gen: 3,
		desc: "A Poke Ball that works especially well on Pokemon that live underwater.",
	},
	"domefossil": {
		id: "domefossil",
		name: "Dome Fossil",
		spritenum: 102,
		fling: {
			basePower: 100,
		},
		num: 102,
		gen: 3,
		desc: "Can be revived into Kabuto.",
	},
	"dousedrive": {
		id: "dousedrive",
		name: "Douse Drive",
		spritenum: 103,
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 649) || pokemon.baseTemplate.num === 649) {
				return false;
			}
			return true;
		},
		onDrive: 'Water',
		forcedForme: "Genesect-Douse",
		num: 116,
		gen: 5,
		desc: "Holder's Techno Blast is Water type.",
	},
	"dracoplate": {
		id: "dracoplate",
		name: "Draco Plate",
		spritenum: 105,
		onPlate: 'Dragon',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Dragon') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Dragon",
		num: 311,
		gen: 4,
		desc: "Holder's Dragon-type attacks have 1.2x power. Judgment is Dragon type.",
	},
	"dragonfang": {
		id: "dragonfang",
		name: "Dragon Fang",
		spritenum: 106,
		fling: {
			basePower: 70,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Dragon') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Rayquaza') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Rayquaza-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Rayquaza') return false;
			return true;
		},
		num: 250,
		gen: 2,
		desc: "Holder's Dragon-type attacks have 1.2x power.",
	},
	"dragongem": {
		id: "dragongem",
		name: "Dragon Gem",
		spritenum: 107,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Dragon') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Dragon Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 561,
		gen: 5,
		desc: "Holder's first successful Dragon-type attack will have 1.3x power. Single use.",
	},
	"dreadplate": {
		id: "dreadplate",
		name: "Dread Plate",
		spritenum: 110,
		onPlate: 'Dark',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Dark') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Dark",
		num: 312,
		gen: 4,
		desc: "Holder's Dark-type attacks have 1.2x power. Judgment is Dark type.",
	},
	"dreamball": {
		id: "dreamball",
		name: "Dream Ball",
		spritenum: 111,
		num: 576,
		gen: 5,
		desc: "A special Poke Ball that appears out of nowhere in a bag at the Entree Forest.",
	},
	"durinberry": {
		id: "durinberry",
		name: "Durin Berry",
		spritenum: 114,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Water",
		},
		num: 182,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"poweranklet": {
		id: "poweranklet",
		name: "Power Anklet",
		spritenum: 249,
		onModifyDamage: function (damage, source, target, move) {
			return this.chainModify([0x119A, 0x1000]);
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"powerband": {
		id: "powerband",
		name: "Power Band",
		spritenum: 249,
		onModifyDamage: function (damage, source, target, move, effect) {
			if (this.random(3) === 0) {
				return this.chainModify([0x2000, 0x1000]);
			}
		},
		num: 685,
		gen: 4,
		desc: "40% Chance for doubled power on attacks.",
	},
	"powerbelt": {
		id: "powerbelt",
		name: "Power Belt",
		spritenum: 249,
		onModifyDef: function (def) {
			return this.chainModify(1.1);
		},
		onModifySpD: function (spd) {
			return this.chainModify(1.1);
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"powerbracer": {
		id: "powerbracer",
		name: "Power Bracer",
		spritenum: 249,
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.category !== 'Status' && !target.volatiles['substitute']) {
				if (target.useItem()) {
					this.debug('-20% reduction');
					return this.chainModify(0.8);
				}
			}
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"powerlens": {
		id: "powerlens",
		name: "Power Lens",
		spritenum: 249,
		onSourceModifyAccuracy: function (accuracy) {
			if (typeof accuracy === 'number') {
				return accuracy * 100;
			}
		},
		onAfterMoveSecondarySelf: function (source, target, move) {
			if (source && source !== target && move) {
				this.damage(source.maxhp / 20, source, source, this.getItem('powerlens'));
			}
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"powerweight": {
		id: "powerweight",
		name: "Power Weight",
		spritenum: 249,
		onModifySpe: function (spe) {
			return this.chainModify(0.5);
		},
		onModifyAtk: function (atk) {
			return this.chainModify(1.3);
		},
		num: 685,
		gen: 4,
		desc: "Lowers speed by x0.67, Multiplies Attack by x1.5",
	},
	"protector": {
		id: "protector",
		name: "Protector",
		spritenum: 249,
		onSourceModifyDamage: function (damage, source, target, move) {
			if (source.item !== 'protectivepads' && move && move.category !== 'Status' && move.flags['contact'] && !target.volatiles['substitute']) {
				if (target.useItem()) {
					this.debug('protector reduction');
					return 0;
				}
			} else if (source.item !== 'protectivepads' && move && move.category !== 'Status' && move.flags['touch'] && !target.volatiles['substitute']) {
				if (target.useItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		num: 685,
		gen: 4,
		desc: "Reduces damage taken from Contact-Moves to the absolute minimum. Single Use.",
	},
	"bossorb": {
		id: "bossorb",
		name: "Boss Orb",
		spritenum: 249,
		isUnreleased: true,
		onModifyDef: function (def) {
			return this.chainModify(8);
		},
		onModifySpD: function (spd) {
			return this.chainModify(8);
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).category === 'Status') {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'tox' || pokemon.status === 'par') {
				this.add('-activate', pokemon, 'item: Boss Orb');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'tox' && status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] item: Boss Orb');
			return false;
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.status === 'psn' || pokemon.status === 'brn' && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 25);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"bossorblite": {
		id: "bossorblite",
		name: "Boss Orb Lite",
		spritenum: 249,
		isUnreleased: true,
		onModifyDef: function (def) {
			return this.chainModify(8);
		},
		onModifySpD: function (spd) {
			return this.chainModify(8);
		},
		onModifyAtk: function (atk) {
			return this.chainModify(0.67);
		},
		onModifySpA: function (spa) {
			return this.chainModify(0.67);
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).category === 'Status') {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'tox' || pokemon.status === 'par') {
				this.add('-activate', pokemon, 'item: Boss Orb');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (status.id !== 'tox' && status.id !== 'par') return;
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] item: Boss Orb');
			return false;
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.status === 'psn' || pokemon.status === 'brn' && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 25);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"subbossorb": {
		id: "subbossorb",
		name: "Sub-Boss Orb",
		spritenum: 249,
		isUnreleased: true,
		onModifyDef: function (def) {
			return this.chainModify(3);
		},
		onModifySpD: function (spd) {
			return this.chainModify(3);
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).category === 'Status') {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"subbossorb": {
		id: "subbossorb",
		name: "Sub-Boss Orb",
		spritenum: 249,
		isUnreleased: true,
		onModifyDef: function (def) {
			return this.chainModify(3);
		},
		onModifySpD: function (spd) {
			return this.chainModify(3);
		},
		onDisableMove: function (pokemon) {
			let moves = pokemon.moveset;
			for (let i = 0; i < moves.length; i++) {
				if (this.getMove(moves[i].move).category === 'Status') {
					pokemon.disableMove(moves[i].id);
				}
			}
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"timerslow": {
		id: "timerslow",
		name: "Timer Slow",
		spritenum: 249,
		isUnreleased: true,
		onTry: function (pokemon, move) {
			if (move && move.id === 'terminate') {
				return;
			}
			this.add('-hint', "" + pokemon.name + " can only use Terminate");
			if (move.id !== 'terminate') {
				this.add('-fail', pokemon);
				return null;
			}
			this.add('-fail', pokemon);
			return null;
		},
		onUpdate: function (pokemon) {
			if (pokemon.status) {
				this.add('-activate', pokemon, 'item: Timer Code');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] item: Timer Code');
			return false;
		},
		onTryHit: function (target, source, move) {
			if (target !== source) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] item: Timer Code');
				}
				return null;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.damage(pokemon.maxhp / 20);
		},
		onFaint: function (pokemon, target) {
			this.useMove('termination', pokemon, target);
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		onTrapPokemon: function (pokemon) {
			pokemon.tryTrap();
		},
		onDragOut: function (pokemon) {
			this.add('-activate', pokemon, 'item: Timer Code');
			return null;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"timermoderate": {
		id: "timermoderate",
		name: "Timer Moderate",
		spritenum: 249,
		isUnreleased: true,
		onTry: function (pokemon, move) {
			if (move && move.id === 'terminate') {
				return;
			}
			this.add('-hint', "" + pokemon.name + " can only use Terminate");
			if (move.id !== 'terminate') {
				this.add('-fail', pokemon);
				return null;
			}
			this.add('-fail', pokemon);
			return null;
		},
		onUpdate: function (pokemon) {
			if (pokemon.status) {
				this.add('-activate', pokemon, 'item: Timer Code');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] item: Timer Code');
			return false;
		},
		onTryHit: function (target, source, move) {
			if (target !== source) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] item: Timer Code');
				}
				return null;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.damage(pokemon.maxhp / 15);
		},
		onFaint: function (pokemon, target) {
			this.useMove('termination', pokemon, target);
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		onTrapPokemon: function (pokemon) {
			pokemon.tryTrap();
		},
		onDragOut: function (pokemon) {
			this.add('-activate', pokemon, 'item: Timer Code');
			return null;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"timerfast": {
		id: "timerfast",
		name: "Timer Fast",
		spritenum: 249,
		isUnreleased: true,
		onTry: function (pokemon, move) {
			if (move && move.id === 'terminate') {
				return;
			}
			this.add('-hint', "" + pokemon.name + " can only use Terminate");
			if (move.id !== 'terminate') {
				this.add('-fail', pokemon);
				return null;
			}
			this.add('-fail', pokemon);
			return null;
		},
		onUpdate: function (pokemon) {
			if (pokemon.status) {
				this.add('-activate', pokemon, 'item: Timer Code');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] item: Timer Code');
			return false;
		},
		onTryHit: function (target, source, move) {
			if (target !== source) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] item: Timer Code');
				}
				return null;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.damage(pokemon.maxhp / 10);
		},
		onFaint: function (pokemon, target) {
			this.useMove('termination', pokemon, target);
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		onTrapPokemon: function (pokemon) {
			pokemon.tryTrap();
		},
		onDragOut: function (pokemon) {
			this.add('-activate', pokemon, 'item: Timer Code');
			return null;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"timerkaizo": {
		id: "timerkaizo",
		name: "Timer Kaizo",
		spritenum: 249,
		isUnreleased: true,
		onTry: function (pokemon, move) {
			if (move && move.id === 'terminate') {
				return;
			}
			this.add('-hint', "" + pokemon.name + " can only use Terminate");
			if (move.id !== 'terminate') {
				this.add('-fail', pokemon);
				return null;
			}
			this.add('-fail', pokemon);
			return null;
		},
		onUpdate: function (pokemon) {
			if (pokemon.status) {
				this.add('-activate', pokemon, 'item: Timer Code');
				pokemon.cureStatus();
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (!effect || !effect.status) return false;
			this.add('-immune', target, '[msg]', '[from] item: Timer Code');
			return false;
		},
		onTryHit: function (target, source, move) {
			if (target !== source) {
				if (!this.heal(0)) {
					this.add('-immune', target, '[msg]', '[from] item: Timer Code');
				}
				return null;
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.damage(pokemon.maxhp / 5);
		},
		onFaint: function (pokemon, target) {
			this.useMove('termination', pokemon, target);
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		onTrapPokemon: function (pokemon) {
			pokemon.tryTrap();
		},
		onDragOut: function (pokemon) {
			this.add('-activate', pokemon, 'item: Timer Code');
			return null;
		},
		num: 685,
		gen: 4,
		desc: "Amplifies Attack Damage by 1.1x.",
	},
	"validbypass": {
		id: "validbypass",
		name: "Valid Bypass",
		spritenum: 115,
		isUnreleased: true,
		onStart: function (pokemon) {
			this.damage(pokemon.maxhp);
		},
		onSwitchIn: function (pokemon) {
			this.damage(pokemon.maxhp);
		},
		onUpdate: function (pokemon) {
			this.damage(pokemon.maxhp);
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.damage(pokemon.maxhp);
		},
		onTakeItem: function (item, pokemon, source) {
			return false;
		},
		num: 13,
		gen: 4,
		desc: "A Poke Ball that makes it easier to catch wild Pokemon at night or in caves.",
	},
	"duskball": {
		id: "duskball",
		name: "Dusk Ball",
		spritenum: 115,
		num: 13,
		gen: 4,
		desc: "A Poke Ball that makes it easier to catch wild Pokemon at night or in caves.",
	},
	"earthplate": {
		id: "earthplate",
		name: "Earth Plate",
		spritenum: 117,
		onPlate: 'Ground',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Ground') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Ground",
		num: 305,
		gen: 4,
		desc: "Holder's Ground-type attacks have 1.2x power. Judgment is Ground type.",
	},
	"ejectbutton": {
		id: "ejectbutton",
		name: "Eject Button",
		spritenum: 118,
		fling: {
			basePower: 30,
		},
		onAfterMoveSecondary: function (target, source, move) {
			if (source && source !== target && target.hp && move && move.category !== 'Status') {
				if (!this.canSwitch(target.side) || target.forceSwitchFlag) return;
				if (target.useItem()) {
					target.switchFlag = true;
					source.switchFlag = false;
				}
			}
		},
		num: 547,
		gen: 5,
		desc: "If holder is hit, it immediately switches out with a chosen ally. Single use.",
	},
	"ejectpack": {
		id: "ejectpack",
		name: "Eject Pack",
		spritenum: 249,
		onAfterMoveSecondarySelf: function (pokemon, move) {
			let foeactive = pokemon.side.foe.active;
			let activated = false;
			for (let i = 0; i < foeactive.length; i++) {
				if (!foeactive[i] || !this.isAdjacent(foeactive[i], pokemon)) continue;
				if (foeactive[i].volatiles['flinch']) {
					if (pokemon.useItem(null, pokemon)) {
						this.add('-message', "" + pokemon.name + " has used its Eject Pack!");
						if (this.runEvent('DragOut', foeactive[i], pokemon, move)) {
							this.dragIn(foeactive[i].side, foeactive[i].position);
						}
					}
				}
			}
		},
		num: 685,
		gen: 4,
		desc: ".",
	},
	"electirizer": {
		id: "electirizer",
		name: "Electirizer",
		spritenum: 119,
		fling: {
			basePower: 80,
		},
		num: 322,
		gen: 4,
		desc: "Evolves Electabuzz into Electivire when traded.",
	},
	"electricgem": {
		id: "electricgem",
		name: "Electric Gem",
		spritenum: 120,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status' || move.id in {firepledge:1, grasspledge:1, waterpledge:1}) return;
			if (move.type === 'Electric') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Electric Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 550,
		gen: 5,
		desc: "Holder's first successful Electric-type attack will have 1.3x power. Single use.",
	},
	"energypowder": {
		id: "energypowder",
		name: "Energy Powder",
		spritenum: 123,
		fling: {
			basePower: 30,
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				source.eatItem();
				this.boost({spe:2}, source);
			}
		},
		num: 34,
		gen: 2,
		desc: "Restores 50 HP to one Pokemon but lowers Happiness.",
	},
	"boosterenergy": {
		id: "boosterenergy",
		name: "Booster Energy",
		spritenum: 123,
		fling: {
			basePower: 30,
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				source.eatItem();
				this.boost({spe:2}, source);
			}
		},
		num: 34900,
		gen: 2,
		desc: "Restores 50 HP to one Pokemon but lowers Happiness.",
	},
	"enigmaberry": {
		id: "enigmaberry",
		name: "Enigma Berry",
		spritenum: 124,
		isBerry: true,
		onBuffer: '???',
		naturalGift: {
			basePower: 100,
			type: "???",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === '???' && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 208,
		gen: 3,
		desc: "Restores 1/4 max HP after holder is hit by a supereffective move. Single use.",
	},
	"eviolite": {
		id: "eviolite",
		name: "Eviolite",
		spritenum: 130,
		fling: {
			basePower: 40,
		},
		onModifyDefPriority: 2,
		onModifyDef: function (def, pokemon) {
			if ((pokemon.baseTemplate.nfe || pokemon.baseTemplate.num === 233) && pokemon.baseTemplate.num !== 191) {
				return this.chainModify(1.5);
			}
		},
		onModifySpDPriority: 2,
		onModifySpD: function (spd, pokemon) {
			if ((pokemon.baseTemplate.nfe || pokemon.baseTemplate.num === 233) && pokemon.baseTemplate.num !== 191) {
				return this.chainModify(1.5);
			}
		},
		num: 538,
		gen: 5,
		desc: "If holder's species can evolve, its Defense and Sp. Def are 1.5x.",
	},
	"expertbelt": {
		id: "expertbelt",
		name: "Expert Belt",
		spritenum: 132,
		fling: {
			basePower: 10,
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 268,
		gen: 4,
		desc: "Holder's attacks that are super effective against the target do 1.2x damage.",
	},
	"fairygem": {
		id: "fairygem",
		name: "Fairy Gem",
		spritenum: 611,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Fairy') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Fairy Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: -6,
		gen: 6,
		desc: "Holder's first successful Fairy-type attack will have 1.3x power. Single use.",
	},
	"fastball": {
		id: "fastball",
		name: "Fast Ball",
		spritenum: 137,
		num: 492,
		gen: 2,
		desc: "A Poke Ball that makes it easier to catch Pokemon which are quick to run away.",
	},
	"fightinggem": {
		id: "fightinggem",
		name: "Fighting Gem",
		spritenum: 139,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Fighting') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Fighting Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 553,
		gen: 5,
		desc: "Holder's first successful Fighting-type attack will have 1.3x power. Single use.",
	},
	"figyberry": {
		id: "figyberry",
		name: "Figy Berry",
		spritenum: 140,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Bug",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(pokemon.maxhp / 8);
			if (pokemon.getNature().minus === 'atk') {
				pokemon.addVolatile('confusion');
			}
		},
		num: 159,
		gen: 3,
		desc: "Restores 1/8 max HP when at 1/2 max HP or less. May confuse. Single use.",
	},
	"firegem": {
		id: "firegem",
		name: "Fire Gem",
		spritenum: 141,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status' || move.id in {firepledge:1, grasspledge:1, waterpledge:1}) return;
			if (move.type === 'Fire') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Fire Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 548,
		gen: 5,
		desc: "Holder's first successful Fire-type attack will have 1.3x power. Single use.",
	},
	"fistplate": {
		id: "fistplate",
		name: "Fist Plate",
		spritenum: 143,
		onPlate: 'Fighting',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fighting') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Fighting",
		num: 303,
		gen: 4,
		desc: "Holder's Fighting-type attacks have 1.2x power. Judgment is Fighting type.",
	},
	"flameorb": {
		id: "flameorb",
		name: "Flame Orb",
		spritenum: 145,
		fling: {
			basePower: 30,
			status: 'brn',
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fire') {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (!pokemon.hasAbility('spacepower') && !pokemon.volatiles['profire']) {
				pokemon.trySetStatus('brn', pokemon);
			}
		},
		num: 273,
		gen: 4,
		desc: "At the end of every turn, this item attempts to burn the holder.",
	},
	"flameplate": {
		id: "flameplate",
		name: "Flame Plate",
		spritenum: 146,
		onPlate: 'Fire',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fire') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Fire",
		num: 298,
		gen: 4,
		desc: "Holder's Fire-type attacks have 1.2x power. Judgment is Fire type.",
	},
	"floatstone": {
		id: "floatstone",
		name: "Float Stone",
		spritenum: 147,
		fling: {
			basePower: 30,
		},
		onModifyWeight: function (weight) {
			return weight / 2;
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if ((pokemon.hp < pokemon.maxhp) && move && (move.id === 'healblock' || move.id === 'haze')) {
				pokemon.eatItem();
				this.heal(pokemon.maxhp, pokemon);
			}
		},
		num: 539,
		gen: 5,
		desc: "Holder's weight is halved.",
	},
	"flyinggem": {
		id: "flyinggem",
		name: "Flying Gem",
		spritenum: 149,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Flying') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Flying Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 556,
		gen: 5,
		desc: "Holder's first successful Flying-type attack will have 1.3x power. Single use.",
	},
	"focusband": {
		id: "focusband",
		name: "Focus Band",
		spritenum: 150,
		fling: {
			basePower: 10,
		},
		onDragOutPriority: 1,
		onDragOut: function (pokemon) {
			if (pokemon.useItem()) {
				return null;
			}
		},
		num: 230,
		gen: 2,
		desc: "Holder has a 10% chance to survive an attack that would KO it with 1 HP.",
	},
	"focussash": {
		id: "focussash",
		name: "Focus Sash",
		spritenum: 151,
		fling: {
			basePower: 10,
		},
		onDamage: function (damage, target, source, effect) {
			if (this.random(4) === 0 && target.hp === target.maxhp && damage >= target.hp && effect && effect.effectType === 'Move') {
				if (target.useItem()) {
					return target.hp - 1;
				}
			}
		},
		num: 275,
		gen: 4,
		desc: "If holder's HP is full, will survive an attack that would KO it with 1 HP. Single use.",
	},
	"rustedsword": {
		id: "rustedsword",
		name: "Rusted Sword",
		spritenum: 153,
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.flags['sword']) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		num: 497,
		gen: 4,
		desc: ".",
	},
	"rustedshield": {
		id: "rustedshield",
		name: "Rusted Shield",
		spritenum: 153,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if ((pokemon.hp < pokemon.maxhp) && move && (move.id === 'kingsshield')) {
				pokemon.eatItem();
				this.heal(pokemon.maxhp, pokemon);
			}
		},
		num: 497,
		gen: 4,
		desc: ".",
	},
	"protectivepads": {
		id: "protectivepads",
		name: "Protective Pads",
		spritenum: 663,
		fling: {
			basePower: 30,
		},
		onAttractPriority: -1,
		onAttract: function (target, source, effect) {
			if (target !== source && target === this.activePokemon && this.activeMove.flags['contact']) return false;
		},
		onBoostPriority: -1,
		onBoost: function (boost, target, source, effect) {
			if (target !== source && target === this.activePokemon && this.activeMove.flags['contact']) {
				if (effect && effect.effectType === 'Ability') {
					// Ability activation always happens for boosts
					this.add('-activate', target, 'item: Protective Pads');
				}
				return false;
			}
		},
		onDamagePriority: -1,
		onDamage: function (damage, target, source, effect) {
			if (target !== source && target === this.activePokemon && this.activeMove.flags['contact']) {
				if (effect && effect.effectType === 'Ability') {
					this.add('-activate', source, effect.fullname);
					this.add('-activate', target, 'item: Protective Pads');
				}
				return false;
			}
		},
		onSetAbility: function (ability, target, source, effect) {
			if (target !== source && target === this.activePokemon && this.activeMove.flags['contact']) {
				if (effect && effect.effectType === 'Ability') {
					this.add('-activate', source, effect.fullname);
					this.add('-activate', target, 'item: Protective Pads');
				}
				return false;
			}
		},
		onSetStatus: function (status, target, source, effect) {
			if (target !== source && target === this.activePokemon && this.activeMove.flags['contact']) return false;
		},
		num: 880,
		gen: 4,
		desc: "Holder's moves are protected from adverse contact effects, except Pickpocket.",
	},
	"leafstone": {
		id: "leafstone",
		name: "Leaf Stone",
		spritenum: 153,
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (pokemon.baseTemplate.species === 'Calyrex-Shadow' && move.id === 'hyperbeam') {
				move.type = 'Grass';
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && user.baseTemplate.species === 'Calyrex-Shadow') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 497,
		gen: 2,
		desc: ".",
	},
	"firestone": {
		id: "firestone",
		name: "Fire Stone",
		spritenum: 153,
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (pokemon.baseTemplate.species === 'Calyrex-Shadow' && move.id === 'hyperbeam') {
				move.type = 'Fire';
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && user.baseTemplate.species === 'Calyrex-Shadow') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 497,
		gen: 2,
		desc: ".",
	},
	"thunderstone": {
		id: "thunderstone",
		name: "Thunder Stone",
		spritenum: 153,
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (pokemon.baseTemplate.species === 'Calyrex-Shadow' && move.id === 'hyperbeam') {
				move.type = 'Electric';
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && user.baseTemplate.species === 'Calyrex-Shadow') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 497,
		gen: 2,
		desc: ".",
	},
	"waterstone": {
		id: "waterstone",
		name: "Water Stone",
		spritenum: 153,
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (pokemon.baseTemplate.species === 'Calyrex-Shadow' && move.id === 'hyperbeam') {
				move.type = 'Water';
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && user.baseTemplate.species === 'Calyrex-Shadow') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 497,
		gen: 2,
		desc: ".",
	},
	"icestone": {
		id: "icestone",
		name: "Ice Stone",
		spritenum: 153,
		onModifyMovePriority: -1,
		onModifyMove: function (move, pokemon) {
			if (pokemon.baseTemplate.species === 'Calyrex-Shadow' && move.id === 'hyperbeam') {
				move.type = 'Ice';
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && user.baseTemplate.species === 'Calyrex-Shadow') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 497,
		gen: 2,
		desc: ".",
	},
	"sunstone": {
		id: "sunstone",
		name: "Sun Stone",
		spritenum: 153,
		num: 497,
		gen: 2,
		desc: ".",
	},
	"moonstone": {
		id: "moonstone",
		name: "Moon Stone",
		spritenum: 153,
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Lunala') return false;
			return true;
		},
		num: 497,
		gen: 2,
		desc: ".",
	},
	"prismscale": {
		id: "prismscale",
		name: "Prism Scale",
		spritenum: 153,
		noRecycle: true,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move && move.flags['heavy']) {
				pokemon.eatItem();
				this.boost({spa:3});
			}
		},
		num: 497,
		gen: 2,
		desc: ".",
	},
	"dawnstone": {
		id: "dawnstone",
		name: "Dawn Stone",
		spritenum: 139,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.category === 'Special') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Dawn Stone', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 553,
		gen: 5,
		desc: "Holder's first successful Special attack will have 1.3x power. Single use.",
	},
	"duskstone": {
		id: "duskstone",
		name: "Dusk Stone",
		spritenum: 139,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.category === 'Physical') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Dusk Stone', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 553,
		gen: 5,
		desc: "Holder's first successful Physical attack will have 1.3x power. Single use.",
	},
	"ovalstone": {
		id: "ovalstone",
		name: "Oval Stone",
		spritenum: 139,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move && move.flags['shatter']) {
				if (source.useItem()) {
					this.add('-enditem', source, 'Oval Stone', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 553,
		gen: 5,
		desc: "Holder's first successful Shatter attack will have 1.3x power. Single use.",
	},
	"friendball": {
		id: "friendball",
		name: "Friend Ball",
		spritenum: 153,
		num: 497,
		gen: 2,
		desc: "A Poke Ball that makes caught Pokemon more friendly.",
	},
	"fullincense": {
		id: "fullincense",
		name: "Full Incense",
		spritenum: 155,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (this.isWeather(['sunnyday', 'desolateland']) && (move.type === 'Ground' || move.type === 'Flying')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 316,
		gen: 4,
		desc: "Holder moves last in its priority bracket.",
	},
	"galladite": {
		id: "galladite",
		name: "Galladite",
		spritenum: 616,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Gallade') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Gallade-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Gallade') return false;
			return true;
		},
		num: 756,
		gen: 6,
		desc: "If holder is a Gallade, this item allows it to Mega Evolve in battle.",
	},
	"ganlonberry": {
		id: "ganlonberry",
		name: "Ganlon Berry",
		spritenum: 158,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Ice",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || pokemon.hasAbility('gluttony')) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			this.boost({def:1});
		},
		num: 202,
		gen: 3,
		desc: "Raises holder's Defense by 1 stage when at 1/4 max HP or less. Single use.",
	},
	"garchompite": {
		id: "garchompite",
		name: "Garchompite",
		spritenum: 589,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Garchomp') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Garchomp-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Garchomp') return false;
			return true;
		},
		num: 683,
		gen: 6,
		desc: "If holder is a Garchomp, this item allows it to Mega Evolve in battle.",
	},
	"gardevoirite": {
		id: "gardevoirite",
		name: "Gardevoirite",
		spritenum: 587,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Gardevoir') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Gardevoir-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Gardevoir') return false;
			return true;
		},
		num: 657,
		gen: 6,
		desc: "If holder is a Gardevoir, this item allows it to Mega Evolve in battle.",
	},
	"gengarite": {
		id: "gengarite",
		name: "Gengarite",
		spritenum: 588,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Gengar') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Gengar-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Gengar') return false;
			return true;
		},
		num: 656,
		gen: 6,
		desc: "If holder is a Gengar, this item allows it to Mega Evolve in battle.",
	},
	"ghostgem": {
		id: "ghostgem",
		name: "Ghost Gem",
		spritenum: 161,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Ghost') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Ghost Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 560,
		gen: 5,
		desc: "Holder's first successful Ghost-type attack will have 1.3x power. Single use.",
	},
	"glalitite": {
		id: "glalitite",
		name: "Glalitite",
		spritenum: 623,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Glalie') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Glalie-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Glalie') return false;
			return true;
		},
		num: 763,
		gen: 6,
		desc: "If holder is a Glalie, this item allows it to Mega Evolve in battle.",
	},
	"grassgem": {
		id: "grassgem",
		name: "Grass Gem",
		spritenum: 172,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status' || move.id in {firepledge:1, grasspledge:1, waterpledge:1}) return;
			if (move.type === 'Grass') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Grass Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 551,
		gen: 5,
		desc: "Holder's first successful Grass-type attack will have 1.3x power. Single use.",
	},
	"greatball": {
		id: "greatball",
		name: "Great Ball",
		spritenum: 174,
		num: 3,
		gen: 1,
		desc: "A high-performance Ball that provides a higher catch rate than a Poke Ball.",
	},
	"grepaberry": {
		id: "grepaberry",
		name: "Grepa Berry",
		spritenum: 178,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Flying",
		},
		num: 173,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"gripclaw": {
		id: "gripclaw",
		name: "Grip Claw",
		spritenum: 179,
		fling: {
			basePower: 90,
		},
		// implemented in statuses
		num: 286,
		gen: 4,
		desc: "Holder's partial-trapping moves always last 7 turns.",
	},
	"griseousorb": {
		id: "griseousorb",
		name: "Griseous Orb",
		spritenum: 180,
		fling: {
			basePower: 60,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (user.baseTemplate.num === 487 && (move.type === 'Ghost' || move.type === 'Dragon')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 487) || pokemon.baseTemplate.num === 487) {
				return false;
			}
			return true;
		},
		num: 112,
		gen: 4,
		desc: "If holder is a Giratina, its Ghost- and Dragon-type attacks have 1.2x power.",
	},
	"adrenalineorb": {
		id: "adrenalineorb",
		name: "Adrenaline Orb",
		spritenum: 249,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && (user.baseTemplate.species === 'Mewtwo' || user.template.species === 'Mewtwo-Mega-X' || user.template.species === 'Mewtwo-Mega-Y')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 150) || pokemon.baseTemplate.num === 150) {
				return false;
			}
			return true;
		},
		num: 270,
		gen: 4,
		desc: "Holder's attacks do 1.3x damage.",
	},
	"groundgem": {
		id: "groundgem",
		name: "Ground Gem",
		spritenum: 182,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Ground') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Ground Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 555,
		gen: 5,
		desc: "Holder's first successful Ground-type attack will have 1.3x power. Single use.",
	},
	"gyaradosite": {
		id: "gyaradosite",
		name: "Gyaradosite",
		spritenum: 589,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Gyarados') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Gyarados-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Gyarados') return false;
			return true;
		},
		num: 676,
		gen: 6,
		desc: "If holder is a Gyarados, this item allows it to Mega Evolve in battle.",
	},
	"habanberry": {
		id: "habanberry",
		name: "Haban Berry",
		spritenum: 185,
		isBerry: true,
		onBuffer: 'Dragon',
		naturalGift: {
			basePower: 80,
			type: "Dragon",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Dragon' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 197,
		gen: 4,
		desc: "Halves damage taken from a supereffective Dragon-type attack. Single use.",
	},
	"hardstone": {
		id: "hardstone",
		name: "Hard Stone",
		spritenum: 187,
		fling: {
			basePower: 100,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Rock') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 238,
		gen: 2,
		desc: "Holder's Rock-type attacks have 1.2x power.",
	},
	"healball": {
		id: "healball",
		name: "Heal Ball",
		spritenum: 188,
		num: 14,
		gen: 4,
		desc: "A remedial Poke Ball that restores the caught Pokemon's HP and status problem.",
	},
	"heatrock": {
		id: "heatrock",
		name: "Heat Rock",
		spritenum: 193,
		fling: {
			basePower: 60,
		},
		num: 284,
		gen: 4,
		desc: "Holder's use of Sunny Day lasts 8 turns instead of 5.",
	},
	"heavyball": {
		id: "heavyball",
		name: "Heavy Ball",
		spritenum: 194,
		num: 495,
		gen: 2,
		desc: "A Poke Ball for catching very heavy Pokemon.",
	},
	"helixfossil": {
		id: "helixfossil",
		name: "Helix Fossil",
		spritenum: 195,
		fling: {
			basePower: 100,
		},
		num: 101,
		gen: 3,
		desc: "Can be revived into Omanyte.",
	},
	"heracronite": {
		id: "heracronite",
		name: "Heracronite",
		spritenum: 590,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Heracross') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Heracross-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Heracross') return false;
			return true;
		},
		num: 680,
		gen: 6,
		desc: "If holder is a Heracross, this item allows it to Mega Evolve in battle.",
	},
	"hondewberry": {
		id: "hondewberry",
		name: "Hondew Berry",
		spritenum: 213,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Ground",
		},
		num: 172,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"houndoominite": {
		id: "houndoominite",
		name: "Houndoominite",
		spritenum: 591,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Houndoom') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Houndoom-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Houndoom') return false;
			return true;
		},
		num: 666,
		gen: 6,
		desc: "If holder is a Houndoom, this item allows it to Mega Evolve in battle.",
	},
	"iapapaberry": {
		id: "iapapaberry",
		name: "Iapapa Berry",
		spritenum: 217,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Dark",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(pokemon.maxhp / 8);
			if (pokemon.getNature().minus === 'def') {
				pokemon.addVolatile('confusion');
			}
		},
		num: 163,
		gen: 3,
		desc: "Restores 1/8 max HP when at 1/2 max HP or less. May confuse. Single use.",
	},
	"icegem": {
		id: "icegem",
		name: "Ice Gem",
		spritenum: 218,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Ice') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Ice Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 552,
		gen: 5,
		desc: "Holder's first successful Ice-type attack will have 1.3x power. Single use.",
	},
	"icicleplate": {
		id: "icicleplate",
		name: "Icicle Plate",
		spritenum: 220,
		onPlate: 'Ice',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Ice') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Ice",
		num: 302,
		gen: 4,
		desc: "Holder's Ice-type attacks have 1.2x power. Judgment is Ice type.",
	},
	"icyrock": {
		id: "icyrock",
		name: "Icy Rock",
		spritenum: 221,
		fling: {
			basePower: 40,
		},
		num: 282,
		gen: 4,
		desc: "Holder's use of Hail lasts 8 turns instead of 5.",
	},
	"insectplate": {
		id: "insectplate",
		name: "Insect Plate",
		spritenum: 223,
		onPlate: 'Bug',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Bug') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Bug",
		num: 308,
		gen: 4,
		desc: "Holder's Bug-type attacks have 1.2x power. Judgment is Bug type.",
	},
	"ironball": {
		id: "ironball",
		name: "Iron Ball",
		spritenum: 224,
		fling: {
			basePower: 130,
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (target.volatiles['ingrain'] || target.volatiles['smackdown'] || this.getPseudoWeather('gravity')) return;
			if (move.type === 'Ground' && !this.getImmunity(move.type, target)) return 0;
		},
		onNegateImmunity: function (pokemon, type) {
			if (type === 'Ground') return false;
		},
		onModifySpe: function (spe) {
			return this.chainModify(0.5);
		},
		num: 278,
		gen: 4,
		desc: "Holder is grounded, Speed halved. If Flying type, takes neutral Ground damage.",
	},
	"ironplate": {
		id: "ironplate",
		name: "Iron Plate",
		spritenum: 225,
		onPlate: 'Steel',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Steel') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Steel",
		num: 313,
		gen: 4,
		desc: "Holder's Steel-type attacks have 1.2x power. Judgment is Steel type.",
	},
	"jabocaberry": {
		id: "jabocaberry",
		name: "Jaboca Berry",
		spritenum: 230,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Dragon",
		},
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.category === 'Physical') {
				if (target.eatItem()) {
					this.damage(source.maxhp / 8, source, target, null, true);
				}
			}
		},
		onEat: function () { },
		num: 211,
		gen: 4,
		desc: "If holder is hit by a physical move, attacker loses 1/8 of its max HP. Single use.",
	},
	"kasibberry": {
		id: "kasibberry",
		name: "Kasib Berry",
		spritenum: 233,
		isBerry: true,
		onBuffer: 'Ghost',
		naturalGift: {
			basePower: 80,
			type: "Ghost",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Ghost' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 196,
		gen: 4,
		desc: "Halves damage taken from a supereffective Ghost-type attack. Single use.",
	},
	"kebiaberry": {
		id: "kebiaberry",
		name: "Kebia Berry",
		spritenum: 234,
		isBerry: true,
		onBuffer: 'Poison',
		naturalGift: {
			basePower: 80,
			type: "Poison",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Poison' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 190,
		gen: 4,
		desc: "Halves damage taken from a supereffective Poison-type attack. Single use.",
	},
	"keeberry": {
		id: "keeberry",
		name: "Kee Berry",
		spritenum: 593,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Fairy",
		},
		onAfterMoveSecondary: function (target, source, move) {
			if (move.category === 'Physical') {
				target.eatItem();
			}
		},
		onEat: function (pokemon) {
			this.boost({def: 1});
		},
		num: -6,
		gen: 6,
		desc: "Raises holder's Defense by 1 stage after it is hit by a physical attack. Single use.",
	},
	"kelpsyberry": {
		id: "kelpsyberry",
		name: "Kelpsy Berry",
		spritenum: 235,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Fighting",
		},
		num: 170,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"kangaskhanite": {
		id: "kangaskhanite",
		name: "Kangaskhanite",
		spritenum: 592,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Kangaskhan') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Kangaskhan-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Kangaskhan') return false;
			return true;
		},
		num: 675,
		gen: 6,
		desc: "If holder is a Kangaskhan, this item allows it to Mega Evolve in battle.",
	},
	"kingsrock": {
		id: "kingsrock",
		name: "King's Rock",
		spritenum: 236,
		fling: {
			basePower: 30,
			volatileStatus: 'flinch',
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move) {
			if (move.category !== "Status") {
				if (!move.secondaries) move.secondaries = [];
				for (let i = 0; i < move.secondaries.length; i++) {
					if (move.secondaries[i].volatileStatus === 'flinch') return;
				}
				move.secondaries.push({
					chance: 10,
					volatileStatus: 'flinch',
				});
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 199) || pokemon.baseTemplate.num === 199) {
				return false;
			}
			return true;
		},
		num: 221,
		gen: 2,
		desc: "Holder's attacks without a chance to flinch gain a 10% chance to flinch.",
	},
	"laggingtail": {
		id: "laggingtail",
		name: "Lagging Tail",
		spritenum: 237,
		fling: {
			basePower: 10,
		},
		onModifyPriority: function (priority, pokemon) {
			if (!pokemon.hasAbility('stall')) {
				return priority - 0.1;
			}
		},
		num: 279,
		gen: 4,
		desc: "Holder moves last in its priority bracket.",
	},
	"lansatberry": {
		id: "lansatberry",
		name: "Lansat Berry",
		spritenum: 238,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Flying",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || pokemon.hasAbility('gluttony')) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			pokemon.addVolatile('focusenergy');
		},
		num: 206,
		gen: 3,
		desc: "Holder gains the Focus Energy effect when at 1/4 max HP or less. Single use.",
	},
	"latiasite": {
		id: "latiasite",
		name: "Latiasite",
		spritenum: 629,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Latias') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Latias-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Latias') return false;
			return true;
		},
		num: -6,
		gen: 6,
		desc: "If holder is a Latias, this item allows it to Mega Evolve in battle.",
	},
	"latiosite": {
		id: "latiosite",
		name: "Latiosite",
		spritenum: 630,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Latios') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Latios-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Latios') return false;
			return true;
		},
		num: -6,
		gen: 6,
		desc: "If holder is a Latios, this item allows it to Mega Evolve in battle.",
	},
	"laxincense": {
		id: "laxincense",
		name: "Lax Incense",
		spritenum: 240,
		fling: {
			basePower: 10,
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if ((pokemon.hasType('Fire') || pokemon.hasType('Grass')) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 10);
			}
		},
		num: 255,
		gen: 3,
		desc: "The accuracy of attacks against the holder is 0.9x.",
	},
	"chippedpot": {
		id: "chippedpot",
		name: "Chipped Pot",
		spritenum: 240,
		fling: {
			basePower: 10,
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if ((pokemon.hasType('Ghost')) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 10);
			}
		},
		num: 255,
		gen: 3,
		desc: "The accuracy of attacks against the holder is 0.9x.",
	},
	"leftovers": {
		id: "leftovers",
		name: "Leftovers",
		spritenum: 242,
		fling: {
			basePower: 10,
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (!pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 12);
			}
		},
		num: 234,
		gen: 2,
		desc: "At the end of every turn, holder restores 1/10 of its max HP.",
	},
	"leppaberry": {
		id: "leppaberry",
		name: "Leppa Berry",
		spritenum: 244,
		isBerry: true,
		isUnreleased: true,
		naturalGift: {
			basePower: 80,
			type: "Fighting",
		},
		onUpdate: function (pokemon) {
			let move = pokemon.getMoveData(pokemon.lastMove);
			if (move && move.pp === 0) {
				pokemon.addVolatile('leppaberry');
				pokemon.volatiles['leppaberry'].move = move;
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			let move;
			if (pokemon.volatiles['leppaberry']) {
				move = pokemon.volatiles['leppaberry'].move;
				pokemon.removeVolatile('leppaberry');
			} else {
				let pp = 99;
				for (let moveid in pokemon.moveset) {
					if (pokemon.moveset[moveid].pp < pp) {
						move = pokemon.moveset[moveid];
						pp = move.pp;
					}
				}
			}
			move.pp += 10;
			if (move.pp > move.maxpp) move.pp = move.maxpp;
			this.add('-activate', pokemon, 'item: Leppa Berry', move.move);
			if (pokemon.item !== 'leppaberry') {
				let foeActive = pokemon.side.foe.active;
				let foeIsStale = false;
				for (let i = 0; i < 1; i++) {
					if (foeActive.isStale >= 2) {
						foeIsStale = true;
						break;
					}
				}
				if (!foeIsStale) return;
			}
			pokemon.isStale = 2;
			pokemon.isStaleSource = 'useleppa';
		},
		num: 154,
		gen: 3,
		desc: "Restores 10 PP to the first of the holder's moves to reach 0 PP. Single use.",
	},
	"levelball": {
		id: "levelball",
		name: "Level Ball",
		spritenum: 246,
		num: 493,
		gen: 2,
		desc: "A Poke Ball for catching Pokemon that are a lower level than your own.",
	},
	"liechiberry": {
		id: "liechiberry",
		name: "Liechi Berry",
		spritenum: 248,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Grass",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || pokemon.hasAbility('gluttony')) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			this.boost({atk:1});
		},
		num: 201,
		gen: 3,
		desc: "Raises holder's Attack by 1 stage when at 1/4 max HP or less. Single use.",
	},
	"lifeorb": {
		id: "lifeorb",
		name: "Life Orb",
		spritenum: 249,
		fling: {
			basePower: 30,
		},
		onModifyDamage: function (damage, source, target, move) {
			return this.chainModify([0x14CD, 0x1000]);
		},
		onAfterMoveSecondarySelf: function (source, target, move) {
			if (source && source !== target && move && move.category !== 'Status' && !move.ohko) {
				this.damage(source.maxhp / 8, source, source, this.getItem('lifeorb'));
			}
		},
		num: 270,
		gen: 4,
		desc: "Holder's attacks do 1.3x damage, and it loses 1/10 its max HP after the attack.",
	},
	"lightball": {
		id: "lightball",
		name: "Light Ball",
		spritenum: 251,
		fling: {
			basePower: 30,
			status: 'par',
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Electric') {
				return this.chainModify([0x1800, 0x1000]);
			} else if (user.baseTemplate.species === 'Tapu Koko' && move && move.type !== 'Electric') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (!pokemon.hasAbility('spacepower') && !pokemon.hasType('Ground') && !pokemon.volatiles['proelectric']) {
				pokemon.trySetStatus('par', pokemon);
			}
		},
		num: 236,
		gen: 2,
		desc: "If holder is a Pikachu, its Attack and Sp. Atk are doubled.",
	},
	"lightclay": {
		id: "lightclay",
		name: "Light Clay",
		noRecycle: true,
		spritenum: 252,
		fling: {
			basePower: 30,
		},
		// implemented in the corresponding thing
		num: 269,
		gen: 4,
		desc: "Holder's use of Light Screen or Reflect lasts 8 turns instead of 5.",
	},
	"lopunnite": {
		id: "lopunnite",
		name: "Lopunnite",
		spritenum: 626,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Lopunny') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Lopunny-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Lopunny') return false;
			return true;
		},
		num: 768,
		gen: 6,
		desc: "If holder is a Lopunny, this item allows it to Mega Evolve in battle.",
	},
	"loveball": {
		id: "loveball",
		name: "Love Ball",
		spritenum: 258,
		num: 496,
		gen: 2,
		desc: "Poke Ball for catching Pokemon that are the opposite gender of your Pokemon.",
	},
	"lucarionite": {
		id: "lucarionite",
		name: "Lucarionite",
		spritenum: 594,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Lucario') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Lucario-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Lucaio') return false;
			return true;
		},
		num: 673,
		gen: 6,
		desc: "If holder is a Lucario, this item allows it to Mega Evolve in battle.",
	},
	"luckypunch": {
		id: "luckypunch",
		name: "Lucky Punch",
		spritenum: 261,
		fling: {
			basePower: 40,
		},
		onModifyMove: function (move, user) {
			if (user.baseTemplate.species === 'Chansey') {
				move.critRatio += 2;
			}
		},
		num: 256,
		gen: 2,
		desc: "If holder is a Chansey, its critical hit ratio is raised by 2 stages.",
	},
	"lumberry": {
		id: "lumberry",
		name: "Lum Berry",
		spritenum: 262,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Flying",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status || pokemon.volatiles['confusion']) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			pokemon.cureStatus();
			pokemon.removeVolatile('confusion');
		},
		num: 157,
		gen: 3,
		desc: "Holder cures itself if it is confused or has a major status condition. Single use.",
	},
	"luminousmoss": {
		id: "luminousmoss",
		name: "Luminous Moss",
		spritenum: 595,
		fling: {
			basePower: 30,
		},
		onAfterDamage: function (damage, target, source, move) {
			if (move.type === 'Water' && target.useItem()) {
				this.boost({spd: 1});
			}
		},
		num: -6,
		gen: 6,
		desc: "Raises holder's Sp. Def by 1 stage if hit by a Water-type attack. Single use.",
	},
	"lureball": {
		id: "lureball",
		name: "Lure Ball",
		spritenum: 264,
		num: 494,
		gen: 2,
		desc: "A Poke Ball for catching Pokemon hooked by a Rod when fishing.",
	},
	"lustrousorb": {
		id: "lustrousorb",
		name: "Lustrous Orb",
		spritenum: 265,
		fling: {
			basePower: 60,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && user.baseTemplate.species === 'Palkia' && (move.type === 'Water' || move.type === 'Dragon')) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 484) || pokemon.baseTemplate.num === 484) {
				return false;
			}
			return true;
		},
		num: 136,
		gen: 4,
		desc: "If holder is a Palkia, its Water- and Dragon-type attacks have 1.2x power.",
	},
	"luxuryball": {
		id: "luxuryball",
		name: "Luxury Ball",
		spritenum: 266,
		num: 11,
		gen: 3,
		desc: "A comfortable Poke Ball that makes a caught wild Pokemon quickly grow friendly.",
	},
	"machobrace": {
		id: "machobrace",
		name: "Macho Brace",
		spritenum: 269,
		fling: {
			basePower: 60,
		},
		onModifySpe: function (spe) {
			return this.chainModify(0.5);
		},
		num: 215,
		gen: 3,
		desc: "Holder's Speed is halved.",
	},
	"magnet": {
		id: "magnet",
		name: "Magnet",
		spritenum: 273,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Electric') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 242,
		gen: 2,
		desc: "Holder's Electric-type attacks have 1.2x power.",
	},
	"magoberry": {
		id: "magoberry",
		name: "Mago Berry",
		spritenum: 274,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Ghost",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(pokemon.maxhp / 3);
			if (pokemon.getNature().minus === 'spe') {
				pokemon.addVolatile('confusion');
			}
		},
		num: 161,
		gen: 3,
		desc: "Restores 1/8 max HP when at 1/2 max HP or less. May confuse. Single use.",
	},
	"magostberry": {
		id: "magostberry",
		name: "Magost Berry",
		spritenum: 275,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Rock",
		},
		num: 176,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"mail": {
		id: "mail",
		name: "Mail",
		spritenum: 403,
		onTakeItem: function (item, source) {
			if (!this.activeMove) return false;
			if (this.activeMove.id !== 'knockoff' && this.activeMove.id !== 'thief' && this.activeMove.id !== 'covet') return false;
		},
		gen: 2,
		desc: "Cannot be given to or taken from a Pokemon, except by Covet/Knock Off/Thief.",
	},
	"manectite": {
		id: "manectite",
		name: "Manectite",
		spritenum: 596,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Manectric') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Manectric-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Manectric') return false;
			return true;
		},
		num: 682,
		gen: 6,
		desc: "If holder is a Manectric, this item allows it to Mega Evolve in battle.",
	},
	"marangaberry": {
		id: "marangaberry",
		name: "Maranga Berry",
		spritenum: 597,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Dark",
		},
		onAfterMoveSecondary: function (target, source, move) {
			if (move.category === 'Special') {
				target.eatItem();
			}
		},
		onEat: function (pokemon) {
			this.boost({spd: 1});
		},
		num: -6,
		gen: 6,
		desc: "Raises holder's Sp. Def by 1 stage after it is hit by a special attack. Single use.",
	},
	"masterball": {
		id: "masterball",
		name: "Master Ball",
		spritenum: 276,
		num: 1,
		gen: 1,
		desc: "The best Ball with the ultimate performance. It will catch any wild Pokemon.",
	},
	"mawilite": {
		id: "mawilite",
		name: "Mawilite",
		spritenum: 598,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Mawile') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Mawile-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Mawile') return false;
			return true;
		},
		num: 681,
		gen: 6,
		desc: "If holder is a Mawile, this item allows it to Mega Evolve in battle.",
	},
	"meadowplate": {
		id: "meadowplate",
		name: "Meadow Plate",
		spritenum: 282,
		onPlate: 'Grass',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Grass') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Grass",
		num: 301,
		gen: 4,
		desc: "Holder's Grass-type attacks have 1.2x power. Judgment is Grass type.",
	},
	"medichamite": {
		id: "medichamite",
		name: "Medichamite",
		spritenum: 599,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Medicham') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Medicham-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Medicham') return false;
			return true;
		},
		num: 665,
		gen: 6,
		desc: "If holder is a Medicham, this item allows it to Mega Evolve in battle.",
	},
	"mentalherb": {
		id: "mentalherb",
		name: "Mental Herb",
		spritenum: 285,
		fling: {
			basePower: 10,
			effect: function (pokemon) {
				let conditions = ['attract', 'taunt', 'encore', 'torment', 'disable', 'healblock'];
				for (let i = 0; i < conditions.length; i++) {
					if (pokemon.volatiles[conditions[i]]) {
						for (let j = 0; j < conditions.length; j++) {
							pokemon.removeVolatile(conditions[j]);
							if (conditions[i] === 'attract' && conditions[j] === 'attract') {
								this.add('-end', pokemon, 'move: Attract', '[from] item: Mental Herb');
							}
						}
						return;
					}
				}
			},
		},
		onUpdate: function (pokemon) {
			let conditions = ['attract', 'taunt', 'encore', 'torment', 'disable', 'healblock'];
			for (let i = 0; i < conditions.length; i++) {
				if (pokemon.volatiles[conditions[i]]) {
					if (!pokemon.useItem()) return;
					for (let j = 0; j < conditions.length; j++) {
						pokemon.removeVolatile(conditions[j]);
						if (conditions[i] === 'attract' && conditions[j] === 'attract') {
							this.add('-end', pokemon, 'move: Attract', '[from] item: Mental Herb');
						}
					}
					return;
				}
			}
		},
		num: 219,
		gen: 3,
		desc: "Cures holder of Attract, Disable, Encore, Heal Block, Taunt, Torment. Single use.",
	},
	"metagrossite": {
		id: "metagrossite",
		name: "Metagrossite",
		spritenum: 618,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Metagross') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Metagross-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Metagross') return false;
			return true;
		},
		num: 758,
		gen: 6,
		desc: "If holder is a Metagross, this item allows it to Mega Evolve in battle.",
	},
	"metalcoat": {
		id: "metalcoat",
		name: "Metal Coat",
		spritenum: 286,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Steel') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (pokemon.hasType('Steel') && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 10);
			}
		},
		num: 233,
		gen: 2,
		desc: "Holder's Steel-type attacks have 1.2x power.",
	},
	"throatspray": {
		id: "throatspray",
		name: "Throat Spray",
		spritenum: 143,
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.flags['sound']) {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 303,
		gen: 4,
		desc: "Holder's Fighting-type attacks have 1.2x power. Judgment is Fighting type.",
	},
	"utilityumbrella": {
		id: "utilityumbrella",
		name: "Utility Umbrella",
		spritenum: 249,
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move && move.category !== 'Status' && (move.flags['spout'] || move.flags['umbrella'])) {
				return this.chainModify(0.25);
			}
		},
		onHit: function (target, source, move) {
			if (target.hp && move.category !== 'Status' && (move.flags['spout'] || move.flags['umbrella'])) {
				this.boost({def: 1, spd: 1});
			}
		},
		num: 685,
		gen: 4,
		desc: ".",
	},
	"shinystone": {
		id: "shinystone",
		name: "Shiny Stone",
		spritenum: 132,
		fling: {
			basePower: 10,
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (pokemon.baseTemplate.species === 'Victini' && move && move.id === 'vcreate' && move.category !== 'Status') {
				pokemon.eatItem();
				if (!pokemon.volatiles['ssvcodfailsafe']) {
					this.boost({atk:2, spa:2, spe:1});
				}
			}
		},
		num: 268,
		gen: 4,
		desc: "Holder's attacks that are super effective against the target do 1.2x damage.",
	},
	"metalpowder": {
		id: "metalpowder",
		name: "Metal Powder",
		fling: {
			basePower: 10,
		},
		spritenum: 287,
		onModifyDefPriority: 2,
		onModifyDef: function (def, pokemon) {
			if (pokemon.template.species === 'Ditto' && !pokemon.transformed) {
				return this.chainModify(2);
			}
		},
		num: 257,
		gen: 2,
		desc: "If holder is a Ditto that hasn't Transformed, its Defense is doubled.",
	},
	"metronome": {
		id: "metronome",
		name: "Metronome",
		spritenum: 289,
		fling: {
			basePower: 30,
		},
		onStart: function (pokemon) {
			pokemon.addVolatile('metronome');
		},
		effect: {
			onStart: function (pokemon) {
				this.effectData.numConsecutive = 0;
				this.effectData.lastMove = '';
			},
			onBeforeMove: function (pokemon, target, move) {
				if (!pokemon.hasItem('metronome')) {
					pokemon.removeVolatile('metronome');
					return;
				}
				if (this.effectData.lastMove === move.id) {
					this.effectData.numConsecutive++;
				} else {
					this.effectData.numConsecutive = 0;
				}
				this.effectData.lastMove = move.id;
			},
			onModifyDamage: function (damage, source, target, move) {
				let numConsecutive = this.effectData.numConsecutive > 5 ? 5 : this.effectData.numConsecutive;
				let dmgMod = [0x1000, 0x1333, 0x1666, 0x1999, 0x1CCC, 0x2000];
				return this.chainModify([dmgMod[numConsecutive], 0x1000]);
			},
		},
		num: 277,
		gen: 4,
		desc: "Damage of moves used on consecutive turns is increased. Max 2x after 5 turns.",
	},
	"mewtwonitex": {
		id: "mewtwonitex",
		name: "Mewtwonite X",
		spritenum: 600,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Mewtwo') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Mewtwo-Mega-X');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Mewtwo') return false;
			return true;
		},
		num: 662,
		gen: 6,
		desc: "If holder is a Mewtwo, this item allows it to Mega Evolve in battle.",
	},
	"mewtwonitey": {
		id: "mewtwonitey",
		name: "Mewtwonite Y",
		spritenum: 601,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Mewtwo') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Mewtwo-Mega-Y');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Mewtwo') return false;
			return true;
		},
		num: 663,
		gen: 6,
		desc: "If holder is a Mewtwo, this item allows it to Mega Evolve in battle.",
	},
	"micleberry": {
		id: "micleberry",
		name: "Micle Berry",
		spritenum: 290,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Rock",
		},
		onResidual: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || pokemon.hasAbility('gluttony')) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			pokemon.addVolatile('micleberry');
		},
		effect: {
			duration: 2,
			onSourceModifyAccuracy: function (accuracy, target, source) {
				this.add('-enditem', source, 'Micle Berry');
				source.removeVolatile('micleberry');
				if (typeof accuracy === 'number') {
					return accuracy * 1.2;
				}
			},
		},
		num: 209,
		gen: 4,
		desc: "Holder's next move has 1.2x accuracy when at 1/4 max HP or less. Single use.",
	},
	"mindplate": {
		id: "mindplate",
		name: "Mind Plate",
		spritenum: 291,
		onPlate: 'Psychic',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Psychic') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Psychic",
		num: 307,
		gen: 4,
		desc: "Holder's Psychic-type attacks have 1.2x power. Judgment is Psychic type.",
	},
	"miracleseed": {
		id: "miracleseed",
		name: "Miracle Seed",
		fling: {
			basePower: 30,
		},
		spritenum: 292,
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Grass') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 239,
		gen: 2,
		desc: "Holder's Grass-type attacks have 1.2x power.",
	},
	"moonball": {
		id: "moonball",
		name: "Moon Ball",
		spritenum: 294,
		num: 498,
		gen: 2,
		desc: "A Poke Ball for catching Pokemon that evolve using the Moon Stone.",
	},
	"muscleband": {
		id: "muscleband",
		name: "Muscle Band",
		spritenum: 297,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.category === 'Physical') {
				return this.chainModify([0x1199, 0x1000]);
			}
		},
		num: 266,
		gen: 4,
		desc: "Holder's physical attacks have 1.1x power.",
	},
	"mysticwater": {
		id: "mysticwater",
		name: "Mystic Water",
		spritenum: 300,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Water') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 243,
		gen: 2,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"nanabberry": {
		id: "nanabberry",
		name: "Nanab Berry",
		spritenum: 302,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Water",
		},
		onHit: function (target, source, move) {
			if (move && move.typeMod > 0) {
				target.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(pokemon.maxhp / 2);
		},
		num: 166,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"nestball": {
		id: "nestball",
		name: "Nest Ball",
		spritenum: 303,
		num: 8,
		gen: 3,
		desc: "A Poke Ball that works especially well on weaker Pokemon in the wild.",
	},
	"netball": {
		id: "netball",
		name: "Net Ball",
		spritenum: 304,
		num: 6,
		gen: 3,
		desc: "A Poke Ball that works especially well on Water- and Bug-type Pokemon.",
	},
	"nevermeltice": {
		id: "nevermeltice",
		name: "Never-Melt Ice",
		spritenum: 305,
		fling: {
			basePower: 30,
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (this.isWeather(['hail']) && (move.category === 'Physical' || move.flags['hitsdef']) && target.hasType('Ice')) {
				this.debug('nevermeltice weaken');
				return this.chainModify(0.67);
			}
		},
		num: 246,
		gen: 2,
		desc: "Holder's Ice-type attacks have 1.2x power.",
	},
	"nomelberry": {
		id: "nomelberry",
		name: "Nomel Berry",
		spritenum: 306,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Dragon",
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move && move.flags['hazard']) {
				pokemon.eatItem();
				pokemon.switchFlag = true;
			}
		},
		num: 178,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"starsweet": {
		id: "starsweet",
		name: "Star Sweet",
		spritenum: 306,
		isBerry: true,
		naturalGift: {
			basePower: 150,
			type: "Dragon",
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move && move.flags['charity'] && !move.flags['charityblock']) {
				pokemon.switchFlag = true;
			}
		},
		num: 178,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"normalgem": {
		id: "normalgem",
		name: "Normal Gem",
		spritenum: 307,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status' || move.id in {firepledge:1, grasspledge:1, waterpledge:1}) return;
			if (move.type === 'Normal') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Normal Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 564,
		gen: 5,
		desc: "Holder's first successful Normal-type attack will have 1.3x power. Single use.",
	},
	"occaberry": {
		id: "occaberry",
		name: "Occa Berry",
		spritenum: 311,
		isBerry: true,
		onBuffer: 'Fire',
		naturalGift: {
			basePower: 80,
			type: "Fire",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Fire' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 184,
		gen: 4,
		desc: "Halves damage taken from a supereffective Fire-type attack. Single use.",
	},
	"oddincense": {
		id: "oddincense",
		name: "Odd Incense",
		spritenum: 312,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (user.hp <= user.maxhp / 4 && move.type === 'Psychic') {
				return this.chainModify([0x2000, 0x1000]);
			}
		},
		num: 314,
		gen: 4,
		desc: "Holder's Psychic-type attacks have 1.2x power.",
	},
	"oldamber": {
		id: "oldamber",
		name: "Old Amber",
		spritenum: 314,
		fling: {
			basePower: 100,
		},
		num: 103,
		gen: 3,
		desc: "Can be revived into Aerodactyl.",
	},
	"oranberry": {
		id: "oranberry",
		name: "Oran Berry",
		spritenum: 319,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Poison",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp < pokemon.maxhp) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(90);
		},
		num: 155,
		gen: 3,
		desc: "Restores 10 HP when at 1/1.43 max HP or less. Single use.",
	},
	"pamtreberry": {
		id: "pamtreberry",
		name: "Pamtre Berry",
		spritenum: 323,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Steel",
		},
		num: 180,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"parkball": {
		id: "parkball",
		name: "Park Ball",
		spritenum: 325,
		num: 500,
		gen: 2,
		desc: "A special Poke Ball for the Pal Park.",
	},
	"passhoberry": {
		id: "passhoberry",
		name: "Passho Berry",
		spritenum: 329,
		isBerry: true,
		onBuffer: 'Water',
		naturalGift: {
			basePower: 80,
			type: "Water",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Water' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 185,
		gen: 4,
		desc: "Halves damage taken from a supereffective Water-type attack. Single use.",
	},
	"payapaberry": {
		id: "payapaberry",
		name: "Payapa Berry",
		spritenum: 330,
		isBerry: true,
		onBuffer: 'Psychic',
		naturalGift: {
			basePower: 80,
			type: "Psychic",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Psychic' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 193,
		gen: 4,
		desc: "Halves damage taken from a supereffective Psychic-type attack. Single use.",
	},
	"pechaberry": {
		id: "pechaberry",
		name: "Pecha Berry",
		spritenum: 333,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Electric",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'psn' || pokemon.status === 'tox') {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			if (pokemon.status === 'psn' || pokemon.status === 'tox') {
				pokemon.cureStatus();
			}
		},
		num: 151,
		gen: 3,
		desc: "Holder is cured if it is poisoned. Single use.",
	},
	"persimberry": {
		id: "persimberry",
		name: "Persim Berry",
		spritenum: 334,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Ground",
		},
		onUpdate: function (pokemon) {
			if (pokemon.volatiles['confusion']) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			pokemon.removeVolatile('confusion');
		},
		num: 156,
		gen: 3,
		desc: "Holder is cured if it is confused. Single use.",
	},
	"petayaberry": {
		id: "petayaberry",
		name: "Petaya Berry",
		spritenum: 335,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Poison",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || pokemon.hasAbility('gluttony')) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			this.boost({spa:1});
		},
		num: 204,
		gen: 3,
		desc: "Raises holder's Sp. Atk by 1 stage when at 1/4 max HP or less. Single use.",
	},
	"pidgeotite": {
		id: "pidgeotite",
		name: "Pidgeotite",
		spritenum: 622,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Pidgeot') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Pidgeot-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Pidgeot') return false;
			return true;
		},
		num: 762,
		gen: 6,
		desc: "If holder is a Pidgeot, this item allows it to Mega Evolve in battle.",
	},
	"pinapberry": {
		id: "pinapberry",
		name: "Pinap Berry",
		spritenum: 337,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Grass",
		},
		onResidualOrder: 99,
		onResidualSubOrder: 6,
		onResidual: function (pokemon) {
			if (!pokemon.hasAbility('windstreamer') && pokemon.volatiles['tailwindflag'] && !pokemon.volatiles['tailwindcheck'] && pokemon.side.sideConditions['tailwind']) {
				pokemon.eatItem();
				this.add('-message', "" + pokemon.name + "'s Pinap Berry is reacting to Tailwind!");
				pokemon.switchFlag = true;
			}
		},
		num: 168,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"pinsirite": {
		id: "pinsirite",
		name: "Pinsirite",
		spritenum: 602,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Pinsir') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Pinsir-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Pinsir') return false;
			return true;
		},
		num: 671,
		gen: 6,
		desc: "If holder is a Pinsir, this item allows it to Mega Evolve in battle.",
	},
	"pixieplate": {
		id: "pixieplate",
		name: "Pixie Plate",
		spritenum: 610,
		onPlate: 'Fairy',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Fairy') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Fairy",
		num: -6,
		gen: 6,
		desc: "Holder's Fairy-type attacks have 1.2x power. Judgment is Fairy type.",
	},
	"plumefossil": {
		id: "plumefossil",
		name: "Plume Fossil",
		spritenum: 339,
		fling: {
			basePower: 100,
		},
		num: 573,
		gen: 5,
		desc: "Can be revived into Archen.",
	},
	"poisonbarb": {
		id: "poisonbarb",
		name: "Poison Barb",
		spritenum: 343,
		fling: {
			basePower: 70,
			status: 'psn',
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Poison') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 245,
		gen: 2,
		desc: "Holder's Poison-type attacks have 1.2x power.",
	},
	"poisongem": {
		id: "poisongem",
		name: "Poison Gem",
		spritenum: 344,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Poison') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Poison Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 554,
		gen: 5,
		desc: "Holder's first successful Poison-type attack will have 1.3x power. Single use.",
	},
	"pokeball": {
		id: "pokeball",
		name: "Poke Ball",
		spritenum: 345,
		num: 4,
		gen: 1,
		desc: "A device for catching wild Pokemon. It is designed as a capsule system.",
	},
	"pomegberry": {
		id: "pomegberry",
		name: "Pomeg Berry",
		spritenum: 351,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Ice",
		},
		num: 169,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"powerherb": {
		id: "powerherb",
		onChargeMove: function (pokemon, target, move) {
			if (pokemon.useItem()) {
				this.debug('power herb - remove charge turn for ' + move.id);
				return false; // skip charge turn
			}
		},
		name: "Power Herb",
		spritenum: 358,
		fling: {
			basePower: 10,
		},
		num: 271,
		gen: 4,
		desc: "Holder's two-turn moves complete in one turn (except Sky Drop). Single use.",
	},
	"premierball": {
		id: "premierball",
		name: "Premier Ball",
		spritenum: 363,
		num: 12,
		gen: 3,
		desc: "A rare Poke Ball that has been crafted to commemorate an event.",
	},
	"psychicgem": {
		id: "psychicgem",
		name: "Psychic Gem",
		spritenum: 369,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Psychic') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Psychic Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 557,
		gen: 5,
		desc: "Holder's first successful Psychic-type attack will have 1.3x power. Single use.",
	},
	"qualotberry": {
		id: "qualotberry",
		name: "Qualot Berry",
		spritenum: 371,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Poison",
		},
		num: 171,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"quickball": {
		id: "quickball",
		name: "Quick Ball",
		spritenum: 372,
		num: 15,
		gen: 4,
		desc: "A Poke Ball that provides a better catch rate at the start of a wild encounter.",
	},
	"quickclaw": {
		id: "quickclaw",
		onModifyPriority: function (priority, pokemon) {
			if (this.random(5) === 0) {
				this.add('-activate', pokemon, 'item: Quick Claw');
				return priority + 0.1;
			}
		},
		name: "Quick Claw",
		spritenum: 373,
		fling: {
			basePower: 80,
		},
		num: 217,
		gen: 2,
		desc: "Each turn, holder has a 20% chance to move first in its priority bracket.",
	},
	"quickpowder": {
		id: "quickpowder",
		name: "Quick Powder",
		spritenum: 374,
		fling: {
			basePower: 10,
		},
		onModifySpe: function (spe, pokemon) {
			if (pokemon.template.species === 'Ditto' && !pokemon.transformed) {
				return this.chainModify(2);
			}
		},
		num: 274,
		gen: 4,
		desc: "If holder is a Ditto that hasn't Transformed, its Speed is doubled.",
	},
	"rabutaberry": {
		id: "rabutaberry",
		name: "Rabuta Berry",
		spritenum: 375,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Ghost",
		},
		num: 177,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"rarebone": {
		id: "rarebone",
		name: "Rare Bone",
		spritenum: 379,
		fling: {
			basePower: 100,
		},
		num: 106,
		gen: 4,
		desc: "No competitive use other than when used with Fling.",
	},
	"rawstberry": {
		id: "rawstberry",
		name: "Rawst Berry",
		spritenum: 381,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Grass",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'brn') {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			if (pokemon.status === 'brn') {
				pokemon.cureStatus();
			}
		},
		num: 152,
		gen: 3,
		desc: "Holder is cured if it is burned. Single use.",
	},
	"razorclaw": {
		id: "razorclaw",
		name: "Razor Claw",
		spritenum: 382,
		fling: {
			basePower: 80,
		},
		onModifyMove: function (move) {
			move.critRatio++;
		},
		num: 326,
		gen: 4,
		desc: "Holder's critical hit ratio is raised by 1 stage.",
	},
	"razorfang": {
		id: "razorfang",
		name: "Razor Fang",
		spritenum: 383,
		fling: {
			basePower: 30,
			volatileStatus: 'flinch',
		},
		onModifyMovePriority: -1,
		onModifyMove: function (move) {
			if (move.category !== "Status") {
				if (!move.secondaries) move.secondaries = [];
				for (let i = 0; i < move.secondaries.length; i++) {
					if (move.secondaries[i].volatileStatus === 'flinch') return;
				}
				move.secondaries.push({
					chance: 10,
					volatileStatus: 'flinch',
				});
			}
		},
		num: 327,
		gen: 4,
		desc: "Holder's attacks without a chance to flinch gain a 10% chance to flinch.",
	},
	"razzberry": {
		id: "razzberry",
		name: "Razz Berry",
		spritenum: 384,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Steel",
		},
		num: 164,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"redcard": {
		id: "redcard",
		name: "Red Card",
		spritenum: 387,
		fling: {
			basePower: 10,
		},
		onAfterMoveSecondary: function (target, source, move) {
			if (source && source !== target && source.hp && target.hp && move && move.category !== 'Status') {
				if (!source.isActive || !this.canSwitch(source.side) || target.forceSwitchFlag) return;
				if (target.useItem(null, source)) { // This order is correct - the item is used up even against a pokemon with Ingrain or that otherwise can't be forced out
					if (this.runEvent('DragOut', source, target, move)) {
						this.dragIn(source.side, source.position);
					}
				}
			}
		},
		num: 542,
		gen: 5,
		desc: "If holder is hit, it forces the attacker to switch to a random ally. Single use.",
	},
	"redorb": {
		id: "redorb",
		name: "Red Orb",
		spritenum: 390,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Groudon') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Groudon-Primal');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-primal', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Groudon') return false;
			return true;
		},
		num: -6,
		gen: 6,
		desc: "If holder is a Groudon, this item triggers its Primal Reversion in battle.",
	},
	"repeatball": {
		id: "repeatball",
		name: "Repeat Ball",
		spritenum: 401,
		num: 9,
		gen: 3,
		desc: "A Poke Ball that works well on Pokemon species that were previously caught.",
	},
	"rindoberry": {
		id: "rindoberry",
		name: "Rindo Berry",
		spritenum: 409,
		isBerry: true,
		onBuffer: 'Grass',
		naturalGift: {
			basePower: 80,
			type: "Grass",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Grass' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 187,
		gen: 4,
		desc: "Halves damage taken from a supereffective Grass-type attack. Single use.",
	},
	"ringtarget": {
		id: "ringtarget",
		name: "Ring Target",
		spritenum: 410,
		fling: {
			basePower: 10,
		},
		onNegateImmunity: function (pokemon, type) {
			if (type in this.data.TypeChart && this.runEvent('Immunity', pokemon, null, null, type)) return false;
		},
		num: 543,
		gen: 5,
		desc: "The holder's type immunities granted solely by its typing are negated.",
	},
	"rockgem": {
		id: "rockgem",
		name: "Rock Gem",
		spritenum: 415,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Rock') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Rock Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 559,
		gen: 5,
		desc: "Holder's first successful Rock-type attack will have 1.3x power. Single use.",
	},
	"rockincense": {
		id: "rockincense",
		name: "Rock Incense",
		spritenum: 416,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Rock') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onEffectiveness: function (typeMod, target, type, move) {
			if (this.isWeather(['sandstorm']) && move && move.effectType === 'Move' && type === 'Rock' && typeMod > 0) {
				this.add('-activate', '', 'rockincense');
				return 0;
			}
		},
		num: 315,
		gen: 4,
		desc: "Holder's Rock-type attacks have 1.2x power.",
	},
	"bottlecap": {
		id: "bottlecap",
		name: "Bottle Cap",
		spritenum: 430,
		fling: {
			basePower: 10,
		},
		onSwitchIn: function (pokemon) {
			if (pokemon.useItem()) {
				this.boost({def:-1, spd:-1, atk:-1, spa:-1, spe:-1});
			}
		},
		num: 254,
		gen: 3,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"goldbottlecap": {
		id: "goldbottlecap",
		name: "Gold Bottle Cap",
		spritenum: 430,
		fling: {
			basePower: 10,
		},
		onUpdate: function (pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland']) && (pokemon.hasType('Fire') || pokemon.hasType('Ground') || pokemon.hasType('Grass'))) {
				if (pokemon.useItem()) {
					this.boost({atk:1});
					if (!pokemon.volatiles['goldbottlecap']) {
						pokemon.addVolatile('goldbottlecap');
					} else {
						pokemon.addVolatile('goldbottlecapx');
					}
				}
			}
		},
		num: 254,
		gen: 3,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"flowersweet": {
		id: "flowersweet",
		name: "Flower Sweet",
		spritenum: 430,
		fling: {
			basePower: 10,
		},
		onSwitchIn: function (pokemon) {
			if (pokemon.hasType('Grass') && (!pokemon.hasType('Bug') && !pokemon.hasType('Dark') && !pokemon.hasType('Dragon') && !pokemon.hasType('Electric') && !pokemon.hasType('Fairy') && !pokemon.hasType('Fighting') && !pokemon.hasType('Fire') && !pokemon.hasType('Flying') && !pokemon.hasType('Ghost') && !pokemon.hasType('Ground') && !pokemon.hasType('Ice') && !pokemon.hasType('Normal') && !pokemon.hasType('Poison') && !pokemon.hasType('Psychic') && !pokemon.hasType('Rock') && !pokemon.hasType('Steel') && !pokemon.hasType('Water'))) {
				this.boost({def:1, spd:1});
				if (!pokemon.volatiles['hanafactor']) {
					pokemon.addVolatile('hanafactor');
				}
			}
		},
		num: 254,
		gen: 3,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"sweetapple": {
		id: "sweetapple",
		name: "Sweet Apple",
		spritenum: 430,
		fling: {
			basePower: 10,
		},
		onSwitchOut: function (pokemon) {
			if (!pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 5);
			}
		},
		num: 954,
		gen: 3,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"tartapple": {
		id: "tartapple",
		name: "Tart Apple",
		spritenum: 430,
		fling: {
			basePower: 10,
		},
		onSwitchOut: function (pokemon) {
			if (pokemon.hp > pokemon.maxhp / 4 && !pokemon.hasType('Ghost')) {
				this.damage(pokemon.maxhp / 4);
			}
		},
		num: 954,
		gen: 3,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"syrupyapple": {
		id: "syrupyapple",
		name: "Syrupy Apple",
		spritenum: 430,
		fling: {
			basePower: 10,
		},
		onModifyDamage: function (damage, source, target, move) {
			if (move && move.typeMod > 0) {
				source.addVolatile('typemodstrong');
			}
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (pokemon.hp >= pokemon.maxhp || !pokemon.volatiles['typemodstrong']) return;
			if (!pokemon.volatiles['syrupfactor']) {
				this.heal(Math.ceil(pokemon.maxhp * 0.35), pokemon);
				pokemon.addVolatile('syrupfactor');
			} else if (pokemon.volatiles['syrupfactor'].layers < 2) {
				this.heal(Math.ceil(pokemon.maxhp * 0.25), pokemon);
				pokemon.addVolatile('syrupfactor');
			} else if (pokemon.volatiles['syrupfactor'].layers < 3) {
				this.heal(Math.ceil(pokemon.maxhp * 0.20), pokemon);
				pokemon.addVolatile('syrupfactor');
			} else if (pokemon.volatiles['syrupfactor'].layers >= 3) {
				this.heal(Math.ceil(pokemon.maxhp * 0.15), pokemon);
				pokemon.addVolatile('syrupfactor');
			}
		},
		num: 954,
		gen: 3,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"roomservice": {
		id: "roomservice",
		name: "Room Service",
		spritenum: 419,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === '???') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onSwitchIn: function (pokemon) {
			if (!pokemon.side.sideConditions['serviceprotect']) {
				pokemon.side.addSideCondition('serviceprotect');
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (this.isWeather(['raindance', 'primordialsea', 'sunnyday', 'desolateland', 'sandstorm', 'hail']) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 8);
			}
		},
		num: 318,
		gen: 4,
		desc: "Holder's Grass-type attacks have 1.2x power.",
	},
	"rockyhelmet": {
		id: "rockyhelmet",
		name: "Rocky Helmet",
		spritenum: 417,
		fling: {
			basePower: 60,
		},
		onAfterDamageOrder: 2,
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.flags['contact']) {
				this.damage(source.maxhp / 6, source, target, null, true);
			}
		},
		num: 540,
		gen: 5,
		desc: "If holder is hit by a contact move, the attacker loses 1/6 of its max HP.",
	},
	"rootfossil": {
		id: "rootfossil",
		name: "Root Fossil",
		spritenum: 418,
		fling: {
			basePower: 100,
		},
		num: 99,
		gen: 3,
		desc: "Can be revived into Lileep.",
	},
	"roseincense": {
		id: "roseincense",
		name: "Rose Incense",
		spritenum: 419,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Grass') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (this.isWeather(['raindance', 'primordialsea']) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 5);
			} else if (this.isWeather(['sunnyday', 'desolateland', 'hail'])) {
				this.damage(pokemon.maxhp / 6);
			}
		},
		num: 318,
		gen: 4,
		desc: "Holder's Grass-type attacks have 1.2x power.",
	},
	"roseliberry": {
		id: "roseliberry",
		name: "Roseli Berry",
		spritenum: 603,
		isBerry: true,
		onBuffer: 'Fairy',
		naturalGift: {
			basePower: 80,
			type: "Fairy",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Fairy' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: -6,
		gen: 6,
		desc: "Halves damage taken from a supereffective Fairy-type attack. Single use.",
	},
	"rowapberry": {
		id: "rowapberry",
		name: "Rowap Berry",
		spritenum: 420,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Dark",
		},
		onAfterDamage: function (damage, target, source, move) {
			if (source && source !== target && move && move.category === 'Special') {
				if (target.eatItem()) {
					this.damage(source.maxhp / 8, source, target, null, true);
				}
			}
		},
		onEat: function () { },
		num: 212,
		gen: 4,
		desc: "If holder is hit by a special move, attacker loses 1/8 of its max HP. Single use.",
	},
	"sablenite": {
		id: "sablenite",
		name: "Sablenite",
		spritenum: 614,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Sableye') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Sableye-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Sableye') return false;
			return true;
		},
		num: 754,
		gen: 6,
		desc: "If holder is a Sableye, this item allows it to Mega Evolve in battle.",
	},
	"safariball": {
		id: "safariball",
		name: "Safari Ball",
		spritenum: 425,
		num: 5,
		gen: 1,
		desc: "A special Poke Ball that is used only in the Safari Zone and Great Marsh.",
	},
	"safetygoggles": {
		id: "safetygoggles",
		name: "Safety Goggles",
		spritenum: 604,
		fling: {
			basePower: 80,
		},
		onImmunity: function (type, pokemon) {
			if (type === 'sandstorm' || type === 'hail' || type === 'powder') return false;
		},
		onTryHit: function (pokemon, source, move) {
			if (move.flags['powder'] && move.id !== 'ragepowder') {
				this.add('-activate', pokemon, 'Safety Goggles', move.name);
				return null;
			}
		},
		num: -6,
		gen: 6,
		desc: "Holder is immune to powder moves and damage from Sandstorm or Hail.",
	},
	"salacberry": {
		id: "salacberry",
		name: "Salac Berry",
		spritenum: 426,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Fighting",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || pokemon.hasAbility('gluttony')) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			this.boost({spe:1});
		},
		num: 203,
		gen: 3,
		desc: "Raises holder's Speed by 1 stage when at 1/4 max HP or less. Single use.",
	},
	"salamencite": {
		id: "salamencite",
		name: "Salamencite",
		spritenum: 627,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Salamence') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Salamence-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Salamence') return false;
			return true;
		},
		num: 769,
		gen: 6,
		desc: "If holder is a Salamence, this item allows it to Mega Evolve in battle.",
	},
	"sceptilite": {
		id: "sceptilite",
		name: "Sceptilite",
		spritenum: 613,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Sceptile') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Sceptile-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Sceptile') return false;
			return true;
		},
		num: 753,
		gen: 6,
		desc: "If holder is a Sceptile, this item allows it to Mega Evolve in battle.",
	},
	"scizorite": {
		id: "scizorite",
		name: "Scizorite",
		spritenum: 605,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Scizorite') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Scizorite-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Scizorite') return false;
			return true;
		},
		num: 670,
		gen: 6,
		desc: "If holder is a Scizor, this item allows it to Mega Evolve in battle.",
	},
	"scopelens": {
		id: "scopelens",
		name: "Scope Lens",
		spritenum: 429,
		fling: {
			basePower: 30,
		},
		onModifyMove: function (move) {
			move.critRatio++;
		},
		num: 232,
		gen: 2,
		desc: "Holder's critical hit ratio is raised by 1 stage.",
	},
	"seaincense": {
		id: "seaincense",
		name: "Sea Incense",
		spritenum: 430,
		fling: {
			basePower: 10,
		},
		onBeforeMove: function (pokemon) {
			if (!this.isWeather(['raindance', 'primordialsea'])) {
				if (!pokemon.volatiles['seaincenserainpre']) {
					pokemon.addVolatile('seaincenserainpre');
				} else {
					pokemon.addVolatile('seaincenserainprex');
				}
			}
		},
		onUpdate: function (pokemon) {
			if (!pokemon.side.sideConditions['assiststart'] && (this.isWeather(['raindance', 'primordialsea']) && pokemon.hasType('Water'))) {
				if (pokemon.useItem()) {
					this.boost({spe:1});
					if (!pokemon.volatiles['seaincenselimit']) {
						pokemon.addVolatile('seaincenselimit');
					} else {
						pokemon.addVolatile('seaincenselimitx');
					}
				}
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Water') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 254,
		gen: 3,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"sharpbeak": {
		id: "sharpbeak",
		name: "Sharp Beak",
		spritenum: 436,
		fling: {
			basePower: 50,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Flying') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 244,
		gen: 2,
		desc: "Holder's Flying-type attacks have 1.2x power.",
	},
	"sharpedonite": {
		id: "sharpedonite",
		name: "Sharpedonite",
		spritenum: 619,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Sharpedo') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Sharpedo-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Sharpedo') return false;
			return true;
		},
		num: 759,
		gen: 6,
		desc: "If holder is a Sharpedo, this item allows it to Mega Evolve in battle.",
	},
	"shedshell": {
		id: "shedshell",
		name: "Shed Shell",
		spritenum: 437,
		fling: {
			basePower: 10,
		},
		onTrapPokemonPriority: -10,
		onTrapPokemon: function (pokemon) {
			if (!pokemon.volatiles['setuptrapped']) {
				pokemon.trapped = pokemon.maybeTrapped = false;
			}
		},
		num: 295,
		gen: 4,
		desc: "Holder may switch out even when trapped by another Pokemon, or by Ingrain.",
	},
	"shellbell": {
		id: "shellbell",
		name: "Shell Bell",
		spritenum: 438,
		fling: {
			basePower: 30,
		},
		onAfterMoveSecondarySelfPriority: -1,
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (move.category !== 'Status' && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.lastDamage / 5, pokemon);
			}
		},
		num: 253,
		gen: 3,
		desc: "After an attack, holder gains 1/3 of the damage in HP dealt to other Pokemon.",
	},
	"shockdrive": {
		id: "shockdrive",
		name: "Shock Drive",
		spritenum: 442,
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 649) || pokemon.baseTemplate.num === 649) {
				return false;
			}
			return true;
		},
		onDrive: 'Electric',
		forcedForme: "Genesect-Shock",
		num: 117,
		gen: 5,
		desc: "Holder's Techno Blast is Electric type.",
	},
	"shucaberry": {
		id: "shucaberry",
		name: "Shuca Berry",
		spritenum: 443,
		isBerry: true,
		onBuffer: 'Ground',
		naturalGift: {
			basePower: 80,
			type: "Ground",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Ground' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 191,
		gen: 4,
		desc: "Halves damage taken from a supereffective Ground-type attack. Single use.",
	},
	"silkscarf": {
		id: "silkscarf",
		name: "Silk Scarf",
		spritenum: 444,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Normal') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 251,
		gen: 3,
		desc: "Holder's Normal-type attacks have 1.2x power.",
	},
	"silverpowder": {
		id: "silverpowder",
		name: "SilverPowder",
		spritenum: 447,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Bug') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (!pokemon.hasAbility('hyperspeed')) {
				this.heal(25);
			}
		},
		num: 222,
		gen: 2,
		desc: "Holder's Bug-type attacks have 1.2x power.",
	},
	"sitrusberry": {
		id: "sitrusberry",
		name: "Sitrus Berry",
		spritenum: 448,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Psychic",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(pokemon.maxhp / 1.33333333);
		},
		num: 158,
		gen: 3,
		desc: "Restores 1/4 max HP when at 1/2 max HP or less. Single use.",
	},
	"whippeddream": {
		id: "whippeddream",
		name: "Whipped Dream",
		spritenum: 448,
		naturalGift: {
			basePower: 80,
			type: "Fairy",
		},
		onSwitchIn: function (pokemon) {
			if (pokemon.hp > pokemon.maxhp / 2) {
				this.damage(pokemon.maxhp / 2);
			}
		},
		num: 158,
		gen: 3,
		desc: "Restores 1/4 max HP when at 1/2 max HP or less. Single use.",
	},
	"skullfossil": {
		id: "skullfossil",
		name: "Skull Fossil",
		spritenum: 449,
		fling: {
			basePower: 100,
		},
		num: 105,
		gen: 4,
		desc: "Can be revived into Cranidos.",
	},
	"skyplate": {
		id: "skyplate",
		name: "Sky Plate",
		spritenum: 450,
		onPlate: 'Flying',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Flying') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Flying",
		num: 306,
		gen: 4,
		desc: "Holder's Flying-type attacks have 1.2x power. Judgment is Flying type.",
	},
	"slowbronite": {
		id: "slowbronite",
		name: "Slowbronite",
		spritenum: 620,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Slowbro') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Slowbro-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Slowbro') return false;
			return true;
		},
		num: 760,
		gen: 6,
		desc: "If holder is a Slowbro, this item allows it to Mega Evolve in battle.",
	},
	"smoothrock": {
		id: "smoothrock",
		name: "Smooth Rock",
		spritenum: 453,
		fling: {
			basePower: 10,
		},
		num: 283,
		gen: 4,
		desc: "Holder's use of Sandstorm lasts 8 turns instead of 5.",
	},
	"snowball": {
		id: "snowball",
		name: "Snowball",
		spritenum: 606,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Ice') {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (!pokemon.hasAbility('spacepower') && !pokemon.volatiles['proice']) {
				pokemon.trySetStatus('frz', pokemon);
			}
		},
		num: -6,
		gen: 6,
		desc: "Raises holder's Attack by 1 if hit by an Ice-type attack. Single use.",
	},
	"softsand": {
		id: "softsand",
		name: "Soft Sand",
		spritenum: 456,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Ground') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 237,
		gen: 2,
		desc: "Holder's Ground-type attacks have 1.2x power.",
	},
	"souldew": {
		id: "souldew",
		name: "Soul Dew",
		spritenum: 459,
		fling: {
			basePower: 30,
		},
		onModifySpAPriority: 1,
		onModifySpA: function (spa, pokemon) {
			if (pokemon.baseTemplate.num === 380 || pokemon.baseTemplate.num === 381) {
				return this.chainModify(1.3);
			}
		},
		onModifySpDPriority: 2,
		onModifySpD: function (spd, pokemon) {
			if (pokemon.baseTemplate.num === 380 || pokemon.baseTemplate.num === 381) {
				return this.chainModify(1.3);
			}
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && (user.baseTemplate.species === 'Mesprit' || user.baseTemplate.species === 'Uxie' || user.baseTemplate.species === 'Azelf')) {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		num: 225,
		gen: 3,
		desc: "If holder is a Latias or a Latios, its Sp. Atk and Sp. Def are 1.5x.",
	},
	"spelltag": {
		id: "spelltag",
		name: "Spell Tag",
		spritenum: 461,
		fling: {
			basePower: 30,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Ghost') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		num: 247,
		gen: 2,
		desc: "Holder's Ghost-type attacks have 1.2x power.",
	},
	"spelonberry": {
		id: "spelonberry",
		name: "Spelon Berry",
		spritenum: 462,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Dark",
		},
		num: 179,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"splashplate": {
		id: "splashplate",
		name: "Splash Plate",
		spritenum: 463,
		onPlate: 'Water',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Water') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Water",
		num: 299,
		gen: 4,
		desc: "Holder's Water-type attacks have 1.2x power. Judgment is Water type.",
	},
	"spookyplate": {
		id: "spookyplate",
		name: "Spooky Plate",
		spritenum: 464,
		onPlate: 'Ghost',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Ghost') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Ghost",
		num: 310,
		gen: 4,
		desc: "Holder's Ghost-type attacks have 1.2x power. Judgment is Ghost type.",
	},
	"sportball": {
		id: "sportball",
		name: "Sport Ball",
		spritenum: 465,
		num: 499,
		gen: 4,
		desc: "A special Poke Ball for the Bug-Catching Contest.",
	},
	"starfberry": {
		id: "starfberry",
		name: "Starf Berry",
		spritenum: 472,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Psychic",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 4 || pokemon.hasAbility('gluttony')) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			let stats = [];
			for (let stat in pokemon.boosts) {
				if (stat !== 'accuracy' && stat !== 'evasion' && pokemon.boosts[stat] < 6) {
					stats.push(stat);
				}
			}
			if (stats.length) {
				let randomStat = stats[this.random(stats.length)];
				let boost = {};
				boost[randomStat] = 2;
				this.boost(boost);
			}
		},
		num: 207,
		gen: 3,
		desc: "Raises a random stat by 2 when at 1/4 max HP or less (not acc/eva). Single use.",
	},
	"steelixite": {
		id: "steelixite",
		name: "Steelixite",
		spritenum: 621,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Steelix') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Steelix-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Steelix') return false;
			return true;
		},
		num: 761,
		gen: 6,
		desc: "If holder is a Steelix, this item allows it to Mega Evolve in battle.",
	},
	"steelgem": {
		id: "steelgem",
		name: "Steel Gem",
		spritenum: 473,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status') return;
			if (move.type === 'Steel') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Steel Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 563,
		gen: 5,
		desc: "Holder's first successful Steel-type attack will have 1.3x power. Single use.",
	},
	"stick": {
		id: "stick",
		name: "Stick",
		fling: {
			basePower: 60,
		},
		spritenum: 475,
		onModifyMove: function (move, user) {
			if (user.baseTemplate.species === 'Farfetch\'d') {
				move.critRatio += 2;
			}
		},
		num: 259,
		gen: 2,
		desc: "If holder is a Farfetch'd, its critical hit ratio is raised by 2 stages.",
	},
	"stickybarb": {
		id: "stickybarb",
		name: "Sticky Barb",
		spritenum: 476,
		fling: {
			basePower: 80,
		},
		onResidualOrder: 26,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			this.damage(pokemon.maxhp / 8);
		},
		onHit: function (target, source, move) {
			if (source && source !== target && !source.item && move && move.flags['contact']) {
				let barb = target.takeItem();
				source.setItem(barb);
				// no message for Sticky Barb changing hands
			}
		},
		num: 288,
		gen: 4,
		desc: "Each turn, holder loses 1/8 max HP. An attacker making contact can receive it.",
	},
	"stoneplate": {
		id: "stoneplate",
		name: "Stone Plate",
		spritenum: 477,
		onPlate: 'Rock',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Rock') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Rock",
		num: 309,
		gen: 4,
		desc: "Holder's Rock-type attacks have 1.2x power. Judgment is Rock type.",
	},
	"swampertite": {
		id: "swampertite",
		name: "Swampertite",
		spritenum: 612,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Swampert') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Swampert-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Swampert') return false;
			return true;
		},
		num: 752,
		gen: 6,
		desc: "If holder is a Swampert, this item allows it to Mega Evolve in battle.",
	},
	"tamatoberry": {
		id: "tamatoberry",
		name: "Tamato Berry",
		spritenum: 486,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Psychic",
		},
		num: 174,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"tangaberry": {
		id: "tangaberry",
		name: "Tanga Berry",
		spritenum: 487,
		isBerry: true,
		onBuffer: 'Bug',
		naturalGift: {
			basePower: 80,
			type: "Bug",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Bug' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 194,
		gen: 4,
		desc: "Halves damage taken from a supereffective Bug-type attack. Single use.",
	},
	"thickclub": {
		id: "thickclub",
		name: "Thick Club",
		spritenum: 491,
		fling: {
			basePower: 90,
		},
		onModifyAtkPriority: 1,
		onModifyAtk: function (atk, pokemon) {
			if (pokemon.baseTemplate.species === 'Cubone' || pokemon.baseTemplate.species === 'Marowak') {
				return this.chainModify(2);
			}
		},
		num: 258,
		gen: 2,
		desc: "If holder is a Cubone or a Marowak, its Attack is doubled.",
	},
	"timerball": {
		id: "timerball",
		name: "Timer Ball",
		spritenum: 494,
		num: 10,
		gen: 3,
		desc: "A Poke Ball that becomes better the more turns there are in a battle.",
	},
	"toxicorb": {
		id: "toxicorb",
		name: "Toxic Orb",
		spritenum: 515,
		fling: {
			basePower: 30,
			status: 'tox',
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === 'Poison') {
				return this.chainModify([0x1800, 0x1000]);
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (!pokemon.hasAbility('spacepower') && !pokemon.volatiles['propoison']) {
				pokemon.trySetStatus('tox', pokemon);
			}
		},
		num: 272,
		gen: 4,
		desc: "At the end of every turn, this item attempts to badly poison the holder.",
	},
	"toxicplate": {
		id: "toxicplate",
		name: "Toxic Plate",
		spritenum: 516,
		onPlate: 'Poison',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Poison') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Poison",
		num: 304,
		gen: 4,
		desc: "Holder's Poison-type attacks have 1.2x power. Judgment is Poison type.",
	},
	"twistedspoon": {
		id: "twistedspoon",
		name: "TwistedSpoon",
		spritenum: 520,
		noRecycle: true,
		fling: {
			basePower: 90,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Psychic') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onAfterMoveSecondarySelf: function (pokemon, target, move) {
			if (pokemon.baseTemplate.species === 'Mewtwo' && move && move.category === 'Status' && !pokemon.volatiles['mewtwoboost']) {
				pokemon.eatItem();
				this.boost({spe:2});
				if (!pokemon.volatiles['mewtwoboost']) {
					pokemon.addVolatile('mewtwoboost');
				}
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 150) || pokemon.baseTemplate.num === 150) {
				return false;
			}
			return true;
		},
		num: 248,
		gen: 2,
		desc: "Holder's Psychic-type attacks have 1.2x power.",
	},
	"tyranitarite": {
		id: "tyranitarite",
		name: "Tyranitarite",
		spritenum: 607,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Tyranitar') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Tyranitar-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Tyranitar') return false;
			return true;
		},
		num: 669,
		gen: 6,
		desc: "If holder is a Tyranitar, this item allows it to Mega Evolve in battle.",
	},
	"ultraball": {
		id: "ultraball",
		name: "Ultra Ball",
		spritenum: 521,
		num: 2,
		gen: 1,
		desc: "An ultra-performance Ball that provides a higher catch rate than a Great Ball.",
	},
	"venusaurite": {
		id: "venusaurite",
		name: "Venusaurite",
		spritenum: 608,
		onSwitchIn: function (pokemon) {
			if (pokemon.isActive && pokemon.baseTemplate.species === 'Venusaur') {
				this.insertQueue({pokemon: pokemon, choice: 'runPrimal'});
			}
		},
		onPrimal: function (pokemon) {
			let template = this.getTemplate('Venusaur-Mega');
			pokemon.formeChange(template);
			pokemon.baseTemplate = template;
			pokemon.details = template.species + (pokemon.level === 100 ? '' : ', L' + pokemon.level) + (pokemon.gender === '' ? '' : ', ' + pokemon.gender) + (pokemon.set.shiny ? ', shiny' : '');
			this.add('detailschange', pokemon, pokemon.details);
			this.add('-mega', pokemon);
			pokemon.setAbility(template.abilities['0']);
			pokemon.baseAbility = pokemon.ability;
		},
		onTakeItem: function (item, source) {
			if (source.baseTemplate.baseSpecies === 'Venusaur') return false;
			return true;
		},
		num: 659,
		gen: 6,
		desc: "If holder is a Venusaur, this item allows it to Mega Evolve in battle.",
	},
	"wacanberry": {
		id: "wacanberry",
		name: "Wacan Berry",
		spritenum: 526,
		isBerry: true,
		onBuffer: 'Electric',
		naturalGift: {
			basePower: 80,
			type: "Electric",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Electric' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 186,
		gen: 4,
		desc: "Halves damage taken from a supereffective Electric-type attack. Single use.",
	},
	"watergem": {
		id: "watergem",
		name: "Water Gem",
		spritenum: 528,
		isGem: true,
		onSourceTryPrimaryHit: function (target, source, move) {
			if (target === source || move.category === 'Status' || move.id in {firepledge:1, grasspledge:1, waterpledge:1}) return;
			if (move.type === 'Water') {
				if (source.useItem()) {
					this.add('-enditem', source, 'Water Gem', '[from] gem', '[move] ' + move.name);
					source.addVolatile('gem');
				}
			}
		},
		num: 549,
		gen: 5,
		desc: "Holder's first successful Water-type attack will have 1.3x power. Single use.",
	},
	"watmelberry": {
		id: "watmelberry",
		name: "Watmel Berry",
		spritenum: 530,
		isBerry: true,
		naturalGift: {
			basePower: 100,
			type: "Fire",
		},
		num: 181,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"waveincense": {
		id: "waveincense",
		name: "Wave Incense",
		spritenum: 531,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Water') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onModifyAtkPriority: 5,
		onModifyAtk: function (atk, attacker, defender, move) {
			if (this.isWeather(['raindance', 'primordialsea']) && move && move.type === 'Water') {
				this.debug('Wave Incense boost');
				return this.chainModify(1.2);
			}
		},
		onModifySpAPriority: 5,
		onModifySpA: function (atk, attacker, defender, move) {
			if (this.isWeather(['raindance', 'primordialsea']) && move && move.type === 'Water') {
				this.debug('Wave Incense boost');
				return this.chainModify(1.2);
			}
		},
		num: 317,
		gen: 4,
		desc: "Holder's Water-type attacks have 1.2x power.",
	},
	"weaknesspolicy": {
		id: "weaknesspolicy",
		name: "Weakness Policy",
		spritenum: 609,
		fling: {
			basePower: 80,
		},
		onHit: function (target, source, move) {
			if (target.hp && move.category !== 'Status' && !move.damage && !move.damageCallback && move.typeMod > 0 && target.useItem()) {
				this.boost({atk: 2, spa: 2});
			}
		},
		num: -6,
		gen: 6,
		desc: "If holder is hit super effectively, raises Attack, Sp. Atk by 2 stages. Single use.",
	},
	"blunderpolicy": {
		id: "blunderpolicy",
		name: "Blunder Policy",
		spritenum: 609,
		fling: {
			basePower: 80,
		},
		onHit: function (target, source, move) {
			if (target.hp && move.category !== 'Status' && !move.damage && !move.damageCallback && move.typeMod > 0 && target.useItem()) {
				this.boost({def: 2, spd: 2});
			}
		},
		num: 9898,
		gen: 6,
		desc: "If holder is hit super effectively, raises Attack, Sp. Atk by 2 stages. Single use.",
	},
	"wepearberry": {
		id: "wepearberry",
		name: "Wepear Berry",
		spritenum: 533,
		isBerry: true,
		naturalGift: {
			basePower: 90,
			type: "Electric",
		},
		num: 167,
		gen: 3,
		desc: "Cannot be eaten by the holder. No effect when eaten with Bug Bite or Pluck.",
	},
	"whiteherb": {
		id: "whiteherb",
		name: "White Herb",
		spritenum: 535,
		fling: {
			basePower: 10,
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if ((pokemon.hasType('Flying') || pokemon.hasType('Ground')) && !pokemon.hasAbility('hyperspeed')) {
				this.heal(pokemon.maxhp / 10);
			}
		},
		num: 214,
		gen: 3,
		desc: "Restores all lowered stat stages to 0 when one is less than 0. Single use.",
	},
	"widelens": {
		id: "widelens",
		name: "Wide Lens",
		spritenum: 537,
		fling: {
			basePower: 10,
		},
		onSourceModifyAccuracy: function (accuracy) {
			if (typeof accuracy === 'number') {
				return accuracy * 1.1;
			}
		},
		num: 265,
		gen: 4,
		desc: "The accuracy of attacks by the holder is 1.1x.",
	},
	"wikiberry": {
		id: "wikiberry",
		name: "Wiki Berry",
		spritenum: 538,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Rock",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(pokemon.maxhp / 8);
			if (pokemon.getNature().minus === 'spa') {
				pokemon.addVolatile('confusion');
			}
		},
		num: 160,
		gen: 3,
		desc: "Restores 1/8 max HP when at 1/2 max HP or less. May confuse. Single use.",
	},
	"wiseglasses": {
		id: "wiseglasses",
		name: "Wise Glasses",
		spritenum: 539,
		fling: {
			basePower: 10,
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.category === 'Special') {
				return this.chainModify([0x1199, 0x1000]);
			}
		},
		num: 267,
		gen: 4,
		desc: "Holder's special attacks have 1.1x power.",
	},
	"yacheberry": {
		id: "yacheberry",
		name: "Yache Berry",
		spritenum: 567,
		isBerry: true,
		onBuffer: 'Ice',
		naturalGift: {
			basePower: 80,
			type: "Ice",
		},
		onSourceModifyDamage: function (damage, source, target, move) {
			if (move.type === 'Ice' && move.typeMod > 0 && !target.volatiles['substitute']) {
				if (target.eatItem()) {
					this.debug('-50% reduction');
					return this.chainModify(0.5);
				}
			}
		},
		onEat: function () { },
		num: 188,
		gen: 4,
		desc: "Halves damage taken from a supereffective Ice-type attack. Single use.",
	},
	"zapplate": {
		id: "zapplate",
		name: "Zap Plate",
		spritenum: 572,
		onPlate: 'Electric',
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Electric') {
				return this.chainModify([0x1333, 0x1000]);
			}
		},
		onTakeItem: function (item, pokemon, source) {
			if ((source && source.baseTemplate.num === 493) || pokemon.baseTemplate.num === 493) {
				return false;
			}
			return true;
		},
		forcedForme: "Arceus-Electric",
		num: 300,
		gen: 4,
		desc: "Holder's Electric-type attacks have 1.2x power. Judgment is Electric type.",
	},
	"zoomlens": {
		id: "zoomlens",
		name: "Zoom Lens",
		spritenum: 574,
		fling: {
			basePower: 10,
		},
		num: 276,
		gen: 4,
		desc: "1.3x Power on all Moves if Tailwind is active. Implemented in Tailwind itself",
	},
	"zoomlensbackup": {
		id: "zoomlensbackup",
		name: "Zoom Lens Backup",
		spritenum: 574,
		isUnreleased: true,
		fling: {
			basePower: 10,
		},
		onSourceModifyAccuracy: function (accuracy, target) {
			if (typeof accuracy === 'number' && !this.willMove(target)) {
				this.debug('Zoom Lens boosting accuracy');
				return accuracy * 1.2;
			}
		},
		num: 276,
		gen: 4,
		desc: "The accuracy of attacks by the holder is 1.2x if it moves after its target.",
	},

	// Gen 2 items

	"berserkgene": {
		id: "berserkgene",
		name: "Berserk Gene",
		spritenum: 388,
		onSwitchIn: function (pokemon) {
			if (pokemon.template.species === 'Mewtwo') {
				this.boost({atk:2});
				pokemon.trySetStatus('brn');
			}
		},
		onResidualOrder: 26,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			pokemon.trySetStatus('brn');
		},
		onBoost: function (boost, target, source, effect) {
			if (source && target === source && source.template.species === 'Mewtwo') return;
			let showMsg = false;
			for (let i in boost) {
				if (boost[i] < 0) {
					delete boost[i];
					showMsg = true;
				}
			}
			if (showMsg && !effect.secondaries) this.add("-fail", target, "unboost", "[from] item: Berserk Gene", "[of] " + target);
		},
		gen: 2,
		desc: "(Gen 2) On switch-in, raises holder's Attack by 2 and confuses it. Single use.",
	},
	"berry": {
		id: "berry",
		name: "Berry",
		spritenum: 319,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Poison",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(150);
		},
		num: 155,
		gen: 2,
		desc: "(Gen 2) Restores 160 HP when at 1/2 max HP or less. Single use.",
	},
	"bitterberry": {
		id: "bitterberry",
		name: "Bitter Berry",
		spritenum: 334,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Ground",
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (this.isWeather(['sandstorm'])) {
				pokemon.switchFlag = true;
			}
		},
		num: 156,
		gen: 2,
		desc: "(Gen 2) Holder is cured if it is confused. Single use.",
	},
	"burntberry": {
		id: "burntberry",
		name: "Burnt Berry",
		spritenum: 13,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Ice",
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (this.isWeather(['sunnyday', 'desolateland'])) {
				pokemon.switchFlag = true;
			}
		},
		num: 153,
		gen: 2,
		desc: "(Gen 2) Holder is cured if it is frozen. Single use.",
	},
	"dragonscale": {
		id: "dragonscale",
		name: "Dragon Scale",
		noRecycle: true,
		spritenum: 108,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Dragon') {
				return basePower * 1.1;
			}
		},
		num: 250,
		gen: 2,
		desc: "(Gen 2) Holder's Dragon-type attacks have 1.1x power. Evolves Seadra (trade).",
	},
	"goldberry": {
		id: "goldberry",
		name: "Gold Berry",
		spritenum: 448,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Psychic",
		},
		onUpdate: function (pokemon) {
			if (pokemon.hp <= pokemon.maxhp / 2) {
				pokemon.eatItem();
			}
		},
		onEatItem: function (item, pokemon) {
			if (!this.runEvent('TryHeal', pokemon)) return false;
		},
		onEat: function (pokemon) {
			this.heal(30);
		},
		num: 158,
		gen: 2,
		isNonstandard: 'gen2',
		desc: "(Gen 2) Restores 30 HP when at 1/2 max HP or less. Single use.",
	},
	"iceberry": {
		id: "iceberry",
		name: "Ice Berry",
		spritenum: 381,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Grass",
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (this.isWeather(['hail'])) {
				pokemon.switchFlag = true;
			}
		},
		num: 152,
		gen: 2,
		desc: "(Gen 2) Holder is cured if it is burned. Single use.",
	},
	"mintberry": {
		id: "mintberry",
		name: "Mint Berry",
		spritenum: 65,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Water",
		},
		onResidualOrder: 5,
		onResidualSubOrder: 2,
		onResidual: function (pokemon) {
			if (this.isWeather(['raindance', 'primordialsea'])) {
				pokemon.switchFlag = true;
			}
		},
		num: 150,
		gen: 2,
		desc: "(Gen 2) Holder wakes up if it is asleep. Single use.",
	},
	"miracleberry": {
		id: "miracleberry",
		name: "Miracle Berry",
		spritenum: 262,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Flying",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status || pokemon.volatiles['confusion']) {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			pokemon.cureStatus();
			pokemon.removeVolatile('confusion');
		},
		num: 157,
		gen: 2,
		isNonstandard: 'gen2',
		desc: "(Gen 2) Holder cures itself if it is confused or has a status condition. Single use.",
	},
	"mysteryberry": {
		id: "mysteryberry",
		name: "Mystery Berry",
		spritenum: 244,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "???",
		},
		onBasePowerPriority: 6,
		onBasePower: function (basePower, user, target, move) {
			if (move && move.type === '???') {
				return this.chainModify([0x14CD, 0x1000]);
			}
		},
		num: 154,
		gen: 2,
		desc: "(Gen 2) Restores 5 PP to the first of the holder's moves to reach 0 PP. Single use.",
	},
	"pinkbow": {
		id: "pinkbow",
		name: "Pink Bow",
		spritenum: 444,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Normal') {
				return basePower * 1.1;
			}
		},
		num: 251,
		gen: 2,
		isNonstandard: 'gen2',
		desc: "(Gen 2) Holder's Normal-type attacks have 1.1x power.",
	},
	"polkadotbow": {
		id: "polkadotbow",
		name: "Polkadot Bow",
		spritenum: 444,
		onBasePower: function (basePower, user, target, move) {
			if (move.type === 'Normal') {
				return basePower * 1.1;
			}
		},
		num: 251,
		gen: 2,
		isNonstandard: 'gen2',
		desc: "(Gen 2) Holder's Normal-type attacks have 1.1x power.",
	},
	"przcureberry": {
		id: "przcureberry",
		name: "PRZ Cure Berry",
		spritenum: 63,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Fire",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'par') {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			if (pokemon.status === 'par') {
				pokemon.cureStatus();
			}
		},
		num: 149,
		gen: 2,
		isNonstandard: 'gen2',
		desc: "(Gen 2) Holder cures itself if it is paralyzed. Single use.",
	},
	"psncureberry": {
		id: "psncureberry",
		name: "PSN Cure Berry",
		spritenum: 333,
		isBerry: true,
		naturalGift: {
			basePower: 80,
			type: "Electric",
		},
		onUpdate: function (pokemon) {
			if (pokemon.status === 'psn' || pokemon.status === 'tox') {
				pokemon.eatItem();
			}
		},
		onEat: function (pokemon) {
			if (pokemon.status === 'psn' || pokemon.status === 'tox') {
				pokemon.cureStatus();
			}
		},
		num: 151,
		gen: 2,
		isNonstandard: 'gen2',
		desc: "(Gen 2) Holder is cured if it is poisoned. Single use.",
	},

	// CAP items

	"crucibellite": {
		id: "crucibellite",
		name: "Crucibellite",
		spritenum: 577,
		megaStone: "Crucibelle-Mega",
		megaEvolves: "Crucibelle",
		onTakeItem: function (item, source) {
			if (item.megaEvolves === source.baseTemplate.baseSpecies) return false;
			return true;
		},
		num: -1,
		gen: 6,
		isNonstandard: true,
		desc: "If holder is a Crucibelle, this item allows it to Mega Evolve in battle.",
	},
};
