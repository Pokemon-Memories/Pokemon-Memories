//Detect and remove ads
document.addEventListener('DOMContentLoaded', function() {
	//Function to be called to stop observer
	function stopObserver() {
		observer.disconnect();
	};//end function

	//Observer function
	var observer = new MutationObserver(function() {
		//If kimcartoon
		if(window.location.href.includes("kimcartoon.li") || window.location.href.includes("kisscenter.net")) {
			kcad1 = document.querySelectorAll("[class^='adsby']")[0];
			if(kcad1) {kcad1.parentNode.removeChild(kcad1)};
			kcad2 = document.getElementsByClassName("glx-teaser")[0];
			if(kcad2) {kcad2.parentNode.removeChild(kcad2)};
			kcad3 = document.getElementsByClassName("glx-close-with-text")[0];
			if(kcad3) {kcad3Parent = kcad3.parentNode; kcad3Parent.parentNode.removeChild(kcad3Parent)};
			kcad4 = document.getElementById("videoAd");
			if(kcad4) {kcad4.parentNode.removeChild(kcad4)};
			kcad5 = document.getElementById("ni-overlay");
			if(kcad5) {kcad5.parentNode.removeChild(kcad5)};
			kcad6 = document.getElementsByClassName("kcAds1")[0];
			if(kcad6) {kcad6.parentNode.removeChild(kcad6)};
			kcad7 = document.querySelectorAll("IFRAME[data-glx='yeap']")[0];
			if(kcad7) {kcad7.parentNode.removeChild(kcad7)};
			kcad8 = document.querySelectorAll("DIV[class*='it-client']")[0];
			if(kcad8) {kcad8.parentNode.removeChild(kcad8)};
			kcad9 = document.getElementById("vi_slider_frame");
			if(kcad9) {kcad9.parentNode.removeChild(kcad9)};
			kcad10 = document.querySelectorAll("DIV[id*='AdskeeperComposite']")[0];
			if(kcad10) {kcad10Parent = kcad10.parentNode; kcad10Parent.parentNode.removeChild(kcad10Parent)};
			kcad11 = document.querySelectorAll("IFRAME[class='it-client-iframe']")[0];
			if(kcad11) {console.log("test"); kcad11Parent = kcad11.parentNode; kcad11Parent.parentNode.removeChild(kcad11Parent)};
			kcad12 = document.querySelectorAll("IFRAME[id^='container-']")[0];
			if(kcad12) {kcad12.parentNode.removeChild(kcad12)};
			kcad13 = document.querySelectorAll("DIV[data-ad-slot^='vi_']")[0];
			if(kcad13) {kcad13.parentNode.removeChild(kcad13)};
			if(document.getElementById("divContentVideo")) {
				kcad14 = document.getElementById("divContentVideo").getElementsByTagName("IFRAME")[0];
				if(kcad14) {kcad14.parentNode.removeChild(kcad14)};
				kcad15 = document.querySelectorAll("IFRAME[style*='block !important']")[0];
				if(kcad15) {kcad15.parentNode.removeChild(kcad15)};
			}
			kcad16 = document.querySelectorAll("IFRAME[src*='Ads']")[0];
			if(kcad16) {kcad16.parentNode.removeChild(kcad16)};
			
			kcad17 = document.querySelectorAll("BODY + IFRAME")[0];
			if(kcad17) {kcad17.parentNode.removeChild(kcad17)};
		}//end if
		
		else if(window.location.href.includes("wcofun")) {
			wad1 = document.getElementById("left300");
			if(wad1) {wad1.parentNode.removeChild(wad1)};
			wad2 = document.getElementById("right300");
			if(wad2) {wad2.parentNode.removeChild(wad2)};
			wad3 = document.getElementById("h-right");
			if(wad3) {wad3.parentNode.removeChild(wad3)};
		}

		//Else if watchcartoon
		else {
			//Remove ads
			ad1 = document.querySelectorAll("[id^='div-1-']")[0];
			if(ad1) {ad1.parentNode.removeChild(ad1);};
			ad2 = document.querySelectorAll("[id*='Composite']")[0];
			if(ad2) {ad2.parentNode.removeChild(ad2);};
			ad3 = document.querySelectorAll("[id^='div-3-']")[0];
			if(ad3) {ad3.parentNode.removeChild(ad3);};
			ad4 = document.querySelectorAll("[src*='wcofun.tv/ads']")[0];
			if(ad4) {adParent = ad4.parentNode.parentNode.parentNode.parentNode; adParent.parentNode.removeChild(adParent);};
			ad5 = document.querySelectorAll("[style*='moz-box-sizing']")[0];
			if(ad5) {ad5.parentNode.removeChild(ad5);}
			ad6 = document.querySelectorAll("[id*='-ps']")[0];
			if(ad6) {ad6.parentNode.removeChild(ad6);}
			ad7 = document.querySelectorAll("[target*='_blank']:not([href*='thumb'])")[0];
			if(ad7) {ad7.parentNode.removeChild(ad7);}
			ad8 = document.querySelectorAll("[id^='ad_is']")[0];
			if(ad8) {ad8.parentNode.removeChild(ad8);}
			ad9 = document.querySelectorAll("[src*='/ads']")[0];
			if(ad9) {ad9.parentNode.removeChild(ad9);}
			ad10 = document.querySelectorAll("[name='cpmstar_anchor_ifrad']")[0];
			if(ad10) {ad10.parentNode.removeChild(ad10);}
			ad11 = document.getElementById("p_native");
			if(ad11) {ad11.parentNode.removeChild(ad11);}
			ad12 = document.getElementById("IL_INSEARCH");
			if(ad12) {ad12.parentNode.removeChild(ad12);}
			ad13 = document.querySelectorAll("[id^='p_root']")[0];
			if(ad13) {ad13.parentNode.parentNode.removeChild(ad13.parentNode);}
			ad14 = document.getElementById("av-container");
			if(ad14) {ad14.parentNode.removeChild(ad14);}
			ad15 = document.querySelectorAll("[href*='//redir.']")[0];
			if(ad15) {ad15.parentNode.parentNode.removeChild(ad15.parentNode);}
			ad16 = $("div:contains('Recommended')");
			if(ad16.length>0) {
				for(a=0;a<ad16.length;a++) {
					if(ad16[a].innerText == "Recommended") {
						adParent2 = ad16[a].closest("DIV[id*='div-2-']");
					}
				}
				if(adParent2) {
					adParent2.parentNode.removeChild(adParent2);
				}
			}
			ad17 = document.getElementById("iki-player-arasi");
			if(ad17) {ad17.parentNode.removeChild(ad17);};
			ad18 = document.getElementsByClassName("fifteen columns");
			if(ad18.length > 0) {ad18[0].parentNode.removeChild(ad18[0])};
			ad19 = document.getElementById("reklam_adscat");
			if(ad19) {ad19.parentNode.removeChild(ad19);};
			ad20 = document.getElementsByClassName("vlioutstream show")[0];
			if(ad20) {ad20.parentNode.removeChild(ad20);};
			ad21 = document.querySelectorAll("DIV[id*='ads_player']")[0];
			if(ad21) {ad21.parentNode.removeChild(ad21);};
			ad22 = document.querySelectorAll("DIV[id*='ad_li_']")[0];
			if(ad22) {ad22.parentNode.removeChild(ad22);};
			ad23 = document.querySelectorAll("DIV[id^='left']")[0];
			if(ad23) {ad23.parentNode.removeChild(ad23);};
			ad24 = document.querySelectorAll("DIV[id^='right']")[0];
			if(ad24) {ad24.parentNode.removeChild(ad24);};
			ad25 = document.getElementsByTagName("IFRAME");
			for(b=0;b<ad25.length;b++) {
				if(ad25[b].hasAttribute("class")) {
					ad25[b].parentNode.parentNode.removeChild(ad25[b].parentNode);
					console.log("test");
				}
			}
			ad26 = document.querySelectorAll("DIV[class^='unique']")[0];
			if(ad26) {ad26.parentNode.removeChild(ad26)}
			ad27 = document.querySelectorAll("DIV[class^='reklam']")[0];
			if(ad27) {ad27.parentNode.removeChild(ad27)}
			ad28 = document.querySelectorAll("DIV[id^='videootv']")[0];
			if(ad28) {
				adParent3 = ad28.parentNode;
				adParent3.parentNode.removeChild(adParent3);
			}
		}//end else

		//Stop observer
		if(document.readyState == "complete") {
			//stopObserver;
		};
	});//end function

	//Observe element
	observer.observe(document.body, {
		subtree: true,
		attributes: true,
		childList: true,
		characterData: true
	});
	
});

window.onload = function() {
	//Hide registration
	if(window.location.href.includes("wcostream")) {
		if(document.getElementsByClassName("larkax").length > 0 || document.getElementById("cizgi-video-js-0")) {
			setTimeout(function() {
				document.getElementsByTagName("iframe")[0].scrollIntoView();
				setTimeout(function() {
					if($("p:contains('Registration Required')")) {
						$("iframe").contents().find("p:contains('Registration Required')").parent().hide();
					}
				}, 750)
			}, 100);
		}
		

		//Add autoplay option
		var num = document.getElementById("content").getElementsByTagName("IFRAME").length;
		var nextlink = document.querySelectorAll("A[rel='next']")[0];

		//Loop through videos and add slider
		for(i=0; i<num; i++) {
			var iframe = document.getElementsByTagName("IFRAME")[i];
			var head = iframe.contentWindow.document.getElementsByTagName("HEAD")[0];
			
			var style = document.createElement("STYLE");
			style.type = 'text/css';
			head.appendChild(style);

			var link = document.createElement("LINK");
			link.rel = 'stylesheet';
			link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css';
			$("iframe").contents().find("head").append(link);

			style.innerHTML = `
			.switch {position: relative; display: inline-block; width: 32px; height: 16px; top: 7px}
			.switch input {opacity: 0; width: 0; height: 0}
			.slider {position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; -webkit-transition: .4s; transition: .4s; border-radius: 16px; font-family: 'FontAwesome'; text-align: center; line-height: 150%; display: flex; flex-direction: row; align-items: center; justify-content: center; font-size: 70%; border: 2px solid #ccc; color: white}
			.slider::before {position: absolute; height: 11px; width: 11px; left: 0.5px; bottom: 0.5px; -webkit-transition: .4s; transition: .4s; border-radius: 50%; content: "\\f04c"}
			input:checked + .slider::before {-webkit-transform: translateX(16px); -ms-transform: translateX(16px); transform: translateX(16px); content: "\\f04b"}`;

			var settings = document.createElement("DIV");
			settings.className = "vjs-settings-button vjs-menu-button vjs-control vjs-button";
			settings.id = "sttngs";
			settings.innerHTML = "<label class='switch'><input type='checkbox'><span class='slider'></span></label>";
			
			var cb = iframe.contentWindow.document.getElementsByClassName("vjs-control-bar")[0];
			var fs = iframe.contentWindow.document.getElementsByClassName("vjs-fullscreen-control")[0];
			
			cb.insertBefore(settings, fs);
		
		} //end loop
		
		
		
		//Add autoplay function to videos
		var vidfn = [];
		var j;
		
		//Function to run at video end
		function returnfn(j) {
			return function() {
				var iframe = document.getElementsByTagName("IFRAME")[j];
				var video = iframe.contentWindow.document.getElementsByTagName("VIDEO")[0];
				if(sessionStorage.getItem("play") == "on" && video.src.includes("error") == false) {
					if(j == num-1){
						if(document.querySelectorAll("A[rel='next']").length > 0){
							//alert("last")
							nextlink.click();
						}
					}
					else {
						//alert("not last")
						var nexti = document.getElementsByTagName("IFRAME")[j+1];
						var nextb = nexti.contentWindow.document.getElementsByClassName("vjs-big-play-button")[0];
						nexti.scrollIntoView();
						nextb.click();
					}
				}
			}
		}
		
		for(j=0;j<num;j++) {
			vidfn[j] = returnfn(j);
			var iframe = document.getElementsByTagName("IFRAME")[j];
			var video = iframe.contentWindow.document.getElementsByTagName("VIDEO")[0];
			video.onended = vidfn[j];
		}
		
		
		
		//Add function to setting buttons
		var setfn = [];
		var k;
		
		//Function to run on button click
		function returnset(k) {
			return function() {
				//alert(k);
				var iframe = document.getElementsByTagName("IFRAME")[k];
				var abutton = iframe.contentWindow.document.getElementsByTagName("INPUT")[0];
				if(abutton.checked == true){sessionStorage.setItem("play","on");}
				else {sessionStorage.setItem("play","off");}
				for(c=0;c<num;c++) {
					var ic = document.getElementsByTagName("IFRAME")[c];
					var ac = ic.contentWindow.document.getElementsByTagName("INPUT")[0];
					if(sessionStorage.getItem("play") == "on"){ac.checked = true;}
					else {ac.checked = false;}
				}
			}
		}
		
		for(k=0;k<num;k++) {
			setfn[k] = returnset(k);
			var iframe = document.getElementsByTagName("IFRAME")[k];
			var settings = iframe.contentWindow.document.getElementsByClassName("vjs-settings-button")[0];
			settings.onclick = setfn[k];
		}
		
		
		
		//Initialize autoplay
		if(sessionStorage.getItem("play") == "on"){
			var iframe = document.getElementsByTagName("IFRAME")[0];
			var pbutton = iframe.contentWindow.document.getElementsByClassName("vjs-big-play-button")[0];
			pbutton.click();
		}
		else if(sessionStorage.getItem("play") != "off"){
			sessionStorage.setItem("play", "off");
		}
		
		for(c=0;c<num;c++) {
			var ic = document.getElementsByTagName("IFRAME")[c];
			var ac = ic.contentWindow.document.getElementsByTagName("INPUT")[0];
			if(sessionStorage.getItem("play") == "on"){ac.checked = true;}
			else {ac.checked = false;}
		}
		
	}
}
